import java.util.Iterator;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import org.graphstream.graph.Edge;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.MultiGraph;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;
import org.graphstream.ui.view.ViewerListener;
import org.graphstream.ui.view.ViewerPipe;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.LogarithmicAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.time.Instant;
import java.text.Format;
import java.util.ArrayList;
import java.util.Dictionary;
import javax.swing.JComponent;
import javax.swing.JFileChooser;

import java.util.Hashtable;
import java.text.DecimalFormat;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.Rectangle;

import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.Color;
import java.io.IOException;
import java.io.FileReader;
import java.awt.Component;
import java.awt.Desktop;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JFrame;  
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;


class GFG{
   
static int X;
//static final int Z = 2;
 
// Function to find if there is a
// path between two vertices in a
// directed graph
static boolean existPath(int V, int edges[][],
                         int u, int v,int num)
{
	X=num;
     
    // mat matrix
    boolean [][]mat = new boolean[V][V];
 
    // set mat[i][j]=true if there is
    // edge between i to j
    for (int i = 0; i < X; i++)
        mat[edges[i][0]][edges[i][1]] = true;
 
    // Check for all intermediate vertex
    for(int k = 0; k < V; k++) 
    {
        for(int i = 0; i < V; i++) 
        {
            for(int j = 0; j < V; j++)
            {
                mat[i][j] = mat[i][j] || 
                            mat[i][k] &&
                            mat[k][j];
            }
        }
    }
 
    // If vertex is invalid
    if (u >= V || v >= V)
    {
        return false;
    }
 
    // If there is a path
    if (mat[u][v])
        return true;
    return false;
}
}
class POGraph { 
    
    public final int V; 
    public final List<List<Integer>> adj; 
  
    public POGraph(int V)  
    { 
        this.V = V; 
        adj = new ArrayList<>(V); 
          
        for (int i = 0; i < V; i++) 
            adj.add(new LinkedList<>()); 
    } 
      
    // This function is a variation of DFSUtil() in  
    // https://www.geeksforgeeks.org/archives/18212 
   public boolean isCyclicUtil(int i, boolean[] visited, 
                                      boolean[] recStack)  
    { 
          
        // Mark the current node as visited and 
        // part of recursion stack 
        if (recStack[i]) 
            return true; 
  
        if (visited[i]) 
            return false; 
              
        visited[i] = true; 
  
        recStack[i] = true; 
        List<Integer> children = adj.get(i); 
          
        for (Integer c: children) 
            if (isCyclicUtil(c, visited, recStack)) 
                return true; 
                  
        recStack[i] = false; 
  
        return false; 
    } 
  
    public void addEdge(int source, int dest) { 
        adj.get(source).add(dest); 
    } 
  
    // Returns true if the graph contains a  
    // cycle, else false. 
    // This function is a variation of DFS() in  
    // https://www.geeksforgeeks.org/archives/18212 
    public boolean isCyclic()  
    { 
          
        // Mark all the vertices as not visited and 
        // not part of recursion stack 
        boolean[] visited = new boolean[V]; 
        boolean[] recStack = new boolean[V]; 
          
          
        // Call the recursive helper function to 
        // detect cycle in different DFS trees 
        for (int i = 0; i < V; i++) 
            if (isCyclicUtil(i, visited, recStack)) 
                return true; 
  
        return false; 
    } 
}
class matrix{
	int row;
	int col;
double val;
	matrix next;
}
class sNode
{
    String id;
    int visited;
    int flag;
    sNode next;
    sNode prev;
    
    sNode() {
        this.flag = 0;
    }
}
class Rpair
{
    String id1;
    String id2;
    int done;
    Rpair next;
}

class PO
{
    String id1;
    String id2;
    int visited;
    PO next;
}
class plist
{
    int name;
    sNode begin;
    double val;
    double extra;
    double extra2;
    plist next;
    
}
class Node
{
    String id;
    int priority;
    Node next;
}
class NFRWeight
{
    String id;
    float val;
    NFRWeight next;
}
class MC
{
    BC Blist;
    int CEdge;
    MC next;
}
class MacroWeight
{
    String id1;
    String id2;
    float val;
    MacroWeight next;
}
class FRDep
{
    String id;
    int val;
    FRDep next;
}
class Edge2
{
    String id1;
    String id2;
    Edge2 next;
}
class Edge1
{
    String id1;
    String id2;
    int value;
    Edge1 next;
}
class DrawNode
{
    String name;
    int indegree;
    int visited;
    int x;
    int y;
    DrawNode next;
}
class BC
{
    String Nid;
    FRDep begin;
    BC next;
}
public class PartialOrder extends JFrame 
{
    static Node FRup, NFRup;
   static  Edge1 E_NNup, E_FNup;
    static Edge2 E_FFup;
    static BC bcHeadup;
    static MC mcHeadup;
    static Rpair rootup;
    static PO prootup;
    static plist seq_up1, seq_up2;
	static int updatedep=0;
	static int updatecon=0;
	static int newdep=0;
	static int newcon=0;
	static int newtemp=0;
	static int newFR=0;
	static int newNFR=0;
	static int clicked=0;
	static int countclick=0;
	static JLabel headclick=new JLabel();
	private static DecimalFormat df = new DecimalFormat("0.00");
	static double probability,rint;
	static double impval;
	static double[][] conflict_weight;
	static double[][] dep_weight;
	static int froindex=0;
	static double RiskExp,RiskExp2;
    static plist rlist,rlist2,rootOp,rootFRo;
    static Node frozenHead;
    static Node FR;
    static Node FR2;
    static Node Fro;
    static JTable parameter;
    static Node prevFro;
    static Node NFR;
    static Node source;
    static Node sink;
    static Edge1 E_FN;
    static Edge1 E_NN;
    static Edge2 E_FF;
    static BC bcHead,bcHead2;
    static MC mcHead,mcHead2;
    static matrix wn,wd;
    static Rpair root;
    static Rpair root2;
    static Rpair root3;
    static PO VprevEdges;
    static PO vedges;
    static PO proot;
    static PO proot2;
    static PO vroot;
    static PO proot3;
    static Node LNFR1;
    static Node LNFR2;
    static DrawNode droot;
    static int countNFR;
    static int countFR;
    static int choice;
    static double w1;
    static double w2;
    //static 	DefaultTableModel model;
    static JFrame frame1,firstFrame,frozenFrame,editFrame, start_frame,po_frame, pa_frame,fp_frame;
    static JLabel[] NFRlabels;
    static JTextField[] NFRPriority;
    static JButton Report;
    static JButton unfreeze;
    static JRadioButton[] FRs;
    static JLabel label1;
    static JLabel label2;
    static JLabel label3;
    static JLabel label4;
    static JLabel label5;
    static JLabel label6;
    static JLabel label7;
    static JLabel label8;
    static JLabel label9;
    static final JButton refresh;
    static final JButton viewAnalytics;
    static final JButton savePriority;
    static final JRadioButton conflict;
    static final JRadioButton priority;
    static final JRadioButton both;
    static final JRadioButton both2;
    static final JRadioButton nc;
    static final JButton submit;
    static final JButton generate, generate2, risk, iterate;
    static final JButton viewgraph, viewgraph2;
    static final JButton frozenFR;
    static final JButton submitfrozen;
    static final JButton editReq;
    static final JButton generatePO;
    static final JButton submitConflict, submitFR, submitNFR,submitFR_NFR,submit_temporal;
    static final JButton saveChanges,addFrozen,delFrozen,delconflict,deltemporal,deldep,loadNFR,savedata,saveconfig,loadconfig;
    static JTextArea textOrder1;
    static JScrollPane scrollPane1;
    static JTextArea textOrder2;
   static  JTextArea req;
    static JScrollPane scrollPane4;
    static JScrollPane scrollPane2;
    static JTextArea textOrder3;
    static JTextArea frozenFRs;
    static JScrollPane scrollPane3,scrollPaneFR,scrollPaneconflict,scrollPanetemporal;
    static JSlider slider1;
	//static DefaultTableModel model = new DefaultTableModel(data,col);  
	static JTable Req,NFR_priority,Reqconflict, Reqtemporal,statdata;
    static JComboBox nfr1,nfr2,nfr3,fr2,nfr5,fr3,fr4,fr5,depvalue1,depvalue2,depvalue3,frofr;
   static JTextArea degree, fr1, nfr4;
    static long beforeUsedMem;
    static PO checkEdge;
    static PO reachable,reachable2;
    static int edgeCount;
    static int riskVal;
    static plist flist,combo;
    public static final int INNER_WIDTH = 50;
    public static final int OUTER_WIDTH = 40;
    static int iteration=1;
    static JTextArea ita;
	static JTable frnfr;
	static int loaddata;
    static {
    	loaddata=0;
    	flist=null;
    	combo=null;
    	rint=0.0;
    	probability=0;
    	impval=0;
    	RiskExp=0;
    	RiskExp2=0;
    	ita=new JTextArea(20,20);
    	riskVal=0;
        rlist = null;
        frozenHead=null;
        FR = null;
        NFR = null;
        E_FN = null;
        E_NN = null;
        E_FF = null;
        bcHead = null;
        mcHead = null;
        root = null;
        VprevEdges=null;
        vedges=null;
        proot = null;
        LNFR1 = null;
        LNFR2 = null;
        droot = null;
        parameter=new JTable();
        frnfr=new JTable();
        wn=null;
        wd=null;
        countNFR = 0;
        countFR = 0;
        choice = 0;
        w1 = 0.0;
        w2 = 0.0;
        prevFro=null;
        viewAnalytics=new JButton("View Analytics");
        start_frame=new JFrame("CARO Tool");
        frame1 = new JFrame("Set NFR Priority & Select Parameter");
        po_frame=new JFrame("Generate Partial Orders!");
        firstFrame = new JFrame("Set Requirements and Constraints");
        frozenFrame = new JFrame("Select Frozen Functional Requirements");
        editFrame = new JFrame("Update Requirements");
        pa_frame=new JFrame("Set Project Parameters!!");
        fp_frame=new JFrame("Set values of FP attributes");
        NFRlabels = new JLabel[100];
        NFRPriority = new JTextField[100];
        FRs = new JRadioButton[100];
        label1 = new JLabel();
        label2 = new JLabel();
        label3 = new JLabel();
        label4 = new JLabel();
        label5 = new JLabel();
        label6 = new JLabel();
        label7 = new JLabel();
        label8 = new JLabel();
        label9 = new JLabel();
        savePriority = new JButton("Save Priority");
        conflict = new JRadioButton("Conflict");
        priority = new JRadioButton("NFR Priority");
        both = new JRadioButton("Product");
        both2 = new JRadioButton("Weighted sum");
        nc = new JRadioButton("Without conflict");
        submit = new JButton("SUBMIT");
        generate = new JButton("Generate Optimal PO");
        viewgraph = new JButton("View Optimal PO graph");
        generate2 = new JButton("Generate Alternate PO");
        viewgraph2 = new JButton("View Alternate PO graph");
        frozenFR = new JButton("Select frozen FR");
        risk = new JButton("Compare Partial Orders");
        iterate = new JButton("Next Iteration");
        editReq = new JButton("Update Requirements");
        generatePO = new JButton("Generate Partial Order");
        submitfrozen=new JButton("Submit");
       refresh=new JButton("Refresh Table");
       submitConflict=new JButton("Submit Conflict");
       unfreeze =new JButton("UnFreeze");
       submitFR=new JButton("Submit");
       submitNFR=new JButton("Submit new NFR");
       submitFR_NFR=new JButton("Submit new relationship");
       submit_temporal=new JButton("Submit Dependency");
       saveChanges=new JButton("Save Changes");
       addFrozen=new JButton("Add");
       delFrozen=new JButton("Delete");
       delconflict=new JButton("Delete Conflict");
       deltemporal=new JButton("Delete Dependency");
       deldep=new JButton("Delete");
       loadNFR=new JButton("Load NFR");
       savedata=new JButton("Save Data");
       loadconfig=new JButton("Load Configuration");
       saveconfig=new JButton("Save Configuration");
       Report=new JButton("View Report");
        textOrder1 = new JTextArea(400, 400);
        scrollPane1 = new JScrollPane(textOrder1);
        textOrder2 = new JTextArea(100, 600);
        scrollPane2 = new JScrollPane(textOrder2);
        textOrder3 = new JTextArea(100, 600);
        scrollPane3 = new JScrollPane(textOrder3);
        slider1 = new JSlider(0, 0, 10, 0);
        req=new JTextArea(400,400);
        scrollPane4 = new JScrollPane(req);
        //Req=new JTable();
        nfr1=new JComboBox();
        nfr2=new JComboBox();
        nfr3=new JComboBox();
        fr2=new JComboBox();
     //model=new 	DefaultTableModel();
        nfr5=new JComboBox();
        fr3=new JComboBox();
        fr4=new JComboBox();
        fr5=new JComboBox();
        frofr=new JComboBox();
        depvalue1=new JComboBox();
        depvalue2=new JComboBox();
        depvalue3=new JComboBox();
        degree=new JTextArea(20,20);
        fr1=new JTextArea(20,20);
        nfr4=new JTextArea(20,20);
        frozenFRs=new JTextArea(20,20);
        scrollPaneFR = new JScrollPane(frozenFRs);
        beforeUsedMem = 0L;
        checkEdge = null;
        reachable = null;
        edgeCount = 0;
        
    }
   public static boolean existPath(int V, int edges[][],
            int u, int v,int num)
{


// mat matrix
boolean [][]mat = new boolean[V+1][V+1];

// set mat[i][j]=true if there is
// edge between i to j
for (int i = 0; i < num; i++)
mat[edges[i][0]][edges[i][1]] = true;

// Check for all intermediate vertex
for(int k = 0; k < V+1; k++) 
{
for(int i = 0; i < V+1; i++) 
{
for(int j = 0; j < V+1; j++)
{
   mat[i][j] = mat[i][j] || 
               mat[i][k] &&
               mat[k][j];
  // System.out.println("Hello there!!");
}
}
}

// If vertex is invalid
if (u >= V || v >= V)
{
return false;
}

// If there is a path
if (mat[u][v])
return true;
return false;
}
    public static void main(final String[] args) {
        beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        choice = 0;
        FR=null;
        NFR=null;
        E_FN=null;
        E_NN=null;
        E_FF=null;
        proot=null;
        proot2=null;
        root=null;
        root2=null;
        Fro=null;
        prevFro=null;
        VprevEdges=null;
        iteration=1;
        choice=0;
        start_frame();
 
    }
    //This is the module that creates the first interface of the CARO tool
    public static void start_frame() {
    	JLabel heading1=new JLabel("Welcome to Our Tool!!");
    	JLabel heading2=new JLabel("Choose an operation to perform");
    	  Font f1 = new Font("TimesRoman",Font.BOLD+Font.ITALIC,25);
    	  heading1.setFont(f1);
    	  Font f2 = new Font("TimesRoman",Font.ITALIC,20);
    	  heading2.setFont(f2);
    	  start_frame.getContentPane().setBackground(new Color(205, 142, 104));
          try {
              UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
          }
          catch (Exception e) {
              System.out.println("Look and Feel not set");
          }
          start_frame.setLayout(null);
          start_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
          start_frame.setBounds(15, 6, 530, 600);
       heading1.setBackground(new Color(102, 102, 255));
          heading1.setForeground(Color.black);
          heading2.setBackground(new Color(102, 102, 255));
          heading2.setForeground(Color.black);
          heading1.setBounds(130, 20, 250, 40);
          heading2.setBounds(130, 50, 350, 40);
      //    start_frame.add(heading1);
          start_frame.add(heading2);
 
          //Button to navigate to requirement input frame
          JButton b1=new JButton("Set constraints");
          b1.setToolTipText("Interface to provide new requirements and access old requirements");
       b1.setFont(new Font("Calibri", 2, 16));
       b1.setBackground(new Color(255, 204, 204));
          b1.setForeground(Color.black);
        b1.setBounds(25, 150, 200, 40);
        start_frame.add(b1);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
            	
            	addDepConValues();
            }
        });
        
      //Button to navigate to partial order generation frame
        JButton b2=new JButton("Generate PO & Do Risk Aanlysis");
        b2.setToolTipText("Interface to generate partial order & perform Risk analysis");
       b2.setFont(new Font("Calibri", 2, 16));
     b2.setBackground(new Color(255, 204, 204));
      b2.setForeground(Color.black);
      b2.setBounds(250, 150, 240, 40);
      start_frame.add(b2);
      b2.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(final ActionEvent e) {
          POframe();
          }
      });
      
      //Button to navigate to dashboard frame
      JButton b3=new JButton("View Dashboard");
      b3.setToolTipText("Displays the work progress!");
     b3.setFont(new Font("Calibri", 2, 16));
   b3.setBackground(new Color(255, 204, 204));
    b3.setForeground(Color.black);
    b3.setBounds(100, 220, 240, 40);
    start_frame.add(b3);
    b3.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
        showLog();
        }
    });
    //Button to load existing data set
    loadconfig.setToolTipText("Click to load the last saved configuration!");
   loadconfig.setFont(new Font("Calibri", 2, 16));
   loadconfig.setBackground(new Color(255, 204, 204));
   loadconfig.setForeground(Color.black);
   loadconfig.setBounds(30, 290, 170,40);
     start_frame.add(loadconfig);
     loadconfig.addActionListener(new ActionListener() {
         @Override
          public void actionPerformed(final ActionEvent e) {
            set_data();
          }
      });
    saveconfig.setToolTipText("Cleck here to Save your work before exiting!");
    saveconfig.setFont(new Font("Calibri", 2, 16));
    saveconfig.setBackground(new Color(255, 204, 204));
    saveconfig.setForeground(Color.black);
    saveconfig.setBounds(230, 290, 200,40);
      start_frame.add(saveconfig);
      saveconfig.addActionListener(new ActionListener() {
          @Override
           public void actionPerformed(final ActionEvent e) {
         	store_data();
           }
       }); 
      iteration=1;
  	JLabel it=new JLabel("Iteration Count");
      it.setFont(new Font("Calibri", 2, 16));
      it.setBounds(50, 360, 200, 40);
     start_frame.add(it);
     
     ita.setFont(new Font("Calibri", 2, 16));
     ita.setBounds(170, 360, 40, 30);
    start_frame.add(ita);
    ita.setEditable(false);
    String s=Integer.toString(iteration);
    ita.setText(s);
    iterate.setFont(new Font("Calibri", 2, 16));
    iterate.setBackground(new Color(255, 204, 204));
    iterate.setForeground(Color.black);
    iterate.setBounds(240, 360, 200, 30);
   iterate.setToolTipText("Click to move to next Iteration");
    start_frame.add(iterate);
  
    iterate.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
             updatecon=0;
             updatedep=0;
             newdep=0;
             newcon=0;
             newtemp=0;
             newFR=0;
             newNFR=0;
         	 iteration++;
       	  frozenFRs.setText("");
             probability=0;
             impval=0;
             rint=0;
       	 vedges=null;
       	 Fro=null;
       	 RiskExp2=0;
       	 String s=Integer.toString(iteration);
            ita.setText(s);
       	 generate2.setEnabled(true);
       	 viewgraph2.setEnabled(true);
       	 risk.setEnabled(true);
       	 frofr.setEnabled(true);
       	 addFrozen.setEnabled(true);
       	 delFrozen.setEnabled(true);
       	
        }
    });
    
    //Button to navigate to requirement project parameters frame
    JButton b4=new JButton("Set Project Parameters");
    b4.setToolTipText("Interface to provide values for different parameters of the project that are used for effort estimation!");
    b4.setFont(new Font("Calibri", 2, 16));
    b4.setBackground(new Color(255, 204, 204));
    b4.setForeground(Color.black);
    b4.setBounds(100, 450, 200, 40);
    start_frame.add(b4);
  b4.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
      	parameter_frame();
      }
  });
     start_frame.setVisible(true);
    	  
    }
    //Module to set project parameters
    public static void parameter_frame() {
    	pa_frame.getContentPane().setBackground(new Color(224, 204, 124));
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch (Exception e) {
            System.out.println("Look and Feel not set");
        }
        pa_frame.setLayout(null);
        pa_frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       pa_frame.setBounds(15, 6, 600, 850);
       
       JLabel heading1=new JLabel("Set Project Parameters!!");
       heading1.setFont(new Font("Calibri", 2, 18));
       heading1.setBounds(20, 10, 200, 40);
       pa_frame.add(heading1);
       
       /*JLabel text1=new JLabel("1: Very Low");
       text1.setFont(new Font("Calibri", 2, 15));
     text1.setBounds(435, 95, 100, 40);
       pa_frame.add(text1);
       JLabel text2=new JLabel("2: Low");
       text2.setFont(new Font("Calibri", 2, 15));
     text2.setBounds(435, 135, 100, 40);
       pa_frame.add(text2);
       JLabel text3=new JLabel("3:Nominal");
       text3.setFont(new Font("Calibri", 2, 15));
     text3.setBounds(435, 175, 110, 40);
       pa_frame.add(text3);
       JLabel text4=new JLabel("4: High");
       text4.setFont(new Font("Calibri", 2, 15));
     text4.setBounds(435, 220, 100, 40);
       pa_frame.add(text4);
       JLabel text5=new JLabel("5: Very High");
       text5.setFont(new Font("Calibri", 2, 15));
     text5.setBounds(435, 260, 100, 40);
       pa_frame.add(text5);
       JLabel text6=new JLabel("6: Extra High");
       text6.setFont(new Font("Calibri", 2, 15));
     text6.setBounds(435, 300, 100, 40);
       pa_frame.add(text6);*/
       
       
       JTable parameter;
       String []col2={"Parameter (Multipler)","Value"};
       String [][]data2=null;
   	 	DefaultTableModel model2 = new DefaultTableModel(data2,col2);  
   	 	parameter=new JTable(model2);/*{
   	    @Override
   	    public boolean isCellEditable(int row, int column) {                
   	        return (column==1);               
   	    };
   	    
   	};*/
   		parameter.setFillsViewportHeight(true);
   	parameter.setRowHeight(30);
    parameter.getColumnModel().getColumn(0).setPreferredWidth(150);
    parameter.getColumnModel().getColumn(1).setPreferredWidth(20);
		JScrollPane js2=new JScrollPane(parameter);
		  js2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		   //js2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		  js2.setBounds(25, 65, 400, 220);
		js2.setVisible(true);
		//jp2.add(js2);
	pa_frame.add(js2);
	
	JTable parameter2;
    String []col3={"Parameter (Scale factor)","Value"};
    String [][]data3=null;
	 	DefaultTableModel model3 = new DefaultTableModel(data3,col3);  
	 	parameter2=new JTable(model3);
		parameter2.setFillsViewportHeight(true);
	parameter2.setRowHeight(30);
 parameter2.getColumnModel().getColumn(0).setPreferredWidth(150);
 parameter2.getColumnModel().getColumn(1).setPreferredWidth(20);
		JScrollPane js3=new JScrollPane(parameter2);
		  js3.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		   //js2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		  js3.setBounds(25, 310, 400, 200);
		js3.setVisible(true);
		//jp2.add(js2);
	pa_frame.add(js3);
	
	JTable parameter3;
    String []col4={"Parameter (FP Adjustment factor)","Value"};
    String [][]data4=null;
	 	DefaultTableModel model4 = new DefaultTableModel(data4,col4);  
	 	parameter3=new JTable(model4);
		parameter3.setFillsViewportHeight(true);
	parameter3.setRowHeight(30);
 parameter3.getColumnModel().getColumn(0).setPreferredWidth(150);
 parameter3.getColumnModel().getColumn(1).setPreferredWidth(20);
		JScrollPane js4=new JScrollPane(parameter3);
		  js4.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		   //js2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		  js4.setBounds(25, 530, 400, 220);
		js4.setVisible(true);
		//jp2.add(js2);
	pa_frame.add(js4);
	//adding parameters to the table
	Object []o = new Object[1];
	o[0]="RUSE (Reuse required)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="PERS (Personnel Capability)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="RCPX (Product Reliability and Complexity)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="PREX (Personnel Experience)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="FCIL (Support Facilities)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="SCED (Schedule)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="PDIF (Platform Difficulty)";
	model2.addRow(o);
	o = new Object[1];
	o[0]="Precedentedness";
	model3.addRow(o);
	o = new Object[1];
	o[0]="Development Flexibility";
	model3.addRow(o);
	o = new Object[1];
	o[0]="Architecture or Risk Resolution";
	model3.addRow(o);
	o = new Object[1];
	o[0]="Team Cohesion";
	model3.addRow(o);
	o = new Object[1];
	o[0]="Process Maturity";
	model3.addRow(o);
	o = new Object[1];
	o[0]="Back-up & Recovery";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Data Communication";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Distributed Processing";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Critical Performance";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Heavily used Configuration";
	model4.addRow(o);
	o = new Object[1];
	o[0]="On-line Data Entry";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Transaction Complexity";
	model4.addRow(o);
	o = new Object[1];
	o[0]="On-line Master File Update";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Complex External Processing";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Complex Internal Processing";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Reusability";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Installation Factor";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Multiple Sites";
	model4.addRow(o);
	o = new Object[1];
	o[0]="Change Facilitation";
	model4.addRow(o);
	File f1=new File("Multiplier.txt");
    if(f1.exists()) {
    	
 	   try {
 		   FileReader f2=new FileReader("Multiplier.txt");
 		 
 		   int i=0;
 		   char c;
 		  String temp1="";
		   String temp2="";
		   int flag=0;
		   int flag2=0;
		   int count=1;
		   int k=0;
 		  while((i=f2.read())!=-1) {
 	 			
			   c=(char)i;
			   if(i==124 && count==1) {
				 flag=1; 
				 count=2;
			   }
			   else if(i==124 && count==2) {
				   flag=0;
				   count=1;
				   System.out.println("Temp = "+temp1);
				   model2.setValueAt(temp1, k, 1);
				   k++;
				   temp1="";
				   flag2=1;
			   }
			   else if(flag==1) {
				   temp1=temp1.concat(Character.toString(c));
			   }
			   else if(flag2==1) {
				   System.out.println("c= "+c);
				   if((i>=48 && i<=57)||i==46)
					   flag2=1;
					 else
						   flag2=0;
			   }
			 
 		  }
 		  f2.close();
 	   }catch(IOException es) {
 		   
 	   }
    }
 		  	
	    f1=new File("ScaleFactor.txt");
 	    if(f1.exists()) {
 	    	
 	 	   try {
 	 		FileReader  f2=new FileReader("ScaleFactor.txt");
 	 		 
 	 		int i=0;
 	 		char c;
 	 		String temp1="";
 			    String temp2="";
 			   int flag=0;
 			   int count=1;
 			   int k=0;
 	 		  while((i=f2.read())!=-1) {
 	 	 			
 				   c=(char)i;
 				   if(i==124 && count==1) {
 					 flag=1; 
 					 count=2;
 				   }
 				   else if(i==124 && count==2) {
 					   flag=0;
 					   count=1;
 					   System.out.println("Temp = "+temp1);
 					   model3.setValueAt(temp1, k, 1);
 					   k++;
 					   temp1="";
 				   }
 				   else if(flag==1) {
 					   temp1=temp1.concat(Character.toString(c));
 				   }
 				 
 	 		  }
 	 		  f2.close();
 	 	   }catch(IOException ep) {
 	 		   
 	 	   }
 	    }
 	 		
 		
	    f1=new File("Adjustment.txt");
 	    if(f1.exists()) {
 	    	
 	 	   try {
 	 		FileReader  f2=new FileReader("Adjustment.txt");
 	 		 
 	 		int i=0;
 	 		char c;
 	 		String temp1="";
 			    String temp2="";
 			   int flag=0;
 			   int count=1;
 			   int k=0;
 	 		  while((i=f2.read())!=-1) {
 	 	 			
 				   c=(char)i;
 				   if(i==124) {
 					 flag=1; 
 				
 				   }
 				   else if(flag==1) {
 					   if(i>=48 && i<=57) {
 						  temp1=temp1.concat(Character.toString(c));
 						 System.out.println("Temp = "+temp1);
 	 					   model4.setValueAt(temp1, k, 1);
 	 					   k++;
 	 				
 					   }
 					   else {
 						temp1="";
 					   flag=0;
 					   }
 					   
 				   }
 				 
 	 		  }
 	 		  f2.close();
 	 	   }catch(IOException ep) {
 	 		   
 	 	   }
 	    }
 	
    

	//Adding drop-down menus
	 TableColumn testColumn = parameter.getColumnModel().getColumn(1);
     JComboBox<String> comboBox = new JComboBox<>();
     comboBox.addItem("Extra Low");
     comboBox.addItem("Very Low");
     comboBox.addItem("Low");
     comboBox.addItem("Nominal");
     comboBox.addItem("High");
     comboBox.addItem("Very High");
     comboBox.addItem("Extra High");
     testColumn.setCellEditor(new DefaultCellEditor(comboBox));
	
     TableColumn testColumn2 = parameter2.getColumnModel().getColumn(1);
     JComboBox<String> comboBox2= new JComboBox<>();
     comboBox2.addItem("Very Low");
     comboBox2.addItem("Low");
     comboBox2.addItem("Nominal");
     comboBox2.addItem("High");
     comboBox2.addItem("Very High");
     comboBox2.addItem("Extra High");
     testColumn2.setCellEditor(new DefaultCellEditor(comboBox2));
     
     TableColumn testColumn3 = parameter3.getColumnModel().getColumn(1);
     JComboBox<String> comboBox3= new JComboBox<>();
     comboBox3.addItem("0");
     comboBox3.addItem("1");
     comboBox3.addItem("2");
     comboBox3.addItem("3");
     comboBox3.addItem("4");
     comboBox3.addItem("5");
     testColumn3.setCellEditor(new DefaultCellEditor(comboBox3));
     
     //Adding button to add row in the table
    /* JButton addrow=new JButton("Add Row");
    addrow.setFont(new Font("Calibri", 2, 16));
		addrow.setBackground(new Color(204, 204, 255));
		addrow.setForeground(Color.black);
		addrow.setBounds(40, 350, 120, 30);
		addrow.setToolTipText("Click to add row in the table");
		pa_frame.add(addrow);
    parameter.setEnabled(true);
  addrow.addActionListener(new ActionListener() {
          @Override
           public void actionPerformed(final ActionEvent e) {
        	  Object []o = new Object[1];
        		o[0]="";
        		model2.addRow(o);
           }
       });*/
  
  //Adding save button
  JButton save=new JButton("Save");
  save.setFont(new Font("Calibri", 2, 16));
	save.setBackground(new Color(204, 204, 255));
		save.setForeground(Color.black);
		save.setBounds(460, 250, 120, 30);
		save.setToolTipText("Click to save data in the tables");
		pa_frame.add(save);
		save.addActionListener(new ActionListener() {
        @Override
         public void actionPerformed(final ActionEvent e) {
      	 //Read data from the table and store it in a file
        	
        	int num=parameter.getRowCount();
        	System.out.println("Row count is: "+num);
        	try {
        		BufferedWriter b1=null;
        		b1=new BufferedWriter(new FileWriter("Multiplier.txt", false));
        	for(int i=0;i<num;i++) {
        		String s1=parameter.getValueAt(i, 0).toString();
        		String s2=parameter.getValueAt(i, 1).toString();
        		double s3=0;
        		if((s1.compareTo("RUSE (Reuse required)"))==0) {
        			System.out.println("RUSE");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=1;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1;
        			else if((s2.compareTo("Low"))==0)
        				s3=0.95;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=1.07;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.15;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=1.24;
        		}
        		else if((s1.compareTo("PERS (Personnel Capability)"))==0) {
        			System.out.println("PERS");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=2.12;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1.62;
        			else if((s2.compareTo("Low"))==0)
        				s3=1.26;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=0.83;
        			else if((s2.compareTo("Very High"))==0)
        				s3=0.63;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.50;
        		}
        		else if((s1.compareTo("RCPX (Product Reliability and Complexity)"))==0) {
        			System.out.println("RCPX");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=0.49;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=0.60;
        			else if((s2.compareTo("Low"))==0)
        				s3=0.83;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=1.33;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.91;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=2.72;
        		}
        		else if((s1.compareTo("PREX (Personnel Experience)"))==0) {
        			System.out.println("PREX");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=1.59;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1.33;
        			else if((s2.compareTo("Low"))==0)
        				s3=1.12;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=0.87;
        			else if((s2.compareTo("Very High"))==0)
        				s3=0.74;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.62;
        		}
        		else if((s1.compareTo("FCIL (Support Facilities)"))==0) {
        			System.out.println("FCIL");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=1.43;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1.30;
        			else if((s2.compareTo("Low"))==0)
        				s3=1.10;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=0.87;
        			else if((s2.compareTo("Very High"))==0)
        				s3=0.73;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.62;
        		}
        		else if((s1.compareTo("SCED (Schedule)"))==0) {
        			System.out.println("SCED");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=1;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1.43;
        			else if((s2.compareTo("Low"))==0)
        				s3=1.14;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=1;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=1;
        		}
        		else if((s1.compareTo("PDIF (Platform Difficulty)"))==0) {
        			System.out.println("PDIF");
        			if((s2.compareTo("Extra Low"))==0)
        				s3=1;
        			else if((s2.compareTo("Very Low"))==0)
        				s3=1;
        			else if((s2.compareTo("Low"))==0)
        				s3=0.87;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=1;
        			else if((s2.compareTo("High"))==0)
        				s3=1.29;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.81;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=2.61;
        		}
        		
        		System.out.println("Entry is: "+s1+" "+s2+" "+s3);
        		String s4=String.valueOf(s3);
        		b1.write(s1+"|"+s2+"|"+s4+" ");
        		b1.newLine();
        	}
        	b1.close();
        	b1=new BufferedWriter(new FileWriter("ScaleFactor.txt", false));
        	num=parameter2.getRowCount();
        	System.out.println("Row count is: "+num);
        	for(int i=0;i<num;i++) {
        		String s1=parameter2.getValueAt(i, 0).toString();
        	double s3=0;
        		String s2=parameter2.getValueAt(i, 1).toString();
        		if((s1.compareTo("Precedentedness"))==0) {
        			if((s2.compareTo("Very Low"))==0)
        				s3=6.20;
        			else if((s2.compareTo("Low"))==0)
        				s3=4.96;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=3.72;
        			else if((s2.compareTo("High"))==0)
        				s3=2.48;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.24;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.00;
        		}
        		else if((s1.compareTo("Development Flexibility"))==0) {
        			if((s2.compareTo("Very Low"))==0)
        				s3=5.07;
        			else if((s2.compareTo("Low"))==0)
        				s3=4.05;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=3.04;
        			else if((s2.compareTo("High"))==0)
        				s3=2.03;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.01;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.00;
        		}
        		else if((s1.compareTo("Architecture or Risk Resolution"))==0) {
        			if((s2.compareTo("Very Low"))==0)
        				s3=7.07;
        			else if((s2.compareTo("Low"))==0)
        				s3=5.65;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=4.24;
        			else if((s2.compareTo("High"))==0)
        				s3=2.83;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.41;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.00;
        		}
        		else if((s1.compareTo("Team Cohesion"))==0) {
        			if((s2.compareTo("Very Low"))==0)
        				s3=5.48;
        			else if((s2.compareTo("Low"))==0)
        				s3=4.38;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=3.29;
        			else if((s2.compareTo("High"))==0)
        				s3=2.19;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.10;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.00;
        		}
        		else if((s1.compareTo("Process Maturity"))==0) {
        			if((s2.compareTo("Very Low"))==0)
        				s3=7.80;
        			else if((s2.compareTo("Low"))==0)
        				s3=6.24;
        			else if((s2.compareTo("Nominal"))==0)
        				s3=4.68;
        			else if((s2.compareTo("High"))==0)
        				s3=3.12;
        			else if((s2.compareTo("Very High"))==0)
        				s3=1.56;
        			else if((s2.compareTo("Extra High"))==0)
        				s3=0.00;
        		}
        		System.out.println("Entry is: "+s1+" "+s2+" "+s3);
        		String s4=String.valueOf(s3);
        		b1.write(s1+"|"+s2+"|"+s4);
        		b1.newLine();
        	}
        	b1.close();
        	b1=new BufferedWriter(new FileWriter("Adjustment.txt", false));
        	num=parameter3.getRowCount();
        	System.out.println("Row count is: "+num);
        	for(int i=0;i<num;i++) {
        		String s1=parameter3.getValueAt(i, 0).toString();
        		String s2=parameter3.getValueAt(i, 1).toString();
        		System.out.println("Entry is: "+s1+" "+s2);
        		b1.write(s1+"|"+s2);
        		b1.newLine();
        	}
        	b1.close();
        	}catch(IOException ez) {
        		
        	}
         }
     });
     
     
       pa_frame.setVisible(true);
    }
    //Module to add FP estimates
    static Node g, frhead;
    public static void addFPValues() {
    	
    	//Create FR List
    	
    	int c=countfr;
    	 frhead=null;
    	int i=1;
    	while(i<=c) {
    		String frname="f"+i;
    	
    				Node temp=new Node();
    				temp.id=frname;
    				temp.next=null;
    				if(frhead==null)
    					frhead=temp;
    				else {
    					Node p=frhead;
    					while(p.next!=null) {
    						p=p.next;
    					}
    					p.next=temp;
    				}
    		
    		i++;
    	}
    	Node p=frhead;
    	while(p!=null) {
    		System.out.println(p.id);
    		p=p.next;
    	}
    	
    //	System.out.println("hii I am here!");
    	fp_frame.getContentPane().setBackground(new Color(204, 204, 204));
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch (Exception e) {
            System.out.println("Look and Feel not set");
        }
        fp_frame.setLayout(null);
        fp_frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       fp_frame.setBounds(15, 6, 540, 450);
       
       JLabel heading1=new JLabel("Set values of Function-point attributes!!");
       heading1.setFont(new Font("Calibri", 2, 18));
       heading1.setBounds(20, 10, 500, 40);
       fp_frame.add(heading1);
       g=frhead;
       String t="Module "+g.id;
      JLabel  heading2=new JLabel(t);
      heading2.setFont(new Font("Calibri", 2, 18));
      heading2.setBounds(160, 60, 500, 40);
      fp_frame.add(heading2);
       
       
      JTable parameter;
  
       String []col2={"Attribute","Count","Complexity Rank"};
       String [][]data2=null;
   	 	DefaultTableModel model2 = new DefaultTableModel(data2,col2);  
   	 	parameter=new JTable(model2);
   		parameter.setFillsViewportHeight(true);
   		
   	parameter.setRowHeight(30);
    parameter.getColumnModel().getColumn(0).setPreferredWidth(150);
    parameter.getColumnModel().getColumn(1).setPreferredWidth(20);
		JScrollPane js2=new JScrollPane(parameter);
		  js2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		   //js2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		  js2.setBounds(25, 95, 400, 200);
		js2.setVisible(true);
		//jp2.add(js2);
	fp_frame.add(js2);
	//adding parameters to the table
	Object []o = new Object[1];
	o[0]="External Inputs";
	model2.addRow(o);
	o = new Object[1];
	o[0]="External Outputs";
	model2.addRow(o);
	o = new Object[1];
	o[0]="Inquiries";
	model2.addRow(o);
	o = new Object[1];
	o[0]="Files";
	model2.addRow(o);
	o = new Object[1];
	o[0]="External Interfaces";
	model2.addRow(o);
    
	//Adding drop-down menus
	 TableColumn testColumn = parameter.getColumnModel().getColumn(2);
     JComboBox<String> comboBox = new JComboBox<>();
     comboBox.addItem("Low");
     comboBox.addItem("Average");
     comboBox.addItem("High");
     
  
     testColumn.setCellEditor(new DefaultCellEditor(comboBox));
  
  //Adding next button
  JButton next=new JButton("Next");
  next.setFont(new Font("Calibri", 2, 16));
	next.setBackground(new Color(204, 204, 255));
		next.setForeground(Color.black);
		next.setBounds(40, 340, 120, 30);
		next.setToolTipText("Click to move to next FR!");
		fp_frame.add(next);
		next.addActionListener(new ActionListener() {
        @Override
         public void actionPerformed(final ActionEvent e) {
      	 
        	g=g.next;
        	parameter.setValueAt("", 0, 1);
        	parameter.setValueAt("", 0, 2);
        	if(g!=null) {
        	String t="Module "+g.id;
        	heading2.setText(t);
        	String fname=g.id+"attributes.txt";
        	File f1=new File(fname);
            System.out.println(f1.length());
            if(f1.exists()) {
            	System.out.println("File Exists");
            	try {
          		   FileReader f2=new FileReader(fname);
          		   int i=0;
          		   char c;
          		   String temp="";
          		  int j=0;
          		   while((i=f2.read())!=-1) {
          			   temp="";
          			   c=(char)i;
          			   temp=temp.concat(Character.toString(c));
          			   while((i=f2.read())!=32) {
          				   c=(char)i;
	          			   temp=temp.concat(Character.toString(c));
          			   }
          			   parameter.setValueAt(temp, j, 1);
          			   temp="";
          			   while((i=f2.read())!=32) {
          				   c=(char)i;
	          			   temp=temp.concat(Character.toString(c));
          			   }
          			   parameter.setValueAt(temp, j, 2);
          			   j++;
          			   i=f2.read();
          			   if(i==13)
          				   i=f2.read();  
          		   }
          		   f2.close();
            }catch(IOException ek) {
            	
            }
        	}
        
        	else {
        	//erasing values
        	parameter.setValueAt("", 0, 1);
        	parameter.setValueAt("", 0, 2);
        	parameter.setValueAt("", 1, 1);
        	parameter.setValueAt("", 1, 2);
        	parameter.setValueAt("", 2, 1);
        	parameter.setValueAt("", 2, 2);
        	parameter.setValueAt("", 3, 1);
        	parameter.setValueAt("", 3, 2);
        	parameter.setValueAt("", 4, 1);
        	parameter.setValueAt("", 4, 2);
        	}
        	}
        	else {
        		JOptionPane.showMessageDialog(fp_frame,"No more FR"); 
        	}
        	//func("Module F2");
        	}
        	
        	
         }
     );
     
		//Adding prev button
		
		JButton prev=new JButton("Prev");
		  prev.setFont(new Font("Calibri", 2, 16));
			prev.setBackground(new Color(204, 204, 255));
				prev.setForeground(Color.black);
				prev.setBounds(200, 340, 120, 30);
				prev.setToolTipText("Click to move to previous FR!");
				fp_frame.add(prev);
				prev.addActionListener(new ActionListener() {
		        @Override
		         public void actionPerformed(final ActionEvent e) {
		        	Node m=frhead;
		        	while(m!=null)
		        	{
		        		if(m.next==g)
		        			break;
		        		m=m.next;
		        		
		        	}
		        	g=m;
		        	String t="Module "+g.id;
		        	heading2.setText(t);
		        	String fname=g.id+"attributes.txt";
		        	File f1=new File(fname);
		            System.out.println("length="+f1.length());
		            if(f1.exists()) {
		            	try {
		          		   FileReader f2=new FileReader(fname);
		          		   int i=0;
		          		   char c;
		          		   String temp="";
		          		  int j=0;
		          		   while((i=f2.read())!=-1) {
		          			   temp="";
		          			   c=(char)i;
		          			   temp=temp.concat(Character.toString(c));
		          			   while((i=f2.read())!=32) {
		          				   c=(char)i;
			          			   temp=temp.concat(Character.toString(c));
		          			   }
		          			   parameter.setValueAt(temp, j, 1);
		          			   temp="";
		          			   while((i=f2.read())!=32) {
		          				   c=(char)i;
			          			   temp=temp.concat(Character.toString(c));
		          			   }
		          			   parameter.setValueAt(temp, j, 2);
		          			   j++;
		          			   i=f2.read();
		          			   if(i==13)
		          				   i=f2.read();  
		          		   }
		          		   f2.close();
		            }catch(IOException ek) {
		            	
		            }
		        	}
		        }
		        	
		         }
		     );
		    
				
		//Adding save button
		  JButton save=new JButton("Save");
		  save.setFont(new Font("Calibri", 2, 16));
			save.setBackground(new Color(204, 204, 255));
				save.setForeground(Color.black);
				save.setBounds(350, 340, 120, 30);
				save.setToolTipText("Click to save data");
				fp_frame.add(save);
				save.addActionListener(new ActionListener() {
		        @Override
		         public void actionPerformed(final ActionEvent e) {
		      	 //Read data from the table and store it in a file
		        	BufferedWriter b1=null;
		    		try {
		    			String fname=g.id+"attributes.txt";
		    	 		 b1 = new BufferedWriter(new FileWriter(fname, false));
		    	 		 String t=String.valueOf(parameter.getValueAt(0, 1));
		    	 		 String k=String.valueOf(parameter.getValueAt(0,2));
		    	 		 b1.write(t+" "+k+" ");
		    	 		 b1.newLine();
		    	 		 t=String.valueOf(parameter.getValueAt(1, 1));
		    	 		  k=String.valueOf(parameter.getValueAt(1,2));
		    	 		 b1.write(t+" "+k+" ");
		    	 		 b1.newLine();
		    	 		 t=String.valueOf(parameter.getValueAt(2, 1));
		    	 		  k=String.valueOf(parameter.getValueAt(2,2));
		    	 		 b1.write(t+" "+k+" ");
		    	 		 b1.newLine();
		    	 		 t=String.valueOf(parameter.getValueAt(3, 1));
		    	 		  k=String.valueOf(parameter.getValueAt(3,2));
		    	 		 b1.write(t+" "+k+" ");
		    	 		 b1.newLine();
		    	 		 t=String.valueOf(parameter.getValueAt(4, 1));
		    	 		  k=String.valueOf(parameter.getValueAt(4,2));
		    	 		 b1.write(t+" "+k+" ");
		    	 		 b1.newLine();
		    	 		 b1.close();
		    	 	}catch(IOException fe) {
		    	 		
		    	 	}
		        	}
		        	
		        	
		         }
		     );	
     
       fp_frame.setVisible(true);
    
    }
    //Module to compute effort estimate
    public static void effortCal() {
    	int a1=0, a2=0, a3=0, a4=0, a5=0;
    	double m=1, adjustment=0, b=0;
    	String c1="", c2="", c3="", c4="", c5="";
    	double total=0,fpt=0;;
    //Fetching multipliers
    	File f1=new File("Multiplier.txt");
        if(f1.exists()) {
        	
     	   try {
     		   FileReader f2=new FileReader("Multiplier.txt");
     		 
     		   int i=0;
     		   char c;
     		  String temp1="";
    		   String temp2="";
    		   int flag=0;
    		   int flag2=0;
    		   int count=1;
    		   int k=0;
     		  while((i=f2.read())!=-1) {
     	 			
    			   c=(char)i;
    			   if(i==124 && count==1) {
    				 flag=1; 
    				 count=2;
    			   }
    			   else if(i==124 && count==2) {
    				   flag=0;
    				   count=1;
    				   //System.out.println("Temp = "+temp1);
    				  // model2.setValueAt(temp1, k, 1);
    				//   k++;
    				   temp1="";
    				   flag2=1;
    			   }
    			   else if(flag==1) {
    				   temp1=temp1.concat(Character.toString(c));
    			   }
    			   else if(flag2==1) {
 
    				   if((i>=48 && i<=57)||i==46) {
    	   				   System.out.println("c= "+c);
    					   temp2=temp2.concat(Character.toString(c));
    					   flag2=1;
    				   }
    					
    					 else {
    						   System.out.println("Temp2 = "+temp2);
    						   flag2=0;
    						   m=m*Double.parseDouble(temp2);
    						   temp2="";
    					 }
    			   }
    			 
     		  }
     		 System.out.println("The multiplier value is "+m);
     		  f2.close();
     	   }catch(IOException es) {
     		   
     	   }
        }
     		  	
    	
       else
       {
       	JOptionPane.showMessageDialog(po_frame, "Project multipliers not set");	
       }
        
        //Fetching scale factors
        f1=new File("ScaleFactor.txt");
        if(f1.exists()) {
        	
     	   try {
     		   FileReader f2=new FileReader("ScaleFactor.txt");
     		 
     		   int i=0;
     		   char c;
     		  String temp1="";
    		   String temp2="";
    		   int flag=0;
    		   int flag2=0;
    		   int count=1;
    		   int k=0;
     		  while((i=f2.read())!=-1) {
     	 			
    			   c=(char)i;
    			   if(i==124 && count==1) {
    				 flag=1; 
    				 count=2;
    			   }
    			   else if(i==124 && count==2) {
    				   flag=0;
    				   count=1;
    				   //System.out.println("Temp = "+temp1);
    				  // model2.setValueAt(temp1, k, 1);
    				//   k++;
    				   temp1="";
    				   flag2=1;
    			   }
    			   else if(flag==1) {
    				   temp1=temp1.concat(Character.toString(c));
    			   }
    			   else if(flag2==1) {
 
    				   if((i>=48 && i<=57)||i==46) {
    	   				   System.out.println("c= "+c);
    					   temp2=temp2.concat(Character.toString(c));
    					   flag2=1;
    				   }
    					
    					 else {
    						   System.out.println("Temp2 = "+temp2);
    						   flag2=0;
    						  b=b+Double.parseDouble(temp2);
    						   temp2="";
    					 }
    			   }
    			 
     		  }
     		  System.out.println("The adjustment value is "+adjustment);
     		  f2.close();
     	   }catch(IOException es) {
     		   
     	   }
        }
     		  	
    	
       else
       {
       	JOptionPane.showMessageDialog(po_frame, "Scale factors not set");	
       }
 
        f1=new File("Adjustment.txt");
 	    if(f1.exists()) {
 	    	
 	 	   try {
 	 		FileReader  f2=new FileReader("Adjustment.txt");
 	 		 
 	 		int i=0;
 	 		char c;
 	 		String temp1="";
 			    String temp2="";
 			   int flag=0;
 			   int count=1;
 			   int k=0;
 	 		  while((i=f2.read())!=-1) {
 	 	 			
 				   c=(char)i;
 				   if(i==124) {
 					 flag=1; 
 				
 				   }
 				   else if(flag==1) {
 					   if(i>=48 && i<=57) {
 						  temp1=temp1.concat(Character.toString(c));
 						 System.out.println("Temp = "+temp1);
 	 					 //  model4.setValueAt(temp1, k, 1);
 	 					   k++;
 	 					
 					   }
 					   else {
 						   adjustment=adjustment+Integer.valueOf(temp1);
 						   temp1="";
 					   flag=0;
 					   }
 					   
 				   }
 				 
 	 		  }
 	 		  f2.close();
 	 	   }catch(IOException ep) {
 	 		   
 	 	   }
 	    }
 	   else
       {
       	JOptionPane.showMessageDialog(po_frame, "Adjustment factors not set");	
       }
       System.out.println("M = "+m+" B= "+b+" Adjustment= "+adjustment);
    	plist k=combo;
    	while(k!=null) {
    	sNode r=k.begin;
    	k.extra=0;
     fpt=0;
    	while(r!=null) {
    	total=0;
    	String fname=r.id+"attributes.txt";
    	f1=new File(fname);
        if(f1.exists()) {
        	try {
      		   FileReader f2=new FileReader(fname);
      		   int i=0;
      		   char c;
      		   String temp="";
      		  int j=0;
      		  int v=1;
      		  //Loop to read the count and complexity rank
      		   while((i=f2.read())!=-1) {
      			   temp="";
      			   c=(char)i;
      			   temp=temp.concat(Character.toString(c));
      			   while((i=f2.read())!=32) {
      				   c=(char)i;
          			   temp=temp.concat(Character.toString(c));
      			   }
      			   //Setting the count
      			   if(v==1)
      				   a1=Integer.valueOf(temp);
      			   else if(v==2)
      				  a2=Integer.valueOf(temp);
      			  else if(v==3)
      				  a3=Integer.valueOf(temp);
      			  else if(v==4)
      				  a4=Integer.valueOf(temp);
      			  else if(v==5)
      				  a5=Integer.valueOf(temp);
      			   temp="";
      			   
      			   while((i=f2.read())!=32) {
      				   c=(char)i;
          			   temp=temp.concat(Character.toString(c));
      			   }
      		
      			   //Setting the complexity rank
      			 if(v==1)
    				   c1=temp;
    			   else if(v==2)
    				  c2=temp;
    			  else if(v==3)
    				  c3=temp;
    			  else if(v==4)
    				  c4=temp;
    			  else if(v==5)
    				  c5=temp;
      			 
      			   v++;
      			   i=f2.read();
      			   if(i==13)
      				   i=f2.read();  
      		   }
      		   f2.close();
        }catch(IOException ek) {
        	
        }
        	//Calculating the total function point
        	//External Input
        	if((c1.compareTo("Low"))==0)
        		total=total+a1*3;
        	else if((c1.compareTo("Average"))==0)
        		total=total+a1*4;
        	else
        		total=total+a1*5;
        	//External Output
        	if((c2.compareTo("Low"))==0)
        		total=total+a2*4;
        	else if((c2.compareTo("Average"))==0)
        		total=total+a2*5;
        	else
        		total=total+a2*7;
        	//Inquiries
        	if((c3.compareTo("Low"))==0)
        		total=total+a3*3;
        	else if((c3.compareTo("Average"))==0)
        		total=total+a3*4;
        	else
        		total=total+a3*6;
        	//Files
        	if((c4.compareTo("Low"))==0)
        		total=total+a4*7;
        	else if((c4.compareTo("Average"))==0)
        		total=total+a4*10;
        	else
        		total=total+a4*15;
        	//Interfaces
           	if((c5.compareTo("Low"))==0)
        		total=total+a5*5;
        	else if((c5.compareTo("Average"))==0)
        		total=total+a5*7;
        	else
        		total=total+a5*10;
           	
           	System.out.println("Total FP= "+total);
           	
         		   
         	   }
	        else {
	        	JOptionPane.showMessageDialog(po_frame, "Function-point attributes not set");
	        }
    	fpt=fpt+total;
   	 r=r.next;  
            }
    
   
    	 
    	
    		k.extra2=fpt;
		   //adjusting the FP estimate
		   adjustment=fpt*(0.65+(0.01*adjustment));
		   System.out.println("after adjusting "+adjustment);
		   fpt=adjustment*128;
		   fpt=fpt/1000;
			 System.out.println("Code Length "+fpt);
		   //Mutiplying with code size
		   //total=total*128;
		   //Finding effort
			 b=0.91+0.01*b;
		 double effort=2.94*(Math.pow(fpt, b))*m;
		 //System.out.println("Total= "+effort);
		effort= Math.round(effort * 100.0) / 100.0;
		  System.out.println("Effort is "+effort+" person-month");
    	 k.extra=effort;
    	k=k.next;
    	}
    } 	
    	
    	
    //Module to create partial order generation interface
    public static void POframe() {
    	  po_frame.getContentPane().setBackground(new Color(224, 224, 224));
          try {
              UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
          }
          catch (Exception e) {
              System.out.println("Look and Feel not set");
          }
          po_frame.setLayout(null);
          po_frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         po_frame.setBounds(15, 6, 1100, 825);
          /*section of NFR Priority*/
          JLabel heading1=new JLabel("Set NFR Priority");
          heading1.setFont(new Font("Calibri", 2, 18));
          heading1.setBounds(20, 10, 200, 40);
          po_frame.add(heading1);
          
          String []col2={"NFR","Priority"};
        	String [][]data2=null;
        	 DefaultTableModel model2 = new DefaultTableModel(data2,col2);  
        	NFR_priority=new JTable(model2){
        	    @Override
        	    public boolean isCellEditable(int row, int column) {                
        	        return (column==1);               
        	    };
        	};
        	NFR_priority.setFillsViewportHeight(true);
  		JScrollPane js2=new JScrollPane(NFR_priority);
  		  js2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
  		   //js2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
  		  js2.setBounds(40, 105, 170, 220);
  		js2.setVisible(true);
  		//jp2.add(js2);
  	po_frame.add(js2);
  		
          loadNFR.setFont(new Font("Calibri", 2, 16));
          loadNFR.setBackground(new Color(204, 204, 255));
          loadNFR.setForeground(Color.black);
          loadNFR.setBounds(20, 60, 100, 30);
          loadNFR.setToolTipText("Click to load NFRs");
         po_frame.add(loadNFR);
          
           /* call a function to add items from a list if exists*/
         loadNFR.addActionListener(new ActionListener() {
                @Override
                 public void actionPerformed(final ActionEvent e) {
                	 try {
                     FileReader	f1=new FileReader("NFR.txt");
                     	int i;
                     	char c;
                     	String temp;
                     	String fe1,fe2,fe3;
                     	while((i=f1.read())!=-1) {
                     		
                     		c=(char)i;
                     		System.out.println("C="+c);
                     		temp="";
                     		if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
                     			temp=temp.concat(Character.toString(c));
                     		System.out.println("i="+i);
                     		while((i=f1.read())!=10 && i != 10 && i != 13 && i!=-1) {
                     			c=(char)i;
                     			if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
                     				temp=temp.concat(Character.toString(c));
                     			System.out.println("i="+i);
                     			while((i=f1.read())!=32) {
                     				c=(char)i;
                     				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
                     					temp=temp.concat(Character.toString(c));
                     				System.out.println("i="+i);
                     			}
                     			fe1=temp;
                     			temp="";
                     			while((i=f1.read())!=32) {
                     				c=(char)i;
                     				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
                     					temp=temp.concat(Character.toString(c));
                     				System.out.println("i="+i);
                     			}
                     			fe2=temp;
                     			System.out.println("Fetched is");
                     			System.out.println(fe1+" | "+fe2);
                     			DefaultTableModel model = (DefaultTableModel)NFR_priority.getModel();
                 				Object []o = new Object[2];
                 				o[0]=fe1;
                 				o[1]=fe2;
                 				model.addRow(o);
                     		}
                     	}
                     	f1.close();
                     	}
                 	
                     	catch(IOException i) {
                     		
                     	}
             	  Node p=NFR;
             	  if(p!=null) {
             		  while(p!=null) {
             			int num=NFR_priority.getRowCount();
             			int found=0;
             			for(int j=0;j<num;j++) {
             				String s=NFR_priority.getValueAt(j, 0).toString();
             				if((s.compareTo(p.id))==0)
             					found=1;
             			}
             			if(found==0) {
             			DefaultTableModel model = (DefaultTableModel)NFR_priority.getModel();
           				Object []o = new Object[2];
           				o[0]=p.id;
           				o[1]="";
           				model.addRow(o);
             			 
             		  }
             			else {
             				System.out.println("already exists"+p.id);
             			}
             			 p=p.next;
             		  }
             	  }
             	  else {
             		  JOptionPane.showMessageDialog(po_frame,"No saved data"); 
             	  }
                 }
             });
         
        //Button to save NFR priority values
		savePriority.setFont(new Font("Calibri", 2, 16));
		savePriority.setBackground(new Color(204, 204, 255));
		savePriority.setForeground(Color.black);
		savePriority.setBounds(140, 60, 120, 30);
		savePriority.setToolTipText("Click to save the NFR Priorities!");
		po_frame.add(savePriority);
       
        /* call a function to add items from a list if exists*/
        savePriority.addActionListener(new ActionListener() {
             @Override
              public void actionPerformed(final ActionEvent e) {
                setPriority();
              }
          });
        
        //Section for adding parameters
        
        (label8 = new JLabel("Select a Parameter")).setFont(new Font("Calibri", 2, 18));
        label8.setBounds(20, 330, 200, 40);
        po_frame.add(label8);
        final ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(conflict);
        buttonGroup.add(priority);
        buttonGroup.add(both);
        buttonGroup.add(both2);
        buttonGroup.add(nc);
        conflict.setFont(new Font("Calibri", 2, 16));
        conflict.setBounds(20, 370, 100, 40);
        po_frame.add(conflict);
        
        priority.setFont(new Font("Calibri", 2, 16));
        priority.setBounds(20, 400, 130, 40);
        po_frame.add(priority);
        both.setFont(new Font("Calibri", 2, 16));
        both.setBounds(20, 430, 130, 40);
        both.setToolTipText("Product of NFR Conflict and NFR Priority");
        po_frame.add(both);
        both2.setFont(new Font("Calibri", 2, 16));
        both2.setBounds(20, 460, 130, 40);
        both2.setToolTipText("Weighted sum of NFR Conflict and NFR Priority");
        po_frame.add(both2);
        (label2 = new JLabel("Specify weights:")).setFont(new Font("Calibri", 2, 14));
        label2.setBounds(20, 494, 100, 40);
       po_frame.add(label2);
        slider1.setMajorTickSpacing(1);
        slider1.setMinorTickSpacing(1);
        slider1.setBackground(new Color(153, 204, 255));
        slider1.setPaintLabels(true);
        slider1.setPaintTicks(true);
        slider1.setPreferredSize(new Dimension(200, 46));
        final Format f = new DecimalFormat("0.0");
        final Hashtable<Integer, JComponent> labels = new Hashtable<Integer, JComponent>();
        for (int i = 0; i <= 10; ++i) {
            final JLabel label = new JLabel(f.format(i * 0.1));
            label.setFont(new Font("Calibri", 1, 16));
            labels.put(i, label);
        }
        JLabel l1=new JLabel("Conflict");
        JLabel l2=new JLabel("NFR Priority");
        l1.setFont(new Font("Calibri", 2, 13));
        l1.setBounds(20, 530, 80, 40);
        po_frame.add(l1);
        l2.setFont(new Font("Calibri", 2, 13));
        l2.setBounds(315, 530, 80, 40);
        po_frame.add(l2);
        slider1.setLabelTable(labels);
        slider1.setBounds(60, 540, 250, 50);
        po_frame.add(slider1);
        submit.setFont(new Font("Calibri", 2, 16));
        submit.setBounds(30, 594, 100, 30);
        submit.setBackground(new Color(204, 204, 255));
        submit.setForeground(Color.black);
        submit.setToolTipText("Click to submit the parameter selected!");
        po_frame.add(submit);
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                setChoice();
            }
        });
        
        //Optimal Partial order generation buttons
        
        label3 = new JLabel("Generate Partial Order");
        label3.setFont(new Font("Calibri", 2, 18));
        label3.setBounds(400, 10, 200, 40);
        po_frame.add(label3);
        
        generate.setFont(new Font("Calibri", 2, 16));
        generate.setBackground(new Color(204, 204, 255));
        generate.setForeground(Color.black);
        generate.setBounds(420, 60, 200, 30);
        generate.setToolTipText("Click to Generate Optimal Partial Order");
       po_frame.add(generate);
        viewgraph.setFont(new Font("Calibri", 2, 16));
        viewgraph.setBackground(new Color(204, 204, 255));
        viewgraph.setForeground(Color.black);
        viewgraph.setBounds(700, 60, 200, 30);
       viewgraph.setToolTipText("Click to View Optimal Partial Order as Graph");
        po_frame.add(viewgraph);
        
        scrollPane1.setVerticalScrollBarPolicy(22);
        scrollPane1.setHorizontalScrollBarPolicy(32);
        scrollPane1.setBounds(400, 110, 550, 150);
        textOrder1.setFont(new Font("Calibri", 2, 20));
        textOrder1.setEditable(false);
        po_frame.add(scrollPane1);
   
        generate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (choice == 0) {
                    JOptionPane.showMessageDialog(po_frame, "Select a parameter");
                }
                else {
               	 if(FR!=null) {
               		Node p=NFR;
               		if(p.priority!=0) {
               	 create_BasicClusters();
               	 display_BasicClusters();
               	 create_MacroClusters();
               	 display_MacroClusters();
               	 create_requirementSet();
               	 wn=null;wd=null;
                    generate_PartialOrderNew();
                    remove_transitive();
                    exist_path();
                    display_PartialOrder();
                    setText();
               
                   setOrderInFrame();
                   show_matrix();
                 
               		}
               		else {
               			 JOptionPane.showMessageDialog(po_frame, "NFR priority not saved");
               		}
               	 }
               	 else {
               		 JOptionPane.showMessageDialog(po_frame, "Data not saved"); 
               	 }
                }
            }
        });
        viewgraph.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (proot == null) {
                    JOptionPane.showMessageDialog(po_frame, "Generate Partial Order at first");
                }
                else {
                 drawGraph();
                }
            }
        });
        
        
        //Alternate Partial order generation buttons
        generate2.setFont(new Font("Calibri", 2, 16));
        generate2.setBackground(new Color(204, 204, 255));
        generate2.setForeground(Color.black);
        generate2.setBounds(420, 290, 200, 30);
        generate2.setToolTipText("Click to Generate Alternate Partial Order");
  po_frame.add(generate2);
        
        generate2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
           	 
           	 if (choice == 0) {
                    JOptionPane.showMessageDialog(po_frame, "Select a parameter");
                }
           	 else {
           	if(FR==null) {
           		 JOptionPane.showMessageDialog(po_frame, "Save Data");
           	}
           	else {
           	if(Fro==null) {
           		JOptionPane.showMessageDialog(po_frame, "Select Requirements to freeze");
           	}
           	else {
           	if(FR==null || NFR==null || E_FN==null || E_NN==null) {
           		JOptionPane.showMessageDialog(po_frame, "Data not saved");
           	}
           	else {
           	Node p=NFR;
           	if(p.priority==0) {
           		JOptionPane.showMessageDialog(po_frame, "NFR priority not saved");
           	}
           	else {
           	if(prevFro!=null) {
           		Node m=prevFro;
           		while(m!=null) {
           			Node t=new Node();
           			t.id=m.id;
           			t.next=null;
           			if(Fro!=null) {
           			Node f=Fro;
           			int flag=0;
           			while(f.next!=null) {
           				if((f.id.compareTo(t.id))==0)
           					flag=1;
           				f=f.next;
           			}
           			if((f.id.compareTo(t.id))==0)
       					flag=1;
           			if(flag==0)
           				f.next=t;
           			}
           			else
           				Fro=t;
           			m=m.next;
           			
           		}
           	}
           	System.out.println("The frozen set are");
           	Node v=Fro;
           	while(v!=null) {
           		System.out.println("Fro="+v.id);
           		v=v.next;
           	}
           	 recreate_basicClusters();
           	 recreate_macroClusters();
           	 recreate_FRList();
           	 recreate_requirementSet();
           	 recreate_PO();
           	 Reremove_transitive();
           	 //display_PartialOrder2();
           	 obtain_source();
           	 create_frozenrequirementset();
           	 create_frozenPO();
           	 remove_frozentransitive();
           	 find_sink();
           	 add_remainEdge();
           	 Reexist_path();
           	 display_PartialOrder2();
           
           	 PO t1=proot2;
           	 while(t1!=null) {
           		 PO t2=proot2;
           		 int count=0;
           		 while(t2!=null) {
           			 if((t1.id1.compareTo(t2.id1))==0)
           			 {
           				 if((t1.id2.compareTo(t2.id2))==0) 
           					count++;
           			 }
           				 t2=t2.next;
           		 }
           		 System.out.println("Count for "+t1.id1+"->"+t1.id2+"is : "+count);
           		 if(count>1) {
           			 PO t3=proot2;
           			 PO t4=t3;
           			 while(t3!=null) {
           				 if((t1.id1.compareTo(t3.id1))==0 && ((t1.id2.compareTo(t3.id2))==0))
               			 {
               			 if(t3==proot2)
               			 {
               				 t3=t3.next;
               				 proot2=t3;
               			 }
               			 else if(t3.next==null){
               				 t4.next=null;
               			 }
               			 else {
               				 t3=t3.next;
               				 t4.next=t3;
               			 }
               			 break;
               			 }
           				 t4=t3;
           				 t3=t3.next;
           			 }
           		 }
           		 t1=t1.next;
           	 }
           	 setTextFro();
           	 setOrderInFrameFro();
           	
           
           	}
           	}
           	}
           	 }
            }
            } 
        });
        
        viewgraph2.setFont(new Font("Calibri", 2, 16));
        viewgraph2.setBackground(new Color(204, 204, 255));
        viewgraph2.setForeground(Color.black);
        viewgraph2.setBounds(700, 290, 200, 30);
        viewgraph2.setToolTipText("Click to View Alternate Partial Order as Graph");
       po_frame.add(viewgraph2);
        viewgraph2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
           	 if(proot2==null) {
           		 JOptionPane.showMessageDialog(po_frame, "Generate Partial Order at first");
           	 }
           	 else
           		 drawGraphFro();
            }
        });
        scrollPane2.setVerticalScrollBarPolicy(22);
        scrollPane2.setHorizontalScrollBarPolicy(32);
        scrollPane2.setBounds(400, 340, 550, 150);
        textOrder2.setFont(new Font("Calibri", 2, 20));
        textOrder2.setEditable(false);
        po_frame.add(scrollPane2);
        
        //Risk Analysis portion 
        
        JLabel l3=new JLabel("Perform Risk Analysis");
        l3.setFont(new Font("Calibri", 2, 18));
        l3.setBounds(400, 505, 200, 40);
        po_frame.add(l3);
        
        risk.setFont(new Font("Calibri", 2, 16));
        risk.setBackground(new Color(204, 204, 255));
        risk.setForeground(Color.black);
        risk.setBounds(420, 560, 200, 30);
        risk.setToolTipText("Click to Compare Optimal and Alternate partial Orders!");
        po_frame.add( risk);
        risk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
           	compare();
           	 
           	
            }
        });
        
        
        unfreeze.setFont(new Font("Calibri", 2, 16));
         unfreeze.setBackground(new Color(204, 204, 255));
          unfreeze.setForeground(Color.black);
          unfreeze.setBounds(900, 560, 100, 30);
          unfreeze.setToolTipText("Click to unfreeze requirements from previous iteartions!");
          po_frame.add(unfreeze);
          
        unfreeze.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
         
         	   JComboBox itr=new JComboBox();
         	   int v1=iteration-1;
         	   while(v1!=0) {
         		   itr.addItem(v1);
         		   v1--;
         	   }
         	 
         	   final JPanel panel1 = new JPanel();
         	   panel1.add(itr);
         
         	   
         	   JOptionPane.showMessageDialog(po_frame, panel1,"Select the particular iteration!",JOptionPane.OK_CANCEL_OPTION);
         	   int itn=Integer.valueOf(itr.getSelectedItem().toString());
         	  
         	   ComputeResults(itn);
         	  effortCal();
         	   JButton ViewR=new JButton("View Risk Analysis");
         	   ViewR.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(final ActionEvent e) {
                    	int c=0;
                 	   plist j=combo;
                 	   while(j!=null)
                 	   {
                 		   c++;
                 		   j=j.next;
                 	   }
                 	   c=c+1;
                 	   JPanel p1 = new JPanel(); 
                 	    p1.setLayout(new GridLayout(c, 2)); 
                 	    JLabel one = new JLabel("FRs"); 
                 	    JLabel two = new JLabel("Risk Reduction (%) "); 
                 	   JLabel three = new JLabel("Effort Incurred (PM) "); 
                 	  JLabel four = new JLabel("Total FP "); 
                  		 p1.add(one);
                  		 p1.add(two);
                  		p1.add(three);
                  		p1.add(four);
                 	    j=combo;
                  	   while(j!=null)
                  	   {
                  		   String s="";
                  		   sNode r=j.begin;
                  		   while(r!=null) {
                  			   s=s.concat(r.id+" ");
                  			   r=r.next;
                  		   }
                  		  one = new JLabel(s); 
                  		j.val = Math.round(j.val * 100.0) / 100.0;
                  		 two = new JLabel(String.valueOf(j.val));
                  		 three= new JLabel(String.valueOf(j.extra));
                  		 four=new JLabel(String.valueOf(j.extra2));
                  		 
                  		 p1.add(one);
                  		 p1.add(two);
                  		 p1.add(three);
                  		 p1.add(four);
                  		 
                  		   j=j.next;
                  	   }
                 	    
                  	  JOptionPane.showMessageDialog(po_frame, p1, "Risk Reduction Analysis",JOptionPane.NO_OPTION);  	   
             }});
         	   JRadioButton[] FRs=new JRadioButton[100];
         	   final JPanel panel = new JPanel();
         	  panel.add(ViewR);
         	   System.out.println("The contents of flist");
               plist p=flist;
           	while(p!=null) {
           		System.out.print(p.name+" : ");
           		sNode r=p.begin;
           		while(r!=null) {
           			System.out.print(r.id+" ");
           			r=r.next;
           		}
           		System.out.println();
           		p=p.next;
           	}
         	   plist tf=flist;
         	   while(tf!=null) {
         		   if(tf.name==itn) {
         			   sNode k=tf.begin;
         			   int j=0;
         			   while(k!=null) {
         				   System.out.println("k.id= "+k.id+" k.visited= "+k.visited+" k.flag="+k.flag);
         				   if(k.visited==1 && k.flag==0) {
         				   FRs[j]=new JRadioButton(k.id);
         				      panel.add(FRs[j]);
         				      j++;
         				   }
         				   k=k.next;
         			   }
         			   break;
         		   }
         		   tf=tf.next;
         	   }
         	
            
               
              
                JOptionPane.showMessageDialog(po_frame, panel, "Select Requirements to unfreeze",JOptionPane.OK_CANCEL_OPTION);
              //creating the list of Frs to unfreeze
             
                Node unlist=null;
                tf=flist;
         	   while(tf!=null) {
         		   if(tf.name==itn) {
         			   sNode k=tf.begin;
         			   int j=0;
         			   while(k!=null) {
         				   if(k.visited==1 && k.flag==0) {
         				   if(FRs[j].isSelected()) {
         					   Node tn=new Node();
         					   tn.id=k.id;
         					   tn.next=null;
         					   if(unlist==null)
         						   unlist=tn;
         					   else {
         						   Node j2=unlist;
         						   while(j2.next!=null)
         							   j2=j2.next;
         						   j2.next=tn;
         					   }
         					   //Already unfrozen will not appear in the list anymore
         					   k.flag=1;
         				   }
         					j++;   
         				   }
         				   k=k.next;
         			   }
         			   break;
         		   }
         		   tf=tf.next;
         	   }
         	   System.out.println("the Frs selected are");
         	   Node p2=unlist;
         	   while(p2!=null) {
         		   System.out.println(p2.id);
         		   p2=p2.next;
         	   }
           
                
         	  String s="";
             	if(unlist!=null) {
             		// Remove from frozen list
             		Node un=unlist;
             		while(un!=null) {
             			s=un.id;
             			Node t=prevFro;
             			 Node q=t;
                  		while(t!=null) {
                  			if((t.id.compareTo(s))==0)
                  				break;
                  			q=t;
                  			t=t.next;
                  		}
                  		if(q==prevFro)
                  			prevFro=t.next;
                  		else if(t.next==null)
                  			q.next=null;
                  		else {
                  			t=t.next;
                  			q.next=t;
                  		}
                  		un=un.next;
             		}
             		System.out.println("The frozen list is");
             		Node r=prevFro;
             		while(r!=null) {
             			System.out.println(r.id);
             			r=r.next;
             		}
             		 un=unlist;
              		while(un!=null) {
              			s=un.id;
              			int ftrue=1;
              			while(ftrue==1) {
              				
              			ftrue=0;
              			Node t=Fro;
              			 Node q=t;
              			 if(Fro!=null) {
              				while(t!=null) {
                   			if((t.id.compareTo(s))==0)
                   				break;
                   			q=t;
                   			t=t.next;
                   		}
                   		if(q==Fro)
                   			Fro=t.next;
                   		else if(t.next==null)
                   			q.next=null;
                   		else {
                   			t=t.next;
                   			q.next=t;
                   		}
              		 }
              			 t=Fro;
              			 while(t!=null) {
              				if((t.id.compareTo(s))==0)
              					ftrue=1;
              					t=t.next;
              			 }
              		}	 
                   		un=un.next;
              		}
              		System.out.println("After unfreezing the list is");
             		 r=Fro;
             		while(r!=null) {
             			System.out.println(r.id);
             			r=r.next;
             		}
             		int yes=0;
                  		//if(Fro!=null) {
                  			if(prevFro!=null) {
                         		Node m=prevFro;
                         		while(m!=null) {
                         			Node t2=new Node();
                         			t2.id=m.id;
                         			t2.next=null;
                         			if(Fro==null) {
                         				Fro=t2;
                         				yes=1;
                         			}
                         			else {
                         				Node k=Fro;
                         				int match=0;
                         				while(k.next!=null) {
                         					if((k.id.compareTo(t2.id))==0)
                         						match=1;
                         					k=k.next;
                         				}
                         				if((k.id.compareTo(t2.id))==0)
                     						match=1;
                         				if(match==0)
                         					k.next=t2;
                         			}
                         		
                         			m=m.next;
                         		}
                         	//}
                  			recreate_basicClusters();
                         	 recreate_macroClusters();
                         	 recreate_FRList();
                         	 recreate_requirementSet();
                         	 recreate_PO();
                         	 Reremove_transitive();
                         	 //display_PartialOrder2();
                         	 obtain_source();
                         	 create_frozenrequirementset();
                         	 create_frozenPO();
                         	 remove_frozentransitive();
                         	 find_sink();
                         	 add_remainEdge();
                         	 Reexist_path();
                         	 display_PartialOrder2();
                         	 PO t1=proot2;
                         	 while(t1!=null) {
                         		 PO t2=proot2;
                         		 int count=0;
                         		 while(t2!=null) {
                         			 if((t1.id1.compareTo(t2.id1))==0)
                         			 {
                         				 if((t1.id2.compareTo(t2.id2))==0) 
                         					count++;
                         			 }
                         				 t2=t2.next;
                         		 }
                         		 System.out.println("Count for "+t1.id1+"->"+t1.id2+"is : "+count);
                         		 if(count>1) {
                         			 PO t3=proot2;
                         			 PO t4=t3;
                         			 while(t3!=null) {
                         				 if((t1.id1.compareTo(t3.id1))==0 && ((t1.id2.compareTo(t3.id2))==0))
                             			 {
                             			 if(t3==proot2)
                             			 {
                             				 t3=t3.next;
                             				 proot2=t3;
                             			 }
                             			 else if(t3.next==null){
                             				 t4.next=null;
                             			 }
                             			 else {
                             				 t3=t3.next;
                             				 t4.next=t3;
                             			 }
                             			 break;
                             			 }
                         				 t4=t3;
                         				 t3=t3.next;
                         			 }
                         		 }
                         		 t1=t1.next;
                         	 }
                         	 compare3();
                         	 if(yes==1)
                         		 Fro=null;
             			}
             			
                      	//Re-calculate risk!!
                  		FileReader f1=null;
                  		try {
                  			String st="Conflicting Precedences that are removed are: \n";
                  			//int count=iteration-1;
                  			int found=0;
                  			String name="Iteration"+itn+".txt";
                  			f1=new FileReader(name);
                  			int total=0;
                  			int conflict=0;
                  			double risk=0;
                  			double impact=0;
                  			int num=0;
                  			int i;
                  			char c;
                  			System.out.println("Name is"+name);
                  			String temp="";
                  			while((i=f1.read())!=-1) {
                  				temp="";
                  				c=(char)i;
                  				temp=temp.concat(Character.toString(c));
                  				System.out.println("c is"+c);
                  				while((i=f1.read())!=32)
                  				{
                  					c=(char)i;
                  					System.out.println("c is"+c);
                      				temp=temp.concat(Character.toString(c));
                  				}
                  				System.out.println("Temp first is"+temp);
                  				if((temp.compareTo("Total"))==0) {
                  					temp="";
                  					while((i=f1.read())!=10)
                      				{
                      					c=(char)i;
                      					if(i!=13)
                      						temp=temp.concat(Character.toString(c));
                      				}
                  					System.out.println("Temp second is"+temp);
                  					total=Integer.parseInt(temp);
                  				}
                  				else if((temp.compareTo("Conflict"))==0) {
                  					temp="";
                  					while((i=f1.read())!=10)
                      				{
                      					c=(char)i;
                      					if(i!=13)
                      						temp=temp.concat(Character.toString(c));
                      				}
                  					System.out.println("Temp is"+temp);
                  					conflict=Integer.parseInt(temp);
                  				}
                  				else if((temp.compareTo("Risk"))==0) {
                  					temp="";
                  					while((i=f1.read())!=10)
                      				{
                      					c=(char)i;
                      					if(i!=13)
                      						temp=temp.concat(Character.toString(c));
                      				}
                  					System.out.println("Temp is"+temp);
                  					risk=Double.parseDouble(temp);
                  				}
                  				else
                  				{
                  					//Check if second FR matches with the selected unfrozen FR
                  					String v=temp;
                  					temp="";
                  					while((i=f1.read())!=32)
                      				{
                  						if(i!=13) {
                      					c=(char)i;
                          				temp=temp.concat(Character.toString(c));
                  						}
                      				}
                  					System.out.println("Temp is"+temp);
                  					Node h=unlist;
                  					int f=0;
                  					while(h!=null) {
                  						s=h.id;
                  						if((temp.compareTo(s))==0) 
                  							f=1;
                  						h=h.next;
                  					}
                  					if(f==1) {
                  						num++;
                  						found=1;
                  						while((i=f1.read())!=10) {
                  							
                  						}
                  						st=st.concat(v+" -> "+temp+"\n");
                  						}
                  					//keep the impact value of other FR pair violation if found becomes true will be used to create new impact
                  					else {
                  						temp="";
                      					while((i=f1.read())!=10)
                          				{
                      						if(i!=13) {
                          					c=(char)i;
                              				temp=temp.concat(Character.toString(c));
                      						}
                          				}
                      					System.out.println("Temp third is"+temp);
                      					impact=impact+Double.parseDouble(temp);
                  					}
                  					
                  				
                  				
                  					
                  				}
                  				
                  			}
                  			if(found==1) //Then break from the loop
                  			{
                  				f1.close();
                  					RiskExp=RiskExp-risk;
                  					conflict=conflict-num;
                  					total=total-num;
                  					double prob=(double)((double)conflict/(double)total);
                  					prob = Math.round(prob * 100.0) / 100.0;
                  	        		System.out.println("probability is"+prob);
                  	        		System.out.println("Impact is before scaling"+impact);
                  	        		System.out.println("Num is "+num);
                  	        		impact=((double)(1-0)*(double)(impact-1))/(double)(1000*conflict-1)+0;
                  	        		System.out.println("Impact is before rounding"+impact);
                  	        		impact = Math.round(impact * 100.0) / 100.0;
                  	        		//impact=Double.valueOf(df.format(impact));
                  	        		System.out.println("Impact is after rounding"+impact);
                  	        		risk=prob*impact;
                  	        		//risk=Double.valueOf(df.format(risk));
                  	        		risk = Math.round(risk * 100.0) / 100.0;
                  	        		RiskExp=RiskExp+risk;
                  	        	
                  	        		double d=RiskExp+rint;
                  	        		
                  	        		
                  	        		d = Math.round(d * 100.0) / 100.0;
                  	        		
                  	        		JOptionPane.showMessageDialog(po_frame, st+"Risk has been reduced to "+d);
                  				//}
                  				//Create new file
                  				f1=new FileReader(name);
                  				BufferedWriter b1=null;
                  				b1=new BufferedWriter(new FileWriter("Dummy.txt",false));
                  				int sc=0;
                  				while((i=f1.read())!=-1) {
                  					temp="";
                  					c=(char)i;
                  					temp=temp.concat(Character.toString(c));
                  					while((i=f1.read())!=32) {
                  						if(i!=13) {
                  						c=(char)i;
                      					temp=temp.concat(Character.toString(c));
                  						}
                  					}
                  					String k2=temp;
                  					System.out.println("k2 = "+k2);
                  					if((k2.compareTo("Total"))!=0) {
                  						temp="";
                  						while((i=f1.read())!=32) {
                  							if(i!=13) {
                      						c=(char)i;
                          					temp=temp.concat(Character.toString(c));
                  							}
                      					}
                  						System.out.println("temp = "+temp);
                  						Node h=unlist;
                      					int f=0;
                      					while(h!=null) {
                      						s=h.id;
                      						if((temp.compareTo(s))==0) 
                      							f=1;
                      						h=h.next;
                      					}
                      					if(f==0) {
                  							
                  							String j=temp;
                  							temp="";
                  							while((i=f1.read())!=10) {
                  								if(i!=13) {
                  								c=(char)i;
                              					temp=temp.concat(Character.toString(c));
                  								}
                  							}
                  							System.out.println("temp = "+temp);
                  							if(sc!=0)
                  								b1.newLine();
                  							b1.append(k2+" "+j+" "+temp);
                  							sc++;
                  					
                  							System.out.println("Not matched ");
                  						}
                  						else {
                  							while((i=f1.read())!=10) {
                  								
                  							}
                  						}
                  							
                  					}
                  					else {
                  					b1.newLine();
                  						b1.append("Total "+total);
                  						b1.newLine();
                  						b1.append("Conflict "+conflict);
                  						b1.newLine();
                  						b1.append("Risk "+risk);
                  						b1.newLine();
                  						b1.close();
                  						f1.close();
                  						File f=new File(name);
                  						System.out.println("name is"+name);
                  						if(f.delete()) {
                  							System.out.println("Deleted");
                  						}
                  						File old=new File("Dummy.txt");
                  						File newname=new File(name);
                  						if(old.renameTo(newname)) {
                  							System.out.println("renamed Successfully");
                  						}
                  						try {
                  				    		
                  				    		String n="Iteration"+String.valueOf(itn)+".txt";
                  				    		
                  				    	BufferedWriter b2= new BufferedWriter(new FileWriter("Itr"+String.valueOf(itn)+"\\Risk.txt", false));
                  				    	FileReader f2=new FileReader(name);
                  				    	int i2;
                  				    	while((i2=f2.read())!=-1) {
                  				    		char c2=(char)i;
                  				    		b2.write(i2);
                  				    	}
                  				    	f2.close();
                  				    	b2.close();
                  				    	}catch(IOException e5) {
                  				    		
                  				    	}
                  						break;
                  					}
                  				}
                  			
                  			}
                  			
                  		}
                  			
                  		catch(IOException e2) {
                  			
                  		}
             	
             	}
             	else {
              		//JOptionPane.showMessageDialog(po_frame, "Select an item!");
              	}
            }
            
        });
        
        Report.setFont(new Font("Calibri", 2, 16));
        Report.setBackground(new Color(204, 204, 255));
        Report.setForeground(Color.black);
       Report.setBounds(700, 560, 120, 30);
       Report.setToolTipText("Click to View Risk Report!!");
        po_frame.add(Report);
        
     Report.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
         	   show_riskReport();
            }
     });
     
     scrollPane3.setVerticalScrollBarPolicy(22);
     scrollPane3.setHorizontalScrollBarPolicy(32);
     scrollPane3.setBounds(400, 610, 550, 150);
     textOrder3.setFont(new Font("Calibri", 2, 20));
     textOrder3.setEditable(false);
     po_frame.add(scrollPane3);
        
     //User Selection of requirements
     
     /*adding section for frozen requirements*/
     

     JLabel labelFrozen=new JLabel("Select FRs to be frozen");
     labelFrozen.setFont(new Font("Calibri", 2, 18));
     labelFrozen.setBounds(20, 630, 200, 40);
     po_frame.add(labelFrozen);
     frofr.setBounds(20, 670, 100, 40);
     po_frame.add(frofr);
     frofr.addItem("");
    // frofr.setEnabled(false);
     addFrozen.setFont(new Font("Calibri", 2, 16));
     addFrozen.setBackground(new Color(204, 204, 255));
     addFrozen.setForeground(Color.black);
     addFrozen.setBounds(130, 670, 80, 40);
     addFrozen.setToolTipText("Click to add Frozen Requirements");
  po_frame.add(addFrozen);
     delFrozen.setFont(new Font("Calibri", 2, 16));
     delFrozen.setBackground(new Color(204, 204, 255));
     delFrozen.setForeground(Color.black);
     delFrozen.setBounds(130, 730, 80, 40);
    delFrozen.setToolTipText("Click to Delete Frozen Rqeuirements from the list");
     po_frame.add(delFrozen);
    addFrozen.setEnabled(true);
    delFrozen.setEnabled(true);
    scrollPaneFR.setVerticalScrollBarPolicy(22);
    scrollPaneFR.setHorizontalScrollBarPolicy(32);
    scrollPaneFR.setBounds(230, 660, 150, 120);
    frozenFRs.setFont(new Font("Calibri", 2, 20));
    frozenFRs.setEditable(false);
   po_frame.add(scrollPaneFR);
   
   frofr.removeAllItems();
	 Node p=FR;
	   while(p!=null) {
		   frofr.addItem(p.id);
		   p=p.next;
	   }
	   
    addFrozen.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
       
       	String s=frofr.getSelectedItem().toString(); 
     
       	BufferedWriter b1=null;
     
       	int found=0;
       	Node h=Fro;
       	while(h!=null) {
       		if((h.id.compareTo(s))==0)
       		{
       			found=1;
       			break;
       		}
       		h=h.next;
       	}
       	Node j=prevFro;
       	int prevfound=0;
       	while(j!=null) {
       		if((j.id.compareTo(s))==0)
       		{
       			prevfound=1;
       			break;
       		}
       		j=j.next;
       	}
       	if(prevfound==0) {
       	if(found==0) {
       		 Node temp=new Node();
       		 temp.id=s;
       		 temp.next=null;
       		 if(Fro==null)
       			 Fro=temp;
       		 else {
       			 Node p=Fro;
       			 while(p.next!=null) {
       				 p=p.next;
       			 }
       			 p.next=temp;
       		 }
       		 System.out.println("The FRs are");
       		 Node f=Fro;
       		 while(f!=null) {
       			 System.out.println(f.id);
       			 f=f.next;
       		 }
       	  	frozenFRs.append(s);
           	frozenFRs.append("\n");
        }
       	else {
       		 JOptionPane.showMessageDialog(po_frame, "Already exists!");  
       		
       	}
       	
        }
       	else {
       		 JOptionPane.showMessageDialog(po_frame, "Already Frozen!");  
       	}
       
       	
        }
    });
    delFrozen.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
          	String s=frofr.getSelectedItem().toString(); 
          	if((s.compareTo(""))!=0) {
	        	   Node k=Fro;
	        	   Node m=k;
	        	   int found=0;
	        	   while(k!=null) {
	        		   if((k.id.compareTo(s))==0) {
	        			   found=1;
	        			   break;
	        		   }
	        		   m=k;
	        		   k=k.next;
	        	   }
	        	   if(found==1) {
	        		   if(k==Fro) {
	        			   if(k.next!=null) {
	        				   k=k.next;
	        				   Fro=k;
	        			   }
	        			   else
	        				   Fro=null;
	        		   }
	        		   else if(k.next==null)
	        		   		m.next=null;
	        		   else {
	        			   k=k.next;
	        			   m.next=k;
	        		   }
	          		 frozenFRs.setText(null);
	          		 k=Fro;
	          		 while(k!=null) {
	          			 Node t=prevFro;
	          			 int flag=0;
	          			 while(t!=null) {
	          				 if((t.id.compareTo(k.id))==0)
	          					 flag=1;
	          				 t=t.next;
	          			 }
	          			 if(flag==0) {
	          			 frozenFRs.append(k.id);
	          			 frozenFRs.append("\n");
	          			 }
	          			 k=k.next;
	          		 }
	        	   }
	        	   else {
	        		   JOptionPane.showMessageDialog(po_frame, "Does not exists!");  
	        	   }
	             	}
          	else {
          		JOptionPane.showMessageDialog(po_frame, "Select an item!");
          	}
       	
        }
    });

    
          po_frame.setVisible(true);
    }

    
    public static void delete_files() {
    	System.out.println("called");
    	File f=new File("count.txt");
    	 if(f.delete()){
             // System.out.println("Cleared1");
          }else {
          	// System.out.println("File doesn't exist1");
          	}
    	File file = new File("FroFR.txt");

        if(file.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
    	File file1 = new File("FR.txt");

        if(file1.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file2 = new File("frozenFR.txt");

        if(file2.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file3 = new File("NFR.txt");

        if(file3.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file4 = new File("Dependency.txt");

        if(file4.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file5 = new File("Conflict.txt");

        if(file5.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file6 = new File("Temporal.txt");

        if(file6.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file7 = new File("VEdges.txt");

        if(file7.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        File file8 = new File("VNodes.txt");

        if(file8.delete()){
           // System.out.println("Cleared1");
        }else {
        	// System.out.println("File doesn't exist1");
        	}
        
    }
    
    public static void display_List() {
        for (Node p = FR; p != null; p = p.next) {}
        for (Node p = NFR; p != null; p = p.next) {}
        for (Edge1 q = E_FN; q != null; q = q.next) {
            //System.out.println("FR:" + q.id1);
            //System.out.println("NFR:" + q.id2);
            //System.out.println("Dependency value:" + q.value);
        }
        for (Edge1 q = E_NN; q != null; q = q.next) {
            //System.out.println("NFR:" + q.id1);
            //System.out.println("NFR:" + q.id2);
            //System.out.println("Conflict value:" + q.value);
        }
        Edge2 r = E_FF;
        //System.out.println("The temporal edges are: ");
        while (r != null) {
            //System.out.println("FR:" + r.id1);
            //System.out.println("FR:" + r.id2);
            r = r.next;
        }
    }
    
    public static void create_BasicClusters() {
        Node nfr = NFR;
        bcHead = null;
        while (nfr != null) {
            final BC temp = new BC();
            temp.Nid = nfr.id;
            Edge1 fn = E_FN;
            FRDep flist = null;
            while (fn != null) {
                if (fn.id2.compareTo(nfr.id) == 0) {
                    final FRDep fnode = new FRDep();
                    fnode.id = fn.id1;
                    fnode.val = fn.value;
                    fnode.next = null;
                    if (flist == null) {
                        flist = fnode;
                    }
                    else {
                        FRDep p;
                        for (p = flist; p.next != null; p = p.next) {}
                        p.next = fnode;
                    }
                }
                fn = fn.next;
            }
            if (flist != null) {
                temp.begin = flist;
            }
            temp.next = null;
            if (bcHead == null) {
                bcHead = temp;
            }
            else {
                BC q;
                for (q = bcHead; q.next != null; q = q.next) {}
                q.next = temp;
            }
            nfr = nfr.next;
        }
    }
    
    public static void display_BasicClusters() {
        BC p = bcHead;
        //System.out.println();
        //System.out.println("The basic clusters are:");
        //System.out.println();
        while (p != null) {
            //System.out.println("NFR: " + p.Nid);
            for (FRDep q = p.begin; q != null; q = q.next) {
                //System.out.println("FR: " + q.id);
                //System.out.println("Dependency Edge Weight: " + q.val);
            }
            //System.out.println();
            p = p.next;
        }
    }
    
    public static void create_MacroClusters() {
        Edge1 Nconflict = E_NN;
        mcHead = null;
        while (Nconflict != null) {
            BC p = bcHead;
            final MC temp = new MC();
            temp.next = null;
            temp.Blist = null;
            temp.CEdge = 1;
            while (p != null) {
                if (p.Nid.compareTo(Nconflict.id1) == 0 || p.Nid.compareTo(Nconflict.id2) == 0) {
                    final BC newBC = new BC();
                    newBC.Nid = p.Nid;
                    newBC.begin = p.begin;
                    newBC.next = null;
                    if (temp.Blist == null) {
                        temp.Blist = newBC;
                    }
                    else {
                        BC q;
                        for (q = temp.Blist; q.next != null; q = q.next) {}
                        q.next = newBC;
                    }
                }
                p = p.next;
            }
            if (mcHead == null) {
                mcHead = temp;
            }
            else {
                MC r;
                for (r = mcHead; r.next != null; r = r.next) {}
                r.next = temp;
            }
            Nconflict = Nconflict.next;
        }
      
    }
    
    public static void display_MacroClusters() {
        MC p = mcHead;
        //System.out.println();
        //System.out.println("The macro clusters are:");
        //System.out.println();
        while (p != null) {
            //System.out.println("A macro cluster");
            for (BC q = p.Blist; q != null; q = q.next) {
                //System.out.println("NFR: " + q.Nid);
                for (FRDep r = q.begin; r != null; r = r.next) {
                    //System.out.println("FR: " + r.id);
                    //System.out.println("Dependency Edge Weight: " + r.val);
                }
                //System.out.println();
            }
            p = p.next;
        }
    }
    
    public static void create_requirementSet() {
        root = null;
        for (Node p = FR; p.next != null; p = p.next) {
            for (Node q = p.next; q != null; q = q.next) {
                final Rpair temp = new Rpair();
                temp.id1 = p.id;
                temp.id2 = q.id;
                temp.done = 0;
                temp.next = null;
                if (root == null) {
                    root = temp;
                }
                else {
                    Rpair s;
                    for (s = root; s.next != null; s = s.next) {}
                    s.next = temp;
                }
            }
        }
    }
    
    public static void display_requirementSet() {
        Rpair p = root;
        int count = 0;
        //System.out.println("The requirements pair are: ");
        while (p != null) {
            //System.out.println(String.valueOf(p.id1) + " " + p.id2);
            p = p.next;
            ++count;
        }
        //System.out.println("The count is : " + count);
    }
    
    public static void generate_PartialOrderNew() {
    	Node j=FR;
    	int co=0;
    	while(j!=null)
    	{
    		co++;
    		j=j.next;
    	}
    	conflict_weight=new double[co][co];
    	dep_weight=new double[co][co];
        proot = null;
        for (Rpair point = root; point != null; point = point.next) {
            Edge2 p = E_FF;
            int tflag = 0;
            while (p != null) {
                if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
                    tflag = 1;
                    break;
                }
                p = p.next;
            }
            if (tflag == 1) {
                //System.out.println("Temporal Edge found for : " + point.id1 + " " + point.id2);
                point.done = 1;
                final PO temp = new PO();
                temp.id1 = p.id1;
                temp.id2 = p.id2;
                temp.next = null;
                if (proot == null) {
                    proot = temp;
                }
                else {
                    PO r;
                    for (r = proot; r.next != null; r = r.next) {}
                    r.next = temp;
                }
            }
        }
        for (Rpair point = root; point != null; point = point.next) {
            String fr1 = point.id1;
            String fr2 = point.id2;
            //System.out.println("Checking for " + fr1 + " " + fr2);
            if (point.done == 0) {
                fr1 = point.id1;
                fr2 = point.id2;
                //System.out.println("Checking for " + fr1 + " " + fr2);
                int flagmc1 = 0;
                int flagmc2 = 0;
                int flagmc3 = 0;
                for (MC p2 = mcHead; p2 != null; p2 = p2.next) {
                    flagmc1 = 0;
                    flagmc2 = 0;
                    for (BC q = p2.Blist; q != null; q = q.next) {
                        for (FRDep r2 = q.begin; r2 != null; r2 = r2.next) {
                            if (r2.id.compareTo(fr1) == 0) {
                                flagmc1 = 1;
                            }
                            if (r2.id.compareTo(fr2) == 0) {
                                flagmc2 = 1;
                            }
                        }
                    }
                    if (flagmc1 == 1 && flagmc2 == 1) {
                        flagmc3 = 1;
                        break;
                    }
                }
                if (flagmc3 == 1) {
                    point.done = 1;
                    //System.out.println("Belong to same macro cluster " + fr1 + " " + fr2);
                    if (choice == 1) {
                        case1(fr1, fr2);
                    }
                    else if (choice == 2) {
                        case2(fr1, fr2);
                    }
                    else if (choice == 3) {
                        case3(fr1, fr2);
                    }
                    else if (choice == 4) {
                        case4(fr1, fr2);
                    }
                }
                else {
                    int rflag1 = 0;
                    int rflag2 = 0;
                    LNFR1 = null;
                    LNFR2 = null;
                    for (BC bcluster = bcHead; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id1) == 0) {
                                rflag1 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (LNFR1 == null) {
                                    LNFR1 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = LNFR1; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    for (BC bcluster = bcHead; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id2) == 0) {
                                rflag2 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (LNFR2 == null) {
                                    LNFR2 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = LNFR2; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    int count = 0;
                    int noteq = 0;
                    if (rflag1 == 1 && rflag2 == 1) {
                        Node l1 = LNFR1;
                        int check = 0;
                        while (l1 != null) {
                            Node l2 = LNFR2;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                        l1 = LNFR2;
                        check = 0;
                        while (l1 != null) {
                            Node l2 = LNFR1;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                    }
                    if (count > 0) {
                        point.done = 1;
                        caseB(fr1, fr2);
                    }
                }
            }
            for (PO u = proot; u != null; u = u.next) {
                if (u.next == null) {
                    //System.out.println("added edge is : " + u.id1 + "->" + u.id2);
                    break;
                }
            }
            final int f = check_cycle();
            if (f == 1) {
                //System.out.println("Loop is formed");
                PO p3 = proot;
                PO q3 = p3.next;
                if (q3 != null) {
                    while (q3.next != null) {
                        p3 = p3.next;
                        q3 = p3.next;
                    }
                    p3.next = null;
                }
            }
            for (PO v = proot; v != null; v = v.next) {
                v.visited = 0;
            }
            
        }
     //   display_matrix(co);
    }
    public static void display_matrix(int co) {
    	for(int i=0;i<co;i++) {
    		for(int j=0;j<co;j++) {
    			System.out.println("NFR relevance at ["+i+"]["+j+"] is "+conflict_weight[i][j]);
    		}
    	}
    	for(int i=0;i<co;i++) {
    		for(int j=0;j<co;j++) {
    			System.out.println("Dependency value at ["+i+"]["+j+"] is "+dep_weight[i][j]);
    		}
    	}
    	
    }
    public static int check_cycle() {
    	Node p=FR;
    	int count=0;
    	while(p!=null) {
    		count++;
    		p=p.next;
    	}
    	 POGraph graph = new POGraph(1000); 
    	 PO q=proot;
    	 while(q!=null) {
    		 int num1=0,num2=0;
    		/* if((q.id1.compareTo("fb"))==0) {
    			 num1=max+1;
    		 Scanner in1 = new Scanner(q.id2).useDelimiter("[^0-9]+");
    		 int integer = in1.nextInt();
    		 num2=integer;
    		 }*/
    		 //else {
    			 Scanner in1 = new Scanner(q.id1).useDelimiter("[^0-9]+");
        		 int integer1 = in1.nextInt(); 
        		 num1=integer1;
        		 Scanner in2 = new Scanner(q.id2).useDelimiter("[^0-9]+");
        		 int integer2 = in2.nextInt(); 
        		 num2=integer2;
    		 //}
    		 graph.addEdge(num1,num2);
 	       
    		 q=q.next;
    	 }
    	 if(graph.isCyclic()) 
    		 return 1;
    	 else 
    		 return 0;
    }
    public static void caseB(final String fr1, final String fr2) {
    	matrix nnode=new matrix();
    	nnode.next=null;
    	matrix dnode=new matrix();
    	dnode.next=null;
        Node t = NFR;
        int pval=0;
        String maxNFR = null;
        float weight = 0;
        float maxweight=0;
        while (t != null) {
        
            BC b = bcHead;
            while (b != null) {
                if (b.Nid.compareTo(t.id) == 0) {
                    int flag1 = 0;
                    int flag2 = 0;
                    int v1=0,v2=0;
                	weight=(float) ((float)t.priority*0.5);
                    for (FRDep k = b.begin; k != null; k = k.next) {
                        if (k.id.compareTo(fr1) == 0) {
                            flag1 = 1;
                            v1=k.val;
                            
                        }
                        if (k.id.compareTo(fr2) == 0) {
                            flag2 = 1;
                            v2=k.val;
                        }
                    }
                    if(flag1==1 && flag2==1) {
                    	weight=weight+(float)(((float)v1+(float)v2)*0.5);
                    	if(maxweight<weight)
                    	{
                    		maxweight=weight;
                    	    maxNFR = t.id;
                    	    pval=t.priority;
                    	    break;
                    	}
                    }
                    break;
                }
                else {
                    b = b.next;
                }
            }
            t = t.next;
        }
        //System.out.println("Max NFR is: " + maxNFR);
        BC b = bcHead;
        int val1 = 0;
        int val2 = 0;
        while (b != null) {
            if (b.Nid.compareTo(maxNFR) == 0) {
                final int flag3 = 0;
                final int flag4 = 0;
                for (FRDep i = b.begin; i != null; i = i.next) {
                    if (i.id.compareTo(fr1) == 0) {
                        val1 = i.val;
                    }
                    if (i.id.compareTo(fr2) == 0) {
                        val2 = i.val;
                    }
                }
            }
            b = b.next;
        }
    	Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
        int integer = in.nextInt();
        Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
        int integer2 = in2.nextInt();
       
        final PO temp = new PO();
         if (val1 >= val2) {
             if(val1==val2) {
 		        if(integer>integer2) {
 		            temp.id1 = fr1;
 		            temp.id2 = fr2;
 		           nnode.row=integer;
 		            nnode.col=integer2;
 		            dnode.row=integer;
 		            dnode.col=integer2;
 		        }
 		        else {
 		            temp.id1 = fr2;
 		            temp.id2 = fr1;
 		           nnode.row=integer2;
 		            nnode.col=integer;
 		            dnode.row=integer2;
 		            dnode.col=integer;
 		        }
 	        }
             else {
            temp.id1 = fr1;
            temp.id2 = fr2;
            nnode.row=integer;
            nnode.col=integer2;
            dnode.row=integer;
            dnode.col=integer2;
            }
            nnode.val=pval;
           // conflict_weight[integer-1][integer2-1]=priority;
            double val;
            val=Math.abs(val1-val2);
            if(val<=2)
            {
            	val=val1;
            }
            else {
            	val=(double)((double)val1+(double)val2)/(double)2;
            }
            //System.out.println("Called caseB. Inserting at "+integer+" | "+integer2+". The value "+priority+" and dep "+val);
           // dep_weight[integer-1][integer2-1]=val;
            dnode.val=val;
          
        }
        else if (val1 < val2) {
            temp.id1 = fr2;
            temp.id2 = fr1;
           nnode.val=pval;
          //  conflict_weight[integer2-1][integer-1]=priority;
            double val;
            val=Math.abs(val1-val2);
            if(val<=2)
            {
            	val=val2;
            }
            else {
            	val=(double)((double)val1+(double)val2)/(double)2;
            }
            dnode.val=val;
            nnode.row=integer2;
            nnode.col=integer;
            dnode.row=integer2;
            dnode.col=integer;
            //System.out.println("Called caseB. Inserting at "+integer2+" | "+integer+". The value "+priority+" and dep "+val);
            //dep_weight[integer2-1][integer-1]=val;
            //System.out.println("dep_weight["+integer+"]["+integer2+"]: "+dep_weight[integer-1][integer2-1]);

        }
        if (proot == null) {
            proot = temp;
        }
        else {
            PO r;
            for (r = proot; r.next != null; r = r.next) {}
            r.next = temp;
        }
        if(wn==null)
        	wn=nnode;
        else {
        	matrix k=wn;
        	while(k.next!=null)
        		k=k.next;
        	k.next=nnode;
        }
        if(wd==null)
        	wd=dnode;
        else {
        	matrix k=wd;
        	while(k.next!=null)
        		k=k.next;
        	k.next=dnode;
        }
    }
    
    public static void case1(final String fr1, final String fr2) {
    	matrix nnode=new matrix();
    	nnode.next=null;
    	matrix dnode=new matrix();
    	dnode.next=null;
        int max = 0;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = mcHead;p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                for (Edge1 conflict = E_NN; conflict != null; conflict = conflict.next) {
                    if (((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) && max < conflict.value) {
                        max = conflict.value;
                        nfr1 = N1;
                        nfr2 = N2;
                    }
                }
            }
        }
        //System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
        int integer = in.nextInt();
        Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
        int integer2 = in2.nextInt();
        //System.out.println("The values are val1= "+val1+" val2= "+val2+"Conflict degree= "+max);
        double deg=((double)(((double)val1+(double)val2)/(double)2))*(double)max;
        double dep;
        //System.out.println("Max NFR is: " + maxNFR);
        BC bclist = bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
        	dep=Math.abs(v1-v2);
            if (v1 >= v2) {
                if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		            nnode.row=integer;
    	                nnode.col=integer2;
    	                dnode.row=integer;
    	                dnode.col=integer2;
    		            
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		            nnode.row=integer2;
    	                nnode.col=integer;
    	                dnode.row=integer2;
    	                dnode.col=integer;
    		        }
    	        }
                else {
                temp.id1 = fr1;
                temp.id2 = fr2;
                nnode.row=integer;
                nnode.col=integer2;
                dnode.row=integer;
                dnode.col=integer2;
                }
                
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
            
               // conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
                
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v2;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
               // conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;
            }
          
          
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
           bclist = bcHead;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr2) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v);
            if(dep<=2)
            {
           	 if(v1>v)
           		 dep=v1;
           	 else
           		 dep=v;
            }
            else {
           	 dep=(double)((double)v1+(double)v)/(double)2;
            }
            nnode.val=deg;
            dnode.val=dep;
            nnode.row=integer;
            nnode.col=integer2;
            dnode.row=integer;
            dnode.col=integer2;
           // conflict_weight[integer-1][integer2-1]=deg;
            //dep_weight[integer-1][integer2-1]=dep;
            
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
            bclist = bcHead;
            int v=0;
             while (bclist != null) {
                 flag1 = 0;
                 flag2 = 0;
                 if (minNFR.compareTo(bclist.Nid) == 0) {
                     for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                         if (flist.id.compareTo(fr1) == 0)
                             v = flist.val;
                        
                     }
                     break;
                 }
                 bclist = bclist.next;
             }
             dep=Math.abs(v2-v);
             if(dep<=2)
             {
            	 if(v2>v)
            		 dep=v2;
            	 else
            		 dep=v;
             }
             else {
            	 dep=(double)((double)v2+(double)v)/(double)2;
             }
             nnode.val=deg;
             dnode.val=dep;
             nnode.row=integer2;
             nnode.col=integer;
             dnode.row=integer2;
             dnode.col=integer;
             //conflict_weight[integer2-1][integer-1]=deg;
             //dep_weight[integer2-1][integer-1]=dep;
        }
        else {
            System.out.println("Executing else with Min NFR is: " + minNFR);
            bclist = bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v2);
            
            if (v1 >= v2) {
            	 if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		           nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
                 else {
                 
                temp.id1 = fr1;
                temp.id2 = fr2;
                nnode.row=integer;
                nnode.col=integer2;
                dnode.row=integer;
                dnode.col=integer2;
                 }
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
               
               // conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v2;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
                //conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;
            }
        }
        if (proot == null) {
            proot = temp;
        }
        else {
            PO r2;
            for (r2 = proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
        if(wn==null)
        	wn=nnode;
        else {
        	matrix k=wn;
        	while(k.next!=null)
        		k=k.next;
        	k.next=nnode;
        }
        if(wd==null)
        	wd=dnode;
        else {
        	matrix k=wd;
        	while(k.next!=null)
        		k=k.next;
        	k.next=dnode;
        }
    }
    
    public static void case2(final String fr1, final String fr2) {
    	matrix nnode=new matrix();
    	nnode.next=null;
    	matrix dnode=new matrix();
    	dnode.next=null;
        final int max = 0;
        final String nfr1 = null;
        final String nfr2 = null;
        MC p = mcHead;
        Node nlist = null;
        while (p != null) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                final Node temp1 = new Node();
                temp1.id = N1;
                final Node temp2 = new Node();
                temp2.id = N2;
                if (nlist == null) {
                    nlist = temp1;
                    temp1.next = temp2;
                }
                else {
                    Node j;
                    for (j = nlist; j.next != null; j = j.next) {}
                    j.next = temp1;
                    temp1.next = temp2;
                }
            }
            p = p.next;
        }
        for (Node f = nlist; f != null; f = f.next) {
            System.out.println(f.id);
        }
        String maxNFR = null;
        final String minNFR = null;
        final int val1 = 0;
        final int val2 = 0;
        Node t = nlist;
        int priority = 0;
        while (t != null) {
            for (Node k = NFR; k != null; k = k.next) {
                if (k.id.compareTo(t.id) == 0 && priority < k.priority) {
                    priority = k.priority;
                    maxNFR = t.id;
                }
            }
            t = t.next;
        }
        Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
        int integer = in.nextInt();
        Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
        int integer2 = in2.nextInt();
        System.out.println("Max NFR is: " + maxNFR);
        BC bclist = bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        /*MC m=mcHead;
        while(m!=null) {
        	BC b=m.Blist;
        	String s1=b.Nid;
        	b=b.next;
        	String s2=b.Nid;
        	if((s1.compareTo(maxNFR))==0) {
        		
        	}
        	else if((s2.compareTo(maxNFR))==0) {
        		
        	}
        	m=m.next;
        }*/
        final PO temp3 = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
            	if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		            temp3.id1 = fr1;
     		            temp3.id2 = fr2;
     		           nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		        }
     		        else {
     		            temp3.id1 = fr2;
     		            temp3.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
            	else {
                temp3.id1 = fr1;
                temp3.id2 = fr2;
                nnode.row=integer;
                nnode.col=integer2;
                dnode.row=integer;
                dnode.col=integer2;
            	}
                nnode.val=priority;
               // conflict_weight[integer-1][integer2-1]=priority;
               double v=Math.abs(v1-v2);
                if(v<=2)
                	v=v1;
                else
                	v=(double)((double)v1+(double)v2)/(double)2;
                dnode.val=v;
            
                //dep_weight[integer-1][integer2-1]=v;
            }
            else {
                temp3.id1 = fr2;
                temp3.id2 = fr1;
                nnode.val=priority;
                //conflict_weight[integer2-1][integer-1]=priority;
                double v=Math.abs(v1-v2);
                if(v<=2)
                	v=v2;
                else
                	v=(double)((double)v1+(double)v2)/(double)2;
                dnode.val=v;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
                //dep_weight[integer2-1][integer-1]=v;
            }
        }
        else if (flag1 == 1) {
            temp3.id1 = fr1;
            temp3.id2 = fr2;
            nnode.val=priority;
            //conflict_weight[integer-1][integer2-1]=priority;
            MC m=mcHead;
           double v=0;
            int c=0;
            while(m!=null) {
            	BC b=m.Blist;
            	String s1=b.Nid;
            	b=b.next;
            	String s2=b.Nid;
            	if((s1.compareTo(maxNFR))==0) {
            		BC k=bcHead;
            		while(k!=null) {
            			if((k.Nid.compareTo(s2))==0) {
            				FRDep f=k.begin;
            				while(f!=null) {
            					if((f.id.compareTo(fr2))==0) {
            						v=v+f.val;
            						c++;
            					}
            					f=f.next;
            				}
            			}
            			k=k.next;
            		}
            	}
            	else if((s2.compareTo(maxNFR))==0) {
            		BC k=bcHead;
            		while(k!=null) {
            			if((k.Nid.compareTo(s1))==0) {
            				FRDep f=k.begin;
            				while(f!=null) {
            					if((f.id.compareTo(fr2))==0) {
            						v=v+f.val;
            						c++;
            					}
            					f=f.next;
            				}
            			}
            			k=k.next;
            		}
            	}
            	m=m.next;
            }
            v=v/c;
            if(v<=2)
            {
            	if(v<v1)
            		v=v1;
            }
            else {
            	v=(double)((double)v1+(double)v)/(double)2;
            }
            dnode.val=v;
            nnode.row=integer;
            nnode.col=integer2;
            dnode.row=integer;
            dnode.col=integer2;
            //dep_weight[integer-1][integer2-1]=v;
        }
        else if (flag2 == 1) {
            temp3.id1 = fr2;
            temp3.id2 = fr1;
            MC m=mcHead;
            double v=0;
             int c=0;
             while(m!=null) {
             	BC b=m.Blist;
             	String s1=b.Nid;
             	b=b.next;
             	String s2=b.Nid;
             	if((s1.compareTo(maxNFR))==0) {
             		BC k=bcHead;
             		while(k!=null) {
             			if((k.Nid.compareTo(s2))==0) {
             				FRDep f=k.begin;
             				while(f!=null) {
             					if((f.id.compareTo(fr2))==0) {
             						v=v+f.val;
             						c++;
             					}
             					f=f.next;
             				}
             			}
             			k=k.next;
             		}
             	}
             	else if((s2.compareTo(maxNFR))==0) {
             		BC k=bcHead;
             		while(k!=null) {
             			if((k.Nid.compareTo(s1))==0) {
             				FRDep f=k.begin;
             				while(f!=null) {
             					if((f.id.compareTo(fr2))==0) {
             						v=v+f.val;
             						c++;
             					}
             					f=f.next;
             				}
             			}
             			k=k.next;
             		}
             	}
             	m=m.next;
             }
             v=v/c;
             if(v<=2)
             {
             	if(v<v2)
             		v=v2;
             }
             else {
             	v=(double)((double)v2+(double)v)/(double)2;
             }
             nnode.val=priority;
             dnode.val=v;
             nnode.row=integer2;
             nnode.col=integer;
             dnode.row=integer2;
             dnode.col=integer;
           // conflict_weight[integer2-1][integer-1]=priority;
            //dep_weight[integer2-1][integer-1]=v2;
        }
        else {
            System.out.println("entering else");
            t = nlist;
            priority = 0;
            int complete = 0;
            String min = "";
            int exists = 1;
            while (exists == 1) {
                exists = 0;
                Node q2;
                t = (q2 = nlist);
                while (t != null) {
                    if (t.id.compareTo(maxNFR) == 0) {
                        if (t == nlist) {
                            nlist = t.next;
                            break;
                        }
                        System.out.println("In else");
                        q2.next = t.next;
                        break;
                    }
                    else {
                        q2 = t;
                        t = t.next;
                    }
                }
                for (Node r2 = nlist; r2 != null; r2 = r2.next) {
                    System.out.println(r2.id);
                    if (r2.id.compareTo(maxNFR) == 0) {
                        exists = 1;
                    }
                }
            }
            System.out.println("Done deletion");
            while (complete == 0) {
                t = nlist;
                priority = 0;
                while (t != null) {
                    Node i = NFR;
                    System.out.println("compairing " + t.id);
                    while (i != null) {
                        if (i.id.compareTo(t.id) == 0) {
                            System.out.println("Priority is of k:" + i.id + " " + i.priority);
                            if (priority < i.priority) {
                                priority = i.priority;
                                min = i.id;
                            }
                        }
                        i = i.next;
                    }
                    System.out.println("Priority is" + priority);
                    t = t.next;
                }
                System.out.println("NFR selected =" + min);
                flag1 = 0;
                flag2 = 0;
                v1 = 0;
                v2 = 0;
                for (bclist = bcHead; bclist != null; bclist = bclist.next) {
                    if (min.compareTo(bclist.Nid) == 0) {
                        for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                            if (flist2.id.compareTo(fr1) == 0) {
                                flag1 = 1;
                                v1 = flist2.val;
                            }
                            else if (flist2.id.compareTo(fr2) == 0) {
                                flag2 = 1;
                                v2 = flist2.val;
                            }
                        }
                        break;
                    }
                }
                System.out.println("flag1 and flag2: " + flag1 + " " + flag2);
                if (flag1 == 1 || flag2 == 1) {
                    complete = 1;
                    if (flag1 == 1 && flag2 == 1) {
                        if (v1 >= v2) {
                        	if(v1==v2) {
                 	    		
                 		        if(integer>integer2) {
                 		            temp3.id1 = fr1;
                 		            temp3.id2 = fr2;
                 		           nnode.row=integer;
                                   nnode.col=integer2;
                                   dnode.row=integer;
                                   dnode.col=integer2;
                 		        }
                 		        else {
                 		            temp3.id1 = fr2;
                 		            temp3.id2 = fr1;
                 		           nnode.row=integer2;
                                   nnode.col=integer;
                                   dnode.row=integer2;
                                   dnode.col=integer;
                 		        }
                 	        }
                        else {
                            temp3.id1 = fr1;
                            temp3.id2 = fr2;
                            nnode.row=integer;
                            nnode.col=integer2;
                            dnode.row=integer;
                            dnode.col=integer2;
                        }
                            nnode.val=priority;
                           // conflict_weight[integer-1][integer2-1]=priority;
                            double v=Math.abs(v1-v2);
                            if(v<=2)
                            	v=v1;
                            else
                            	v=(double)((double)v1+(double)v2)/(double)2;
                            dnode.val=v;
                        
                           // dep_weight[integer-1][integer2-1]=v;
                            
                        }
                        else {
                            temp3.id1 = fr2;
                            temp3.id2 = fr1;
                            nnode.val=priority;
                           // conflict_weight[integer2-1][integer-1]=priority;
                            double v=Math.abs(v1-v2);
                            if(v<=2)
                            	v=v2;
                            else
                            	v=(double)((double)v1+(double)v2)/(double)2;
                            dnode.val=v;
                            nnode.row=integer2;
                            nnode.col=integer;
                            dnode.row=integer2;
                            dnode.col=integer;
                            //dep_weight[integer2-1][integer-1]=v;
                        }
                    }
                    else if (flag1 == 1) {
                        temp3.id1 = fr1;
                        temp3.id2 = fr2;
                        MC m=mcHead;
                        double v=0;
                         int c=0;
                         while(m!=null) {
                         	BC b=m.Blist;
                         	String s1=b.Nid;
                         	b=b.next;
                         	String s2=b.Nid;
                         	if((s1.compareTo(min))==0) {
                         		BC k=bcHead;
                         		while(k!=null) {
                         			if((k.Nid.compareTo(s2))==0) {
                         				FRDep f=k.begin;
                         				while(f!=null) {
                         					if((f.id.compareTo(fr2))==0) {
                         						v=v+f.val;
                         						c++;
                         					}
                         					f=f.next;
                         				}
                         			}
                         			k=k.next;
                         		}
                         	}
                         	else if((s2.compareTo(min))==0) {
                         		BC k=bcHead;
                         		while(k!=null) {
                         			if((k.Nid.compareTo(s1))==0) {
                         				FRDep f=k.begin;
                         				while(f!=null) {
                         					if((f.id.compareTo(fr2))==0) {
                         						v=v+f.val;
                         						c++;
                         					}
                         					f=f.next;
                         				}
                         			}
                         			k=k.next;
                         		}
                         	}
                         	m=m.next;
                         }
                         v=v/c;
                         if(v<=2)
                         {
                         	if(v<v1)
                         		v=v1;
                         }
                         else {
                         	v=(double)((double)v1+(double)v)/(double)2;
                         }
                         nnode.val=priority;
                         dnode.val=v;
                         nnode.row=integer;
                         nnode.col=integer2;
                         dnode.row=integer;
                         dnode.col=integer2;
                         //conflict_weight[integer-1][integer2-1]=priority;
                         //dep_weight[integer-1][integer2-1]=v;
                    }
                    else if (flag2 == 1) {
                        temp3.id1 = fr2;
                        temp3.id2 = fr1;
                        MC m=mcHead;
                        double v=0;
                         int c=0;
                         while(m!=null) {
                         	BC b=m.Blist;
                         	String s1=b.Nid;
                         	b=b.next;
                         	String s2=b.Nid;
                         	if((s1.compareTo(min))==0) {
                         		BC k=bcHead;
                         		while(k!=null) {
                         			if((k.Nid.compareTo(s2))==0) {
                         				FRDep f=k.begin;
                         				while(f!=null) {
                         					if((f.id.compareTo(fr2))==0) {
                         						v=v+f.val;
                         						c++;
                         					}
                         					f=f.next;
                         				}
                         			}
                         			k=k.next;
                         		}
                         	}
                         	else if((s2.compareTo(min))==0) {
                         		BC k=bcHead;
                         		while(k!=null) {
                         			if((k.Nid.compareTo(s1))==0) {
                         				FRDep f=k.begin;
                         				while(f!=null) {
                         					if((f.id.compareTo(fr2))==0) {
                         						v=v+f.val;
                         						c++;
                         					}
                         					f=f.next;
                         				}
                         			}
                         			k=k.next;
                         		}
                         	}
                         	m=m.next;
                         }
                         v=v/c;
                         if(v<=2)
                         {
                         	if(v<v2)
                         		v=v2;
                         }
                         else {
                         	v=(double)((double)v2+(double)v)/(double)2;
                         }
                         nnode.val=priority;
                         dnode.val=v;
                         nnode.row=integer2;
                         nnode.col=integer;
                         dnode.row=integer2;
                         dnode.col=integer;
                         //conflict_weight[integer2-1][integer-1]=priority;
                         //dep_weight[integer2-1][integer-1]=v;
                    }
                }
                exists = 1;
                while (exists == 1) {
                    Node h;
                    Node l = h = nlist;
                    exists = 0;
                    while (l != null) {
                        if (l.id.compareTo(min) == 0) {
                            if (l == nlist) {
                                nlist = l.next;
                                break;
                            }
                            h.next = l.next;
                            break;
                        }
                        else {
                            h = l;
                            l = l.next;
                        }
                    }
                    for (l = nlist; l != null; l = l.next) {
                        if (l.id.compareTo(min) == 0) {
                            exists = 1;
                        }
                    }
                }
            }
        }
        if (proot == null) {
            proot = temp3;
        }
        else {
            PO r3;
            for (r3 = proot; r3.next != null; r3 = r3.next) {}
            r3.next = temp3;
        }
        if(wn==null)
        	wn=nnode;
        else {
        	matrix k=wn;
        	while(k.next!=null)
        		k=k.next;
        	k.next=nnode;
        }
        if(wd==null)
        	wd=dnode;
        else {
        	matrix k=wd;
        	while(k.next!=null)
        		k=k.next;
        	k.next=dnode;
        }
    }
    
    public static void case3(final String fr1, final String fr2) {
    	matrix nnode=new matrix();
    	nnode.next=null;
    	matrix dnode=new matrix();
    	dnode.next=null;
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        int p2 = 0;
        int p3 = 0;
        int degree = 0;
        for (MC p = mcHead; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                System.out.println("N1 and N2 are" + N1 + " " + N2);
                Edge1 conflict = E_NN;
                
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
                System.out.println("The degree is " + degree);
               
                for (Node k = NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                System.out.println("p1 and p2 are" + p2 + " " + p3);
                final float product = (degree - 40) * ((p2 + p3) / 200.0f);
                System.out.println("Product is" + product);
                if (max < product) {
                    max = product;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
        int integer = in.nextInt();
        Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
        int integer2 = in2.nextInt();
      double deg=((p2+p3)/2)*degree;
        double dep;
        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
        	dep=Math.abs(v1-v2);
            if (v1 >= v2) {
            	if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		        	 nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
            	else {
            		 nnode.row=integer;
                     nnode.col=integer2;
                     dnode.row=integer;
                     dnode.col=integer2;
                temp.id1 = fr1;
                temp.id2 = fr2;
            	}
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
               
                //conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
                
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
                //conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;

            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
            bclist = bcHead;
            int v=0;
             while (bclist != null) {
                 flag1 = 0;
                 flag2 = 0;
                 if (minNFR.compareTo(bclist.Nid) == 0) {
                     for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                         if (flist.id.compareTo(fr2) == 0)
                             v = flist.val;
                        
                     }
                     break;
                 }
                 bclist = bclist.next;
             }
             dep=Math.abs(v1-v);
             if(dep<=2)
             {
            	 if(v1>v)
             	dep=v1;
            	 else
            		 dep=v;
             }
             	else
             	dep=(double)((double)v1+(double)v2)/(double)2;
             nnode.val=deg;
             dnode.val=dep;
             nnode.row=integer;
             nnode.col=integer2;
             dnode.row=integer;
             dnode.col=integer2;
            // conflict_weight[integer-1][integer2-1]=deg;
             //dep_weight[integer-1][integer2-1]=dep;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
            bclist = bcHead;
            int v=0;
             while (bclist != null) {
                 flag1 = 0;
                 flag2 = 0;
                 if (minNFR.compareTo(bclist.Nid) == 0) {
                     for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                         if (flist.id.compareTo(fr1) == 0)
                             v = flist.val;
                        
                     }
                     break;
                 }
                 bclist = bclist.next;
             }
             dep=Math.abs(v2-v);
             if(dep<=2)
             {
            	 if(v2>v)
             	dep=v2;
            	 else
            		 dep=v;
             }
             	else
             	dep=(double)((double)v+(double)v2)/(double)2;
             nnode.val=deg;
             dnode.val=dep;
             nnode.row=integer2;
             nnode.col=integer;
             dnode.row=integer2;
             dnode.col=integer;
            // conflict_weight[integer2-1][integer-1]=deg;
             //dep_weight[integer2-1][integer-1]=dep;
        }
        else {
            bclist = bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v2);
            if (v1 >= v2) {
            	if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		           nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
            else {
            	  nnode.row=integer;
                  nnode.col=integer2;
                  dnode.row=integer;
                  dnode.col=integer2;
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
              
                //conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v2;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
                //conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;
            }
        }
        if (proot == null) {
            proot = temp;
        }
        else {
            PO r2;
            for (r2 = proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
        if(wn==null)
        	wn=nnode;
        else {
        	matrix k=wn;
        	while(k.next!=null)
        		k=k.next;
        	k.next=nnode;
        }
        if(wd==null)
        	wd=dnode;
        else {
        	matrix k=wd;
        	while(k.next!=null)
        		k=k.next;
        	k.next=dnode;
        }
    }
    
    public static void case4(final String fr1, final String fr2) {
    	matrix nnode=new matrix();
    	nnode.next=null;
    	matrix dnode=new matrix();
    	dnode.next=null;
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        int p2 = 0;
        int p3 = 0;
        int degree = 0;
        for (MC p = mcHead; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                Edge1 conflict = E_NN;
             
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
             
                for (Node k = NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                final float sum = (float)w1 * degree + (p2 + p3) * (float)w2;
                System.out.println("The sum is" + sum);
                if (max < sum) {
                    max = sum;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
        int integer = in.nextInt();
        Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
        int integer2 = in2.nextInt();
        double deg=((p2+p3)/2)*degree;
        double dep;
        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = bcHead;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
        	dep=Math.abs(v1-v2);
            if (v1 >= v2) {
            	if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		           nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
            	else {
            		   nnode.row=integer;
                       nnode.col=integer2;
                       dnode.row=integer;
                       dnode.col=integer2;
                temp.id1 = fr1;
                temp.id2 = fr2;
            	}
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
             
                nnode.val=deg;
                dnode.val=dep;
                //conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v2;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
               // conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
            bclist = bcHead;
            int v=0;
             while (bclist != null) {
                 flag1 = 0;
                 flag2 = 0;
                 if (minNFR.compareTo(bclist.Nid) == 0) {
                     for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                         if (flist.id.compareTo(fr2) == 0)
                             v = flist.val;
                        
                     }
                     break;
                 }
                 bclist = bclist.next;
             }
             dep=Math.abs(v1-v);
             if(dep<=2)
             {
            	 if(v1>v)
            		 dep=v1;
            	 else
            		 dep=v;
             }
             else
             	dep=(double)((double)v1+(double)v)/(double)2;
             nnode.val=deg;
             dnode.val=dep;
             nnode.row=integer;
             nnode.col=integer2;
             dnode.row=integer;
             dnode.col=integer2;
            // conflict_weight[integer-1][integer2-1]=deg;
             //dep_weight[integer-1][integer2-1]=dep;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
            bclist = bcHead;
            int v=0;
             while (bclist != null) {
                 flag1 = 0;
                 flag2 = 0;
                 if (minNFR.compareTo(bclist.Nid) == 0) {
                     for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                         if (flist.id.compareTo(fr1) == 0)
                             v = flist.val;
                        
                     }
                     break;
                 }
                 bclist = bclist.next;
             }
             dep=Math.abs(v2-v);
             if(dep<=2)
             {
            	 if(v2>v)
            		 dep=v2;
            	 else
            		 dep=v;
             }
             else
             	dep=(double)((double)v2+(double)v)/(double)2;
             nnode.val=deg;
             dnode.val=dep;
             nnode.row=integer2;
             nnode.col=integer;
             dnode.row=integer2;
             dnode.col=integer;
             //conflict_weight[integer2-1][integer-1]=deg;
             //dep_weight[integer2-1][integer-1]=dep;
        }
        else {
            bclist = bcHead;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v2);
            if (v1 >= v2) {
            	if(v1==v2) {
     	    		
     		        if(integer>integer2) {
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		           nnode.row=integer;
     	                nnode.col=integer2;
     	                dnode.row=integer;
     	                dnode.col=integer2;
     		            
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		           nnode.row=integer2;
     	                nnode.col=integer;
     	                dnode.row=integer2;
     	                dnode.col=integer;
     		        }
     	        }
            	else {
            		 nnode.row=integer;
                     nnode.col=integer2;
                     dnode.row=integer;
                     dnode.col=integer2;
                temp.id1 = fr1;
                temp.id2 = fr2;
            	}
                if(dep<=2)
                	dep=v1;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
               
               // conflict_weight[integer-1][integer2-1]=deg;
                //dep_weight[integer-1][integer2-1]=dep;
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
                if(dep<=2)
                	dep=v2;
                else
                	dep=(double)((double)v1+(double)v2)/(double)2;
                nnode.val=deg;
                dnode.val=dep;
                nnode.row=integer2;
                nnode.col=integer;
                dnode.row=integer2;
                dnode.col=integer;
               // conflict_weight[integer2-1][integer-1]=deg;
                //dep_weight[integer2-1][integer-1]=dep;
            }
        }
        if (proot == null) {
            proot = temp;
        }
        else {
            PO r2;
            for (r2 = proot; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
        if(wn==null)
        	wn=nnode;
        else {
        	matrix k=wn;
        	while(k.next!=null)
        		k=k.next;
        	k.next=nnode;
        }
        if(wd==null)
        	wd=dnode;
        else {
        	matrix k=wd;
        	while(k.next!=null)
        		k=k.next;
        	k.next=dnode;
        }
    }
    
    public static void display_PartialOrder() {
        PO p = proot;
        System.out.println("The partial order is :");
        while (p != null) {
            System.out.println(String.valueOf(p.id1) + "->" + p.id2);
            p = p.next;
        }
    }
    public static void display_PartialOrder2() {
        PO p = proot2;
        System.out.println("The partial order is :");
        while (p != null) {
            System.out.println(String.valueOf(p.id1) + "->" + p.id2);
            p = p.next;
        }
    }

    public static int  Set_newFR() {
    	int input=0;
    	int type=0;
    	String s1="";
    	String s2="";
    	String s3="";
    	String s4="";
    	String s5="";
    	String s6="";
    	s1=fr1.getText();
  		s3=nfr4.getText();
		s4=depvalue1.getSelectedItem().toString();
    	int flag=0;
    	if((s1.compareTo(""))!=0) {
    		input=1;
  
    		//System.out.println("s3="+s3);
    		if((s3.compareTo(""))==0) {
    			System.out.println("Initiating else");
    			int i=Req.getRowCount();
				int exists=0;
				for(int j=0;j<i;j++) {
					String temp1=Req.getValueAt(j, 0).toString();
					//String temp2=Req.getValueAt(j, 1).toString();
					if((temp1.compareTo(s1))==0) {
						//Req.setValueAt(s4, j, 2);
						exists=1;
					
					}
				}
				if(exists==0) {
    			DefaultTableModel model = (DefaultTableModel)Req.getModel();
				Object []o = new Object[3];
				o[0]=s1;
				o[1]="";
				o[2]="";
				model.addRow(o);
				flag=1;
				type=2;
				}
				else {
					JOptionPane.showMessageDialog(firstFrame,"Not a valid entry");
					type=0;
				}
    		}
    		else {
    			System.out.println("Entering else");

    			if((s4.compareTo(""))!=0) {
					int i=Req.getRowCount();
					int exists=0;
					for(int j=0;j<i;j++) {
						String temp1=Req.getValueAt(j, 0).toString();
						String temp2=Req.getValueAt(j, 1).toString();
						if((temp1.compareTo(s1))==0 && (temp2.compareTo(s3)==0)) {
							System.out.println("Found match 1");
							Req.setValueAt(s4, j, 2);
							exists=1;
						}
						else if((temp1.compareTo(s1))==0 && (temp2.compareTo(""))==0) {
							System.out.println("Found match 2");
							Req.setValueAt(s3, j, 1);
							Req.setValueAt(s4, j, 2);
							exists=1;
						}
					}
					if(exists==0) {
						System.out.println("Does not exists");
						DefaultTableModel model = (DefaultTableModel)Req.getModel();
						Object []o = new Object[3];
						o[0]=s1;
						o[1]=s3;			// you can use integer or anything 
						o[2]=s4;	
						model.addRow(o);
						newdep++;
						type=2;
					}
					if(exists==1) {
						updatedep++;
						type=1;
					}
    				flag=2;
    			}
    			else {
    				
    				JOptionPane.showMessageDialog(firstFrame,"Select a dependency value.");
    				type=0;
    			}
    		}
    	
    		fr1.setText("");
    		nfr4.setText("");
    		depvalue1.setSelectedItem("");
    		
    	}
    	s2=fr2.getSelectedItem().toString();
		s5=nfr1.getSelectedItem().toString();
		s6=depvalue2.getSelectedItem().toString();
    	if((fr2.getSelectedItem())!="")
    	{
    		input=1;
    		System.out.println("hie I am updating!!");
    		
    		if((nfr1.getSelectedItem())!="") {
    	
    			if((s6.compareTo(""))!=0) {
    				int i=Req.getRowCount();
					int exists=0;
					for(int j=0;j<i;j++) {
						String temp1=Req.getValueAt(j, 0).toString();
						String temp2=Req.getValueAt(j, 1).toString();
						if((temp1.compareTo(s2))==0 && (temp2.compareTo(s5)==0)) {
							System.out.println("Found match 1");
							Req.setValueAt(s6, j, 2);
							exists=1;
							type=2;
						}
						else if((temp1.compareTo(s2))==0 && (temp2.compareTo(""))==0) {
							System.out.println("Found match 2");
							Req.setValueAt(s5, j, 1);
							Req.setValueAt(s6, j, 2);
							exists=1;
						}
					}
					if(exists==0) {
						System.out.println("Does not exists");
						DefaultTableModel model = (DefaultTableModel)Req.getModel();
						Object []o = new Object[3];
						o[0]=s2;
						o[1]=s5;			// you can use integer or anything 
						o[2]=s6;	
						model.addRow(o);
						type=0;
					}
    			}
    			else {
    				JOptionPane.showMessageDialog(firstFrame,"Select a dependency value");
    				type=0;
    			}
    		}
    		else {
    			JOptionPane.showMessageDialog(firstFrame,"Select a NFR");
    		}
    		fr2.setSelectedItem("");
    		nfr1.setSelectedItem("");
    		depvalue2.setSelectedItem("");
    	}
    	if(input==0)
    		JOptionPane.showMessageDialog(firstFrame,"No input provided!");
    	if((s1.compareTo(""))!=0) {
    		int n=fr2.getItemCount();
    		/*checking whether FR already exists or not*/
    		int k=0,found=0;
    		while(k<n) {
    			String s=fr2.getItemAt(k).toString();
    			if((s.compareTo(s1))==0)
    				found=1;
    			k++;
    		}
    		if(found==0) {
    			fr2.addItem(s1);
    			fr4.addItem(s1);
    			fr5.addItem(s1);
    			newFR++;
        	
    	}
    	}
    	if((s3.compareTo(""))!=0) {
    		int n=nfr1.getItemCount();
    		/*checking whether FR already exists or not*/
    		int k=0,found=0;
    		while(k<n) {
    			String s=nfr1.getItemAt(k).toString();
    			if((s.compareTo(s3))==0)
    				found=1;
    			k++;
    		}
    		if(found==0) {
    			nfr1.addItem(s3);
    			nfr2.addItem(s3);
    			nfr3.addItem(s3);
    			newNFR++;
    		}
    		
    	}
    	return type;
    }
 public static void Set_newConflicts() {
    	String s1=nfr2.getSelectedItem().toString();
    	String s2=nfr3.getSelectedItem().toString();
    	String s3=degree.getText();
    	if((s1.compareTo(""))!=0 && (s2.compareTo(""))!=0 && (s3.compareTo(""))!=0) {
    		if((s1.compareTo(s2))!=0) {
    			int c=Integer.valueOf(s3);
    		if(c>100 || c<1) {
    			JOptionPane.showMessageDialog(firstFrame,"Not a valid degree of conflict");
    		}
    		else {
    		int num=Reqconflict.getRowCount();
    		int exists=0;
    		for(int j=0;j<num;j++) {
    			String temp1=Reqconflict.getValueAt(j, 0).toString();
    			String temp2=Reqconflict.getValueAt(j, 1).toString();
    			if(((temp1.compareTo(s1))==0 && (temp2.compareTo(s2))==0)||((temp1.compareTo(s2))==0 && (temp2.compareTo(s1))==0)) {
    				Reqconflict.setValueAt(s3, j, 2);
    				exists=1;
    				break;
    			}
    		}
    		if(exists==0) {
    			DefaultTableModel model = (DefaultTableModel)Reqconflict.getModel();
				Object []o = new Object[3];
				o[0]=s1;
				o[1]=s2;
				o[2]=s3;
				model.addRow(o);
				newcon++;
    		}
    		if(exists==1)
    			updatecon++;
    		}
    	}
    		else {
    			JOptionPane.showMessageDialog(firstFrame,"Select different NFRs");
    		}
    	}
    	else {
    		JOptionPane.showMessageDialog(firstFrame,"Select all the data");
    	}
    
    		nfr2.setSelectedItem("");
    	nfr3.setSelectedItem("");
    	degree.setText("");
    }
  public static void display_reqs()
    {
    
    	Edge1 q=E_FN;
        int rows=0;
        while(q!=null)
        {
        	rows++;
        	q=q.next;
        }
        String[] columns = new String[] {"FR", "NFR", "Dependency Value"};
        Object[][] data=new Object[100][3]; 
      //data[0][0]="FR";
       //data[0][1]="NFR";
       //data[0][2]="Dependency Value";
       Node k=FR;
       int r=0;
       while(k!=null) {
       	Edge1 p=E_FN;
       	int flag=0;
       	while(p!=null) {
       		if((p.id1.compareTo(k.id))==0)
       		{
       			flag=1;
       		  	int c=0;
       			data[r][c]=p.id1;
       			c++;
       			data[r][c]=p.id2;
       			c++;
       			data[r][c]=p.value;
       	      	r++;
       	     //model.insertRow(r, new Object[]{p.id1, p.id2, p.value});
       	     //r++;
       		}
       		p=p.next;
       	}
       	if(flag==0)
       	{
       		System.out.println("Found");
       		data[r][0]=k.id;
       		r++;
       	 // model.addRow(new Object[]{k.id, "", ""});
       	}
 
       	k=k.next;
       }
      
       System.out.println("data in the table");
       for(int p=0;p<r;p++) {
    	   for(int q1=0;q1<3;q1++)
    		   System.out.print(data[p][q1]+" ");
    	   System.out.println();
       }

    }
    public static void create_frozenrequirementset() {
    	root3 = null;
        for (Node p = Fro; p.next != null; p = p.next) {
            for (Node q = p.next; q != null; q = q.next) {
                final Rpair temp = new Rpair();
                temp.id1 = p.id;
                temp.id2 = q.id;
                temp.done = 0;
                temp.next = null;
                if (root3== null) {
                    root3 = temp;
                }
                else {
                    Rpair s;
                    for (s = root3; s.next != null; s = s.next) {}
                    s.next = temp;
                }
            }
        }	
    }
	 public static void create_frozenPO() {
		
	        proot3 = null;
	        for (Rpair point = root3; point != null; point = point.next) {
	            Edge2 p = E_FF;
	            int tflag = 0;
	            while (p != null) {
	                if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
	                    tflag = 1;
	                    break;
	                }
	                p = p.next;
	            }
	            if (tflag == 1) {
	                System.out.println("Temporal Edge found for : " + point.id1 + " " + point.id2);
	                point.done = 1;
	                final PO temp = new PO();
	                temp.id1 = p.id1;
	                temp.id2 = p.id2;
	                temp.next = null;
	                if (proot3 == null) {
	                    proot3 = temp;
	                }
	                else {
	                    PO r;
	                    for (r = proot3; r.next != null; r = r.next) {}
	                    r.next = temp;
	                }
	            }
	        }
	        for (Rpair point = root3; point != null; point = point.next) {
	            String fr1 = point.id1;
	            String fr2 = point.id2;
	            System.out.println("Checking for " + fr1 + " " + fr2);
	            if (point.done == 0) {
	                fr1 = point.id1;
	                fr2 = point.id2;
	                System.out.println("Checking for " + fr1 + " " + fr2);
	                int flagmc1 = 0;
	                int flagmc2 = 0;
	                int flagmc3 = 0;
	                for (MC p2 = mcHead; p2 != null; p2 = p2.next) {
	                    flagmc1 = 0;
	                    flagmc2 = 0;
	                    for (BC q = p2.Blist; q != null; q = q.next) {
	                        for (FRDep r2 = q.begin; r2 != null; r2 = r2.next) {
	                            if (r2.id.compareTo(fr1) == 0) {
	                                flagmc1 = 1;
	                            }
	                            if (r2.id.compareTo(fr2) == 0) {
	                                flagmc2 = 1;
	                            }
	                        }
	                    }
	                    if (flagmc1 == 1 && flagmc2 == 1) {
	                        flagmc3 = 1;
	                        break;
	                    }
	                }
	                if (flagmc3 == 1) {
	                    point.done = 1;
	                    System.out.println("Belong to same macro cluster " + fr1 + " " + fr2);
	                    if (choice == 1) {
	                        fcase1(fr1, fr2);
	                    }
	                    else if (choice == 2) {
	                        fcase2(fr1, fr2);
	                    }
	                    else if (choice == 3) {
	                        fcase3(fr1, fr2);
	                    }
	                    else if (choice == 4) {
	                        fcase4(fr1, fr2);
	                    }
	                }
	                else {
	                    int rflag1 = 0;
	                    int rflag2 = 0;
	                    LNFR1 = null;
	                    LNFR2 = null;
	                    for (BC bcluster = bcHead; bcluster != null; bcluster = bcluster.next) {
	                        FRDep s = bcluster.begin;
	                        while (s != null) {
	                            if (s.id.compareTo(point.id1) == 0) {
	                                rflag1 = 1;
	                                final Node temp2 = new Node();
	                                temp2.id = bcluster.Nid;
	                                temp2.next = null;
	                                if (LNFR1 == null) {
	                                    LNFR1 = temp2;
	                                    break;
	                                }
	                                Node q2;
	                                for (q2 = LNFR1; q2.next != null; q2 = q2.next) {}
	                                q2.next = temp2;
	                                break;
	                            }
	                            else {
	                                s = s.next;
	                            }
	                        }
	                    }
	                    for (BC bcluster = bcHead; bcluster != null; bcluster = bcluster.next) {
	                        FRDep s = bcluster.begin;
	                        while (s != null) {
	                            if (s.id.compareTo(point.id2) == 0) {
	                                rflag2 = 1;
	                                final Node temp2 = new Node();
	                                temp2.id = bcluster.Nid;
	                                temp2.next = null;
	                                if (LNFR2 == null) {
	                                    LNFR2 = temp2;
	                                    break;
	                                }
	                                Node q2;
	                                for (q2 = LNFR2; q2.next != null; q2 = q2.next) {}
	                                q2.next = temp2;
	                                break;
	                            }
	                            else {
	                                s = s.next;
	                            }
	                        }
	                    }
	                    int count = 0;
	                    int noteq = 0;
	                    if (rflag1 == 1 && rflag2 == 1) {
	                        Node l1 = LNFR1;
	                        int check = 0;
	                        while (l1 != null) {
	                            Node l2 = LNFR2;
	                            check = 0;
	                            while (l2 != null) {
	                                if (l1.id.compareTo(l2.id) == 0) {
	                                    check = 1;
	                                    ++count;
	                                    break;
	                                }
	                                l2 = l2.next;
	                            }
	                            l1 = l1.next;
	                            if (check == 0) {
	                                noteq = 1;
	                            }
	                        }
	                        l1 = LNFR2;
	                        check = 0;
	                        while (l1 != null) {
	                            Node l2 = LNFR1;
	                            check = 0;
	                            while (l2 != null) {
	                                if (l1.id.compareTo(l2.id) == 0) {
	                                    check = 1;
	                                    ++count;
	                                    break;
	                                }
	                                l2 = l2.next;
	                            }
	                            l1 = l1.next;
	                            if (check == 0) {
	                                noteq = 1;
	                            }
	                        }
	                    }
	                    if (count > 0) {
	                        point.done = 1;
	                        fcaseB(fr1, fr2);
	                    }
	                }
	            }
	            for (PO u = proot3; u != null; u = u.next) {
	                if (u.next == null) {
	                    System.out.println("added edge is : " + u.id1 + "->" + u.id2);
	                    break;
	                }
	            }
	            final int f = check_cycle2();
	            if (f == 1) {
	                System.out.println("Loop is formed");
	                PO p3 = proot3;
	                PO q3 = p3.next;
	                if (q3 != null) {
	                    while (q3.next != null) {
	                        p3 = p3.next;
	                        q3 = p3.next;
	                    }
	                    p3.next = null;
	                }
	            }
	            for (PO v = proot3; v != null; v = v.next) {
	                v.visited = 0;
	            }
	         
	    }
	   
	 }
	 public static void fcaseB(final String fr1, final String fr2) {
	        Node t = NFR;
	        String maxNFR = null;
	        int priority = 0;
	        while (t != null) {
	            BC b = bcHead;
	            while (b != null) {
	                if (b.Nid.compareTo(t.id) == 0) {
	                    int flag1 = 0;
	                    int flag2 = 0;
	                    for (FRDep k = b.begin; k != null; k = k.next) {
	                        if (k.id.compareTo(fr1) == 0) {
	                            flag1 = 1;
	                        }
	                        if (k.id.compareTo(fr2) == 0) {
	                            flag2 = 1;
	                        }
	                    }
	                    if (flag1 == 1 && flag2 == 1 && priority < t.priority) {
	                        priority = t.priority;
	                        maxNFR = t.id;
	                        break;
	                    }
	                    break;
	                }
	                else {
	                    b = b.next;
	                }
	            }
	            t = t.next;
	        }
	        System.out.println("Max NFR is: " + maxNFR);
	        BC b = bcHead;
	        int val1 = 0;
	        int val2 = 0;
	        while (b != null) {
	            if (b.Nid.compareTo(maxNFR) == 0) {
	                final int flag3 = 0;
	                final int flag4 = 0;
	                for (FRDep i = b.begin; i != null; i = i.next) {
	                    if (i.id.compareTo(fr1) == 0) {
	                        val1 = i.val;
	                    }
	                    if (i.id.compareTo(fr2) == 0) {
	                        val2 = i.val;
	                    }
	                }
	            }
	            b = b.next;
	        }
	       
	        final PO temp = new PO();
	        if(val1==val2) {
	    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
		        int integer1 = in1.nextInt();
		  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
		        int integer2 = in2.nextInt();
		        if(integer1>integer2) {
		            temp.id1 = fr1;
		            temp.id2 = fr2;
		        }
		        else {
		            temp.id1 = fr2;
		            temp.id2 = fr1;
		        }
	        }
	        else if (val1 > val2) {
	            temp.id1 = fr1;
	            temp.id2 = fr2;
	       
	            
	        }
	        else if (val1 < val2) {
	            temp.id1 = fr2;
	            temp.id2 = fr1;

	        }
	        if (proot3 == null) {
	            proot3 = temp;
	        }
	        else {
	            PO r;
	            for (r = proot3; r.next != null; r = r.next) {}
	            r.next = temp;
	        }
	    }
	    
	    public static void fcase1(final String fr1, final String fr2) {
	        int max = 0;
	        String nfr1 = null;
	        String nfr2 = null;
	        for (MC p = mcHead;p != null; p = p.next) {
	            int flagmc1 = 0;
	            int flagmc2 = 0;
	            String N1 = null;
	            String N2 = null;
	            for (BC q = p.Blist; q != null; q = q.next) {
	                for (FRDep r = q.begin; r != null; r = r.next) {
	                    if (r.id.compareTo(fr1) == 0) {
	                        flagmc1 = 1;
	                    }
	                    if (r.id.compareTo(fr2) == 0) {
	                        flagmc2 = 1;
	                    }
	                }
	            }
	            if (flagmc1 == 1 && flagmc2 == 1) {
	                BC q = p.Blist;
	                N1 = q.Nid;
	                q = q.next;
	                N2 = q.Nid;
	                for (Edge1 conflict = E_NN; conflict != null; conflict = conflict.next) {
	                    if (((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) && max < conflict.value) {
	                        max = conflict.value;
	                        nfr1 = N1;
	                        nfr2 = N2;
	                    }
	                }
	            }
	        }
	        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
	        String maxNFR = null;
	        String minNFR = null;
	        int val1 = 0;
	        int val2 = 0;
	        for (Node t = NFR; t != null; t = t.next) {
	            if (t.id.compareTo(nfr1) == 0) {
	                val1 = t.priority;
	            }
	            else if (t.id.compareTo(nfr2) == 0) {
	                val2 = t.priority;
	            }
	        }
	        if (val1 > val2) {
	            maxNFR = nfr1;
	            minNFR = nfr2;
	        }
	        else if (val1 < val2) {
	            maxNFR = nfr2;
	            minNFR = nfr1;
	        }
	     
	        System.out.println("Max NFR is: " + maxNFR);
	        BC bclist = bcHead;
	        int flag1 = 0;
	        int flag2 = 0;
	        int v1 = 0;
	        int v2 = 0;
	        while (bclist != null) {
	            flag1 = 0;
	            flag2 = 0;
	            if (maxNFR.compareTo(bclist.Nid) == 0) {
	                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
	                    if (flist.id.compareTo(fr1) == 0) {
	                        flag1 = 1;
	                        v1 = flist.val;
	                    }
	                    else if (flist.id.compareTo(fr2) == 0) {
	                        flag2 = 1;
	                        v2 = flist.val;
	                    }
	                }
	                break;
	            }
	            bclist = bclist.next;
	        }
	        final PO temp = new PO();
	        if (flag1 == 1 && flag2 == 1) {
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	            else  if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	                
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	                
	            }
	          
	          
	        }
	        else if (flag1 == 1) {
	            temp.id1 = fr1;
	            temp.id2 = fr2;
	             
	        }
	        else if (flag2 == 1) {
	            temp.id1 = fr2;
	            temp.id2 = fr1;
	             }
	        else {
	            System.out.println("Executing else with Min NFR is: " + minNFR);
	            bclist = bcHead;
	            v1 = 0;
	            v2 = 0;
	            while (bclist != null) {
	                flag1 = 0;
	                flag2 = 0;
	                if (minNFR.compareTo(bclist.Nid) == 0) {
	                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
	                        if (flist2.id.compareTo(fr1) == 0) {
	                            v1 = flist2.val;
	                        }
	                        else if (flist2.id.compareTo(fr2) == 0) {
	                            v2 = flist2.val;
	                        }
	                    }
	                    break;
	                }
	                bclist = bclist.next;
	            }
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	            
	            else if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	                
	            }
	        }
	        if (proot3 == null) {
	            proot3 = temp;
	        }
	        else {
	            PO r2;
	            for (r2 = proot3; r2.next != null; r2 = r2.next) {}
	            r2.next = temp;
	        }
	    }
	    
	    public static void fcase2(final String fr1, final String fr2) {
	        final int max = 0;
	        final String nfr1 = null;
	        final String nfr2 = null;
	        MC p = mcHead;
	        Node nlist = null;
	        while (p != null) {
	            int flagmc1 = 0;
	            int flagmc2 = 0;
	            String N1 = null;
	            String N2 = null;
	            for (BC q = p.Blist; q != null; q = q.next) {
	                for (FRDep r = q.begin; r != null; r = r.next) {
	                    if (r.id.compareTo(fr1) == 0) {
	                        flagmc1 = 1;
	                    }
	                    if (r.id.compareTo(fr2) == 0) {
	                        flagmc2 = 1;
	                    }
	                }
	            }
	            if (flagmc1 == 1 && flagmc2 == 1) {
	                BC q = p.Blist;
	                N1 = q.Nid;
	                q = q.next;
	                N2 = q.Nid;
	                final Node temp1 = new Node();
	                temp1.id = N1;
	                final Node temp2 = new Node();
	                temp2.id = N2;
	                if (nlist == null) {
	                    nlist = temp1;
	                    temp1.next = temp2;
	                }
	                else {
	                    Node j;
	                    for (j = nlist; j.next != null; j = j.next) {}
	                    j.next = temp1;
	                    temp1.next = temp2;
	                }
	            }
	            p = p.next;
	        }
	        for (Node f = nlist; f != null; f = f.next) {
	            System.out.println(f.id);
	        }
	        String maxNFR = null;
	        final String minNFR = null;
	        final int val1 = 0;
	        final int val2 = 0;
	        Node t = nlist;
	        int priority = 0;
	        while (t != null) {
	            for (Node k = NFR; k != null; k = k.next) {
	                if (k.id.compareTo(t.id) == 0 && priority < k.priority) {
	                    priority = k.priority;
	                    maxNFR = t.id;
	                }
	            }
	            t = t.next;
	        }
	     
	        System.out.println("Max NFR is: " + maxNFR);
	        BC bclist = bcHead;
	        int flag1 = 0;
	        int flag2 = 0;
	        int v1 = 0;
	        int v2 = 0;
	        while (bclist != null) {
	            flag1 = 0;
	            flag2 = 0;
	            if (maxNFR.compareTo(bclist.Nid) == 0) {
	                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
	                    if (flist.id.compareTo(fr1) == 0) {
	                        flag1 = 1;
	                        v1 = flist.val;
	                    }
	                    else if (flist.id.compareTo(fr2) == 0) {
	                        flag2 = 1;
	                        v2 = flist.val;
	                    }
	                }
	                break;
	            }
	            bclist = bclist.next;
	        }
	        /*MC m=mcHead;
	        while(m!=null) {
	        	BC b=m.Blist;
	        	String s1=b.Nid;
	        	b=b.next;
	        	String s2=b.Nid;
	        	if((s1.compareTo(maxNFR))==0) {
	        		
	        	}
	        	else if((s2.compareTo(maxNFR))==0) {
	        		
	        	}
	        	m=m.next;
	        }*/
	        final PO temp3 = new PO();
	        if (flag1 == 1 && flag2 == 1) {
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp3.id1 = fr1;
			            temp3.id2 = fr2;
			        }
			        else {
			            temp3.id1 = fr2;
			            temp3.id2 = fr1;
			        }
		        }
	            else if (v1 > v2) {
	                temp3.id1 = fr1;
	                temp3.id2 = fr2;
	                
	            }
	            else {
	                temp3.id1 = fr2;
	                temp3.id2 = fr1;
	                
	            }
	        }
	        else if (flag1 == 1) {
	            temp3.id1 = fr1;
	            temp3.id2 = fr2;
	            }
	        else if (flag2 == 1) {
	            temp3.id1 = fr2;
	            temp3.id2 = fr1;
	                }
	        else {
	            System.out.println("entering else");
	            t = nlist;
	            priority = 0;
	            int complete = 0;
	            String min = "";
	            int exists = 1;
	            while (exists == 1) {
	                exists = 0;
	                Node q2;
	                t = (q2 = nlist);
	                while (t != null) {
	                    if (t.id.compareTo(maxNFR) == 0) {
	                        if (t == nlist) {
	                            nlist = t.next;
	                            break;
	                        }
	                        System.out.println("In else");
	                        q2.next = t.next;
	                        break;
	                    }
	                    else {
	                        q2 = t;
	                        t = t.next;
	                    }
	                }
	                for (Node r2 = nlist; r2 != null; r2 = r2.next) {
	                    System.out.println(r2.id);
	                    if (r2.id.compareTo(maxNFR) == 0) {
	                        exists = 1;
	                    }
	                }
	            }
	            System.out.println("Done deletion");
	            while (complete == 0) {
	                t = nlist;
	                priority = 0;
	                while (t != null) {
	                    Node i = NFR;
	                    System.out.println("compairing " + t.id);
	                    while (i != null) {
	                        if (i.id.compareTo(t.id) == 0) {
	                            System.out.println("Priority is of k:" + i.id + " " + i.priority);
	                            if (priority < i.priority) {
	                                priority = i.priority;
	                                min = i.id;
	                            }
	                        }
	                        i = i.next;
	                    }
	                    System.out.println("Priority is" + priority);
	                    t = t.next;
	                }
	                System.out.println("NFR selected =" + min);
	                flag1 = 0;
	                flag2 = 0;
	                v1 = 0;
	                v2 = 0;
	                for (bclist = bcHead; bclist != null; bclist = bclist.next) {
	                    if (min.compareTo(bclist.Nid) == 0) {
	                        for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
	                            if (flist2.id.compareTo(fr1) == 0) {
	                                flag1 = 1;
	                                v1 = flist2.val;
	                            }
	                            else if (flist2.id.compareTo(fr2) == 0) {
	                                flag2 = 1;
	                                v2 = flist2.val;
	                            }
	                        }
	                        break;
	                    }
	                }
	                System.out.println("flag1 and flag2: " + flag1 + " " + flag2);
	                if (flag1 == 1 || flag2 == 1) {
	                    complete = 1;
	                    if (flag1 == 1 && flag2 == 1) {
	                        if(v1==v2) {
	            	    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
	            		        int integer1 = in1.nextInt();
	            		  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
	            		        int integer2 = in2.nextInt();
	            		        if(integer1>integer2) {
	            		            temp3.id1 = fr1;
	            		            temp3.id2 = fr2;
	            		        }
	            		        else {
	            		            temp3.id1 = fr2;
	            		            temp3.id2 = fr1;
	            		        }
	            	        }
	                        else if (v1 > v2) {
	                            temp3.id1 = fr1;
	                            temp3.id2 = fr2;
	                            
	                            
	                        }
	                        else {
	                            temp3.id1 = fr2;
	                            temp3.id2 = fr1;
	                            
	                        }
	                    }
	                    else if (flag1 == 1) {
	                        temp3.id1 = fr1;
	                        temp3.id2 = fr2;
	                          }
	                    else if (flag2 == 1) {
	                        temp3.id1 = fr2;
	                        temp3.id2 = fr1;
	                          }
	                }
	                exists = 1;
	                while (exists == 1) {
	                    Node h;
	                    Node l = h = nlist;
	                    exists = 0;
	                    while (l != null) {
	                        if (l.id.compareTo(min) == 0) {
	                            if (l == nlist) {
	                                nlist = l.next;
	                                break;
	                            }
	                            h.next = l.next;
	                            break;
	                        }
	                        else {
	                            h = l;
	                            l = l.next;
	                        }
	                    }
	                    for (l = nlist; l != null; l = l.next) {
	                        if (l.id.compareTo(min) == 0) {
	                            exists = 1;
	                        }
	                    }
	                }
	            }
	        }
	        if (proot3 == null) {
	            proot3 = temp3;
	        }
	        else {
	            PO r3;
	            for (r3 = proot3; r3.next != null; r3 = r3.next) {}
	            r3.next = temp3;
	        }
	    }
	    
	    public static void fcase3(final String fr1, final String fr2) {
	        float max = 0.0f;
	        String nfr1 = null;
	        String nfr2 = null;
	        int p2 = 0;
	        int p3 = 0;
	        int degree = 0;
	        for (MC p = mcHead; p != null; p = p.next) {
	            int flagmc1 = 0;
	            int flagmc2 = 0;
	            String N1 = null;
	            String N2 = null;
	            for (BC q = p.Blist; q != null; q = q.next) {
	                for (FRDep r = q.begin; r != null; r = r.next) {
	                    if (r.id.compareTo(fr1) == 0) {
	                        flagmc1 = 1;
	                    }
	                    if (r.id.compareTo(fr2) == 0) {
	                        flagmc2 = 1;
	                    }
	                }
	            }
	            if (flagmc1 == 1 && flagmc2 == 1) {
	                BC q = p.Blist;
	                N1 = q.Nid;
	                q = q.next;
	                N2 = q.Nid;
	                System.out.println("N1 and N2 are" + N1 + " " + N2);
	                Edge1 conflict = E_NN;
	                
	                while (conflict != null) {
	                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
	                        degree = conflict.value;
	                    }
	                    conflict = conflict.next;
	                }
	                System.out.println("The degree is " + degree);
	               
	                for (Node k = NFR; k != null; k = k.next) {
	                    if (k.id.compareTo(N1) == 0) {
	                        p2 = k.priority;
	                    }
	                    if (k.id.compareTo(N2) == 0) {
	                        p3 = k.priority;
	                    }
	                }
	                System.out.println("p1 and p2 are" + p2 + " " + p3);
	                final float product = (degree - 40) * ((p2 + p3) / 200.0f);
	                System.out.println("Product is" + product);
	                if (max < product) {
	                    max = product;
	                    nfr1 = N1;
	                    nfr2 = N2;
	                }
	            }
	        }
	       
	        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
	        String maxNFR = null;
	        String minNFR = null;
	        int val1 = 0;
	        int val2 = 0;
	        for (Node t = NFR; t != null; t = t.next) {
	            if (t.id.compareTo(nfr1) == 0) {
	                val1 = t.priority;
	            }
	            else if (t.id.compareTo(nfr2) == 0) {
	                val2 = t.priority;
	            }
	        }
	        if (val1 > val2) {
	            maxNFR = nfr1;
	            minNFR = nfr2;
	        }
	        else if (val1 < val2) {
	            maxNFR = nfr2;
	            minNFR = nfr1;
	        }
	        BC bclist = bcHead;
	        int flag1 = 0;
	        int flag2 = 0;
	        int v1 = 0;
	        int v2 = 0;
	        while (bclist != null) {
	            flag1 = 0;
	            flag2 = 0;
	            if (maxNFR.compareTo(bclist.Nid) == 0) {
	                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
	                    if (flist.id.compareTo(fr1) == 0) {
	                        flag1 = 1;
	                        v1 = flist.val;
	                    }
	                    else if (flist.id.compareTo(fr2) == 0) {
	                        flag2 = 1;
	                        v2 = flist.val;
	                    }
	                }
	                break;
	            }
	            bclist = bclist.next;
	        }
	        final PO temp = new PO();
	        if (flag1 == 1 && flag2 == 1) {
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	            else  if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	               
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	                
	            }
	        }
	        else if (flag1 == 1) {
	            temp.id1 = fr1;
	            temp.id2 = fr2;
	             }
	        else if (flag2 == 1) {
	            temp.id1 = fr2;
	            temp.id2 = fr1;
	              }
	        else {
	            bclist = bcHead;
	            v1 = 0;
	            v2 = 0;
	            while (bclist != null) {
	                flag1 = 0;
	                flag2 = 0;
	                if (minNFR.compareTo(bclist.Nid) == 0) {
	                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
	                        if (flist2.id.compareTo(fr1) == 0) {
	                            v1 = flist2.val;
	                        }
	                        else if (flist2.id.compareTo(fr2) == 0) {
	                            v2 = flist2.val;
	                        }
	                    }
	                    break;
	                }
	                bclist = bclist.next;
	            }
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	            if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	               
	            }
	        }
	        if (proot3 == null) {
	            proot3 = temp;
	        }
	        else {
	            PO r2;
	            for (r2 = proot3; r2.next != null; r2 = r2.next) {}
	            r2.next = temp;
	        }
	    }
	    
	    public static void fcase4(final String fr1, final String fr2) {
	        float max = 0.0f;
	        String nfr1 = null;
	        String nfr2 = null;
	        int p2 = 0;
	        int p3 = 0;
	        int degree = 0;
	        for (MC p = mcHead; p != null; p = p.next) {
	            int flagmc1 = 0;
	            int flagmc2 = 0;
	            String N1 = null;
	            String N2 = null;
	            for (BC q = p.Blist; q != null; q = q.next) {
	                for (FRDep r = q.begin; r != null; r = r.next) {
	                    if (r.id.compareTo(fr1) == 0) {
	                        flagmc1 = 1;
	                    }
	                    if (r.id.compareTo(fr2) == 0) {
	                        flagmc2 = 1;
	                    }
	                }
	            }
	            if (flagmc1 == 1 && flagmc2 == 1) {
	                BC q = p.Blist;
	                N1 = q.Nid;
	                q = q.next;
	                N2 = q.Nid;
	                Edge1 conflict = E_NN;
	             
	                while (conflict != null) {
	                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
	                        degree = conflict.value;
	                    }
	                    conflict = conflict.next;
	                }
	             
	                for (Node k = NFR; k != null; k = k.next) {
	                    if (k.id.compareTo(N1) == 0) {
	                        p2 = k.priority;
	                    }
	                    if (k.id.compareTo(N2) == 0) {
	                        p3 = k.priority;
	                    }
	                }
	                final float sum = (float)w1 * degree + (p2 + p3) * (float)w2;
	                System.out.println("The sum is" + sum);
	                if (max < sum) {
	                    max = sum;
	                    nfr1 = N1;
	                    nfr2 = N2;
	                }
	            }
	        }
	   
	        System.out.println("The NFRs are " + nfr1 + " " + nfr2);
	        String maxNFR = null;
	        String minNFR = null;
	        int val1 = 0;
	        int val2 = 0;
	        for (Node t = NFR; t != null; t = t.next) {
	            if (t.id.compareTo(nfr1) == 0) {
	                val1 = t.priority;
	            }
	            else if (t.id.compareTo(nfr2) == 0) {
	                val2 = t.priority;
	            }
	        }
	        if (val1 > val2) {
	            maxNFR = nfr1;
	            minNFR = nfr2;
	        }
	        else if (val1 < val2) {
	            maxNFR = nfr2;
	            minNFR = nfr1;
	        }
	        BC bclist = bcHead;
	        int flag1 = 0;
	        int flag2 = 0;
	        int v1 = 0;
	        int v2 = 0;
	        while (bclist != null) {
	            flag1 = 0;
	            flag2 = 0;
	            if (maxNFR.compareTo(bclist.Nid) == 0) {
	                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
	                    if (flist.id.compareTo(fr1) == 0) {
	                        flag1 = 1;
	                        v1 = flist.val;
	                    }
	                    else if (flist.id.compareTo(fr2) == 0) {
	                        flag2 = 1;
	                        v2 = flist.val;
	                    }
	                }
	                break;
	            }
	            bclist = bclist.next;
	        }
	        final PO temp = new PO();
	        if (flag1 == 1 && flag2 == 1) {
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	        else if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	                
	            }
	        }
	        else if (flag1 == 1) {
	            temp.id1 = fr1;
	            temp.id2 = fr2;
	               }
	        else if (flag2 == 1) {
	            temp.id1 = fr2;
	            temp.id2 = fr1;
	            
	        }
	        else {
	            bclist = bcHead;
	            v1 = 0;
	            v2 = 0;
	            while (bclist != null) {
	                flag1 = 0;
	                flag2 = 0;
	                if (minNFR.compareTo(bclist.Nid) == 0) {
	                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
	                        if (flist2.id.compareTo(fr1) == 0) {
	                            v1 = flist2.val;
	                        }
	                        else if (flist2.id.compareTo(fr2) == 0) {
	                            v2 = flist2.val;
	                        }
	                    }
	                    break;
	                }
	                bclist = bclist.next;
	            }
	            if(v1==v2) {
		    		Scanner in1 = new Scanner(fr1).useDelimiter("[^0-9]+");
			        int integer1 = in1.nextInt();
			  		Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
			        int integer2 = in2.nextInt();
			        if(integer1>integer2) {
			            temp.id1 = fr1;
			            temp.id2 = fr2;
			        }
			        else {
			            temp.id1 = fr2;
			            temp.id2 = fr1;
			        }
		        }
	            else if (v1 > v2) {
	                temp.id1 = fr1;
	                temp.id2 = fr2;
	                
	            }
	            else {
	                temp.id1 = fr2;
	                temp.id2 = fr1;
	                
	            }
	        }
	        if (proot3 == null) {
	            proot3 = temp;
	        }
	        else {
	            PO r2;
	            for (r2 = proot3; r2.next != null; r2 = r2.next) {}
	            r2.next = temp;
	        }
	    }
	    //checks for cycle when creating PO for frozen requirements
	    public static int check_cycle2() {
	    	Node p=Fro;
	    	int count=0;
	    	while(p!=null) {
	    		count++;
	    		p=p.next;
	    	}
	    	
	    	 POGraph graph = new POGraph(1000); 
	    	 PO q=proot3;
	    	 while(q!=null) {
	    		 int num1=0,num2=0;
	    		
	    			 Scanner in1 = new Scanner(q.id1).useDelimiter("[^0-9]+");
	        		 int integer1 = in1.nextInt(); 
	        		 num1=integer1;
	        		 Scanner in2 = new Scanner(q.id2).useDelimiter("[^0-9]+");
	        		 int integer2 = in2.nextInt(); 
	        		 num2=integer2;
	   
	    		 graph.addEdge(num1,num2);
	 	       
	    		 q=q.next;
	    	 }
	    	 if(graph.isCyclic()) 
	    		 return 1;
	    	 else 
	    		 return 0;
	    }
	 public static void remove_frozentransitive() {
			    PO j=proot3;
			    while(j!=null) {
			    	j.visited=0;
			    	j=j.next;
			    }
			    for(Node p=Fro;p!=null;p=p.next) {
			    	for(Node q=Fro;q!=null;q=q.next) {
			    		for(Node r=Fro;r!=null;r=r.next) {
			    			String s1=p.id;
			    			String s2=q.id;
			    			PO k=proot3;
			    			int flag1=0;
			    			while(k!=null) {
			    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
			    					flag1=1;
			    					break;
			    				}
			    				k=k.next;
			    			}
			    			s1=q.id;
			    			s2=r.id;
			    			k=proot3;
			    			int flag2=0;
			    			while(k!=null) {
			    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
			    					flag2=1;
			    					break;
			    				}
			    				k=k.next;
			    			}
			    			if(flag1==1 && flag2==1) {
			        			s1=p.id;
			        			s2=r.id;
			        			System.out.println("removing "+p.id+" -> "+r.id+" due to "+p.id+" -> "+q.id+" and "+q.id+" -> "+r.id);
			        			
			        			PO m=proot3;
			        			PO n=m;
			        			int found=0;
			        			while(m!=null) {
			        				if((m.id1.compareTo(s1))==0 && (m.id2.compareTo(s2))==0) {
			        					found=1;
			        					m.visited=1;
			        					break;
			        				}
			        				n=m;
			        				m=m.next;
			        			}
			        			/*if(found==1) {
			        				if(m==proot) {
			        					if(m.next!=null) {
			        						m=m.next;
			        						proot=m;
			        					}
			        					else
			        						proot=null;
			        				}
			        				else if(m.next==null) {
			        					n.next=null;
			        				}
			        				else {
			        					m=m.next;
			        					n.next=m;
			        				}
			        			}*/
			    		}
			    	
			    			
			    		}
			    	}
			    }
			    PO s=proot3;
			    while(s!=null) {
			    	System.out.println(s.id1+" -> "+s.id2+" : "+s.visited);
			    	s=s.next;
			    }
			    PO p=proot3;
			    int flag=1;
			    while(flag==1) {
			    	flag=0;
			    	PO m=proot3;
					PO n=m;
					int found=0;
					while(m!=null) {
						if(m.visited==1) {
							found=1;
							break;
						}
						n=m;
						m=m.next;
					}
				//	System.out.println("Found "+m.id1+" -> "+m.id2);
					if(found==1) {
						System.out.println("Found "+m.id1+" -> "+m.id2);
						if(m==proot3) {
							if(m.next!=null) {
								m=m.next;
								proot3=m;
							}
							else
								proot3=null;
						}
						else if(m.next==null) {
							n.next=null;
						}
						else {
							m=m.next;
							n.next=m;
						}
					}
			    	PO g=proot3;
			    	while(g!=null) {
			    		if(g.visited==1)
			    			flag=1;
			    		g=g.next;
			    	}
			    }
			    System.out.println("After removing transitive edges");
			    PO r=proot3;
			    while(r!=null) {
			    	System.out.println(r.id1+" -> "+r.id2);
			    	r=r.next;
			    }
			    }
	 
	 public static void add_remainEdge() {
		 Node p=sink;
		 while(p!=null){
			 Node q=source;
			 while(q!=null) {
				 PO temp=new PO();
				 temp.id1=p.id;
				 temp.id2=q.id;
				 temp.next=null;
				 int bcflag=0;
				 int mcflag=0;
				 int p1=0, q1=0;
				 BC b1=bcHead;
				 System.out.println("checking for pair "+p.id+" "+q.id);
				 while(b1!=null) {
					 FRDep f=b1.begin;
					 p1=0;q1=0;
					 while(f!=null) {
						 if((f.id.compareTo(p.id))==0)
							 p1=1;
						 if((f.id.compareTo(q.id))==0)
							 q1=1;
						 f=f.next;
					 }
					 if(p1==1 && q1==1) {
						 bcflag=1;
						 break;
					 }
					 b1=b1.next;
				 }
				 MC m1=mcHead;
				 System.out.println("Displaying just before");
				 display_MacroClusters();
				 while (m1 != null) {
					 p1=0;q1=0;
			            System.out.println("A macro cluster");
			            for (BC b2 = m1.Blist; b2 != null; b2 = b2.next) {
			              
			                for (FRDep r = b2.begin; r != null; r = r.next) {
			                	 if((r.id.compareTo(p.id))==0)
									 p1=1;
								 if((r.id.compareTo(q.id))==0)
									 q1=1;
			                }
			              
			            }
			            if(p1==1 && q1==1) {
							 mcflag=1;
							 break;
						 }
			            m1 = m1.next;
			        }
				 System.out.println("BCflag="+bcflag+" mcflag="+mcflag);
				 if(bcflag==1 || mcflag==1) {
				 if(proot2==null)
					 proot2=temp;
				 else {
					 PO m=proot2;
					 while(m.next!=null)
						 m=m.next;
					 m.next=temp;
				 }
				}
				 q=q.next;
			 }
			 p=p.next;
		 }
		 PO k=proot2;
		 while(k!=null) {
			 if((k.id1.compareTo("fb"))==0) {
				 p=sink;
				 while(p!=null) {
					 PO temp=new PO();
					 temp.id1=p.id;
					 temp.id2=k.id2;
					 temp.next=null;
					 int bcflag=0;
					 int mcflag=0;
					 int p1=0, q1=0;
					 BC b1=bcHead;
					 System.out.println("checking for pair "+p.id+" "+k.id2);
					 while(b1!=null) {
						 FRDep f=b1.begin;
						 p1=0;q1=0;
						 while(f!=null) {
							 if((f.id.compareTo(p.id))==0)
								 p1=1;
							 if((f.id.compareTo(k.id2))==0)
								 q1=1;
							 f=f.next;
						 }
						 if(p1==1 && q1==1) {
							 bcflag=1;
							 break;
						 }
						 b1=b1.next;
					 }
					 MC m1=mcHead;
					 System.out.println("Displaying just before");
					 display_MacroClusters();
					 while (m1 != null) {
						 p1=0;q1=0;
				            System.out.println("A macro cluster");
				            for (BC b2 = m1.Blist; b2 != null; b2 = b2.next) {
				              
				                for (FRDep r = b2.begin; r != null; r = r.next) {
				                	 if((r.id.compareTo(p.id))==0)
										 p1=1;
									 if((r.id.compareTo(k.id2))==0)
										 q1=1;
				                }
				              
				            }
				            if(p1==1 && q1==1) {
								 mcflag=1;
								 break;
							 }
				            m1 = m1.next;
				        }
					 System.out.println("BCflag="+bcflag+" mcflag="+mcflag);
					 if(bcflag==1 || mcflag==1) {

						 PO m=proot2;
						 while(m.next!=null)
							 m=m.next;
						 m.next=temp;
						 
					 }
					 p=p.next;
				 }
					 
			 }
			 k=k.next;
		 }
		 int exists=1;
		 while(exists==1) {
			 exists=0;
			 PO s=proot2;
			 PO t=s;
			 int found=0;
			 while(s!=null) {
				 if((s.id1.compareTo("fb"))==0) {
					 found=1;
				 break;
			 }
				 t=s;
				 s=s.next;
			 }
			 if(found==1) {
				 if(s==proot2) {
					 if(s.next!=null) {
						 s=s.next;
						 proot2=s;
					 }
					 else
						 proot2=null;
				 }
				 else if(s.next==null) {
					 t.next=null;
				 }
				 else {
					 s=s.next;
					 t.next=s;
				 }
			 }
			 PO h=proot2;
			 while(h!=null) {
				 if((h.id1.compareTo("fb"))==0)
					 exists=1;
				 h=h.next;
			 }
		 }
		 Reremove_transitive();
		 k=proot3;
		 while(k!=null) {
			 PO temp=new PO();
			 temp.id1=k.id1;
			 temp.id2=k.id2;
			 temp.next=null;
			 PO h=proot2;
			 while(h.next!=null)
				 h=h.next;
			 h.next=temp;
			 k=k.next;
		 }
		
	 }
	 public static void show_matrix() {
		 matrix temp=wn;
		 double val=0;
		 System.out.println("The NFR Relevance values are: ");
		 while(temp!=null) {
			 if(temp.val>100) {
				 val=((double)(100-1)*(double)(temp.val-1))/(double)(10000-1)+1;
				 val=Math.round(val * 100.0) / 100.0;
				 System.out.println("["+temp.row+"]["+temp.col+"] = "+val);
			 }
			 else
				 System.out.println("["+temp.row+"]["+temp.col+"] = "+temp.val);
			 
			 temp=temp.next;
		 }
		 temp=wd;
		 System.out.println("The Dependency values are: ");
		 while(temp!=null) {
			 System.out.println("["+temp.row+"]["+temp.col+"] = "+temp.val);
			 temp=temp.next;
		 }
	 }
	 
	 //Module that creates requirement input interface
    public static void create_frame() {

    	
    	firstFrame.getContentPane().setBackground(new Color(229, 255, 204));
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch (Exception e) {
            System.out.println("Look and Feel not set");
        }
        firstFrame.setLayout(null);
        firstFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        firstFrame.setBounds(15, 6, 900, 700);
       
        JButton selectfile= new JButton("Select File");
        selectfile.setToolTipText("Click to select a requirements document!");
        selectfile.setFont(new Font("Calibri", 2, 16));
        selectfile.setBackground(new Color(204, 255, 153));
        selectfile.setForeground(Color.black);
        selectfile.setBounds(50, 50, 180,30);
		        firstFrame.add(selectfile);
		        selectfile.addActionListener(new ActionListener() {
		            @Override
		             public void actionPerformed(final ActionEvent e) {
		            	 JFileChooser fileChooser = new JFileChooser("Requirements");
		         	    int returnValue = fileChooser.showOpenDialog(null);
		         	    if (returnValue == JFileChooser.APPROVE_OPTION)
		         	    {
		         	        File selectedFile = fileChooser.getSelectedFile();
		         	       // System.out.println(selectedFile.getName());
		         	        String name=selectedFile.getAbsolutePath();
		         	       System.out.println("The selected file name is "+name);
		         	        try {
		         	        	
		         	       	
		         	        }
		         	        catch(Exception es){
		         	        	
		         	        	
		         	        }
		      
		         	}
		            }
		        });
       
        
        /*Adding the table of FR-NFR dependencies*/
       String []col={"Label","Functional Requirement"};
    	String [][]data=null;
    	 DefaultTableModel model = new DefaultTableModel(data,col);  
    	Req=new JTable(model);
    	Req.getColumnModel().getColumn(0).setMaxWidth(40);
		Req.setFillsViewportHeight(true);
		Req.setEnabled(false);
		/*Req.getColumn("FP Estimates").setCellRenderer(new ButtonRenderer());
	      Req.getColumn("FP Estimates").setCellEditor(
	           new ButtonEditor(new JCheckBox()));*/
		JScrollPane js=new JScrollPane(Req);
		js.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		js.setBounds(30, 100, 380, 450);
		js.setVisible(true);
		firstFrame.add(js);
		
		JButton fpestimate= new JButton("Add FP Estimate");
		  fpestimate.setToolTipText("Click to add FP estimate for the functional requirements");
		  fpestimate.setFont(new Font("Calibri", 2, 16));
		  fpestimate.setBackground(new Color(204, 255, 153));
		  fpestimate.setForeground(Color.black);
		  fpestimate.setBounds(100, 600, 180,30);
		        firstFrame.add( fpestimate);
		        fpestimate.addActionListener(new ActionListener() {
		            @Override
		             public void actionPerformed(final ActionEvent e) {
		               int n=Req.getRowCount();
		               if(n==0) {
		            	   JOptionPane.showMessageDialog(firstFrame,"No functional reuirements added!!");
		               }
		               else {
		            	
		            	   addFPValues();
		               }
		             }
		         });
		        
		        JButton addDep= new JButton("Add Dependencies or Conflicts");
		        addDep.setToolTipText("Click to add dependencies and conflicts among the requirements");
		        addDep.setFont(new Font("Calibri", 2, 16));
		        addDep.setBackground(new Color(204, 255, 153));
		        addDep.setForeground(Color.black);
		        addDep.setBounds(350, 600, 280,30);
				        firstFrame.add( addDep);
				        addDep.addActionListener(new ActionListener() {
				            @Override
				             public void actionPerformed(final ActionEvent e) {
				              
				            	
				            	   addDepConValues();
				               
				             }
				         });
		        
		/*Section to add new FR & NFR*/
			
		    String []col3={"Label", "Non-functional Requirement"};
      	String [][]data3=null;
      	 DefaultTableModel model3 = new DefaultTableModel(data3,col3);  
      	Reqconflict=new JTable(model3);
      
      	Reqconflict.setFillsViewportHeight(true);
      	Reqconflict.setEnabled(false);
  		JScrollPane js3=new JScrollPane(Reqconflict);
    js3.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
    // js.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
    js3.setBounds(450, 100, 380, 450);
  		js3.setVisible(true);
  		firstFrame.add(js3);
		    
     //Button to save the requirements before generating PO
         
         savedata.setFont(new Font("Calibri", 2, 16));
         savedata.setBackground(new Color(204, 255, 153));
         savedata.setForeground(Color.black);
         savedata.setBounds(250, 690, 120, 30);
         savedata.setToolTipText("Click to store the requirements submitted!!");
        // firstFrame.add(savedata);
        savedata.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(final ActionEvent e) {
                 
                     save_data();
                 
             }
         });
		firstFrame.setVisible(true);
    }
    static int flag=1;
    static int countfr=0, countnfr=0;
    public static void addDepConValues() {
    //	countfr=12;
    	//countnfr=10;
    	if(loaddata==1)
    	{
    		fr1.setText(String.valueOf(countfr));
    		nfr4.setText(String.valueOf(countnfr));
    	}
    	
    	JFrame depframe=new JFrame("Set Dependencies and Conflicts");
    	depframe.getContentPane().setBackground(new Color(224, 204, 124));
        
        depframe.setLayout(null);
        depframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        depframe.setBounds(15, 6, 1200, 800);
      
        JLabel f1=new JLabel("FR Count");
        f1.setFont(new Font("Calibri", 2, 14));
         f1.setBounds(30, 20, 100, 40);
         depframe.add(f1);
    
         fr1.setBounds(100, 20, 100, 40);
        depframe.add(fr1);
        
        JLabel f2=new JLabel("NFR Count");
        f2.setFont(new Font("Calibri", 2, 14));
         f2.setBounds(230, 20, 100, 40);
         depframe.add(f2);
    
         nfr4.setBounds(320, 20, 100, 40);
        depframe.add(nfr4);
        frnfr.setFont(frnfr.getFont().deriveFont(Font.BOLD));
        JButton load= new JButton("LOAD");
        load.setToolTipText("Click to load FRs and NFRs");
        load.setFont(new Font("Calibri", 2, 16));
        load.setBackground(new Color(204, 204, 153));
        load.setForeground(Color.black);
        load.setBounds(450, 20, 180,30);
		       depframe.add(load);
		   
		        load.addActionListener(new ActionListener() {
		            @Override
		             public void actionPerformed(final ActionEvent e) {
		            	if(countfr!=0)
		            		depframe.repaint();
		            	
		            	String s1=fr1.getText();
		            	String s2=nfr4.getText();
		            	countfr=Integer.valueOf(s1);
		            	countnfr=Integer.valueOf(s2);
		            
		            	int n=countfr+countnfr+1;
		                String []col4= new String[n];
		            	  
		                int j=0;
		                
		                col4[j]="FR/NFR";
		                j++;
		                for(int i=1;i<=countfr;i++) {
		                	String header="f"+i;
		                	col4[j]=header;
		                	j++;
		                }
		                for(int i=1;i<=countnfr;i++) {
		                	String header="nf"+i;
		                	col4[j]=header;
		                	j++;
		                }
		                String [][]data4=null;
		          	 	DefaultTableModel model = new DefaultTableModel(data4,col4);  
		          	 	frnfr=new JTable(model);
		        	 	for(int i=1;i<n;i++)
		        	 		frnfr.getColumnModel().getColumn(i).setPreferredWidth(40);
		        	    DefaultTableCellRenderer header = new DefaultTableCellRenderer();
		        	     header.setFont(header.getFont().deriveFont(Font.BOLD));
		        	     TableColumnModel model2 = frnfr.getColumnModel();
		        	     for(int i=0;i<=countfr+countnfr;i++)
		        	     model2.getColumn(i).setHeaderRenderer(header);
		        	  	Object []o = new Object[1];
		        	 	for(int i=1;i<n;i++) {
			             	o = new Object[1];
			            	o[0]=col4[i];
			            	model.addRow(o);
			             	}
		        	 	frnfr.setIntercellSpacing(new Dimension(0,0));//Get rid of cell spacing

		                //Set your own renderer.  You'll have to set this for Number and Boolean too if you're using those
		                CustomRenderer cr = new CustomRenderer(frnfr.getDefaultRenderer(Object.class), Color.green, Color.blue, Color.pink, Color.yellow);
		               frnfr.setDefaultRenderer(Object.class, cr);


		        	 	frnfr.setFillsViewportHeight(true);
		        	 	frnfr.setRowHeight(30);
		        	 	frnfr.getColumnModel().getColumn(0).setPreferredWidth(60);
		        	 	 frnfr.getColumnModel().getColumn(0).setCellRenderer(new RowHeaderRenderer());
		        	 	JScrollPane js4=new JScrollPane(frnfr);//, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		      		  js4.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		      		  js4.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		      		   frnfr.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		      		  js4.setBounds(25, 70, 900, 680);
		      		js4.setVisible(true);
		      		//jp2.add(js2);
		      		depframe.add(js4);
		      		if(E_FN!=null) {
		      			Edge1 p=E_FN;
		      			while(p!=null) {
		      				String h1=p.id1;
		      				String h2=p.id2;
		      				int num=p.value;
		      				int row=0;
		      				int col=0;
		      				for(int i=0;i<countfr;i++) {
		      					String t=String.valueOf(frnfr.getValueAt(i, 0));
		      					if((t.compareTo(h1))==0)
		      						row=i;
		      				}
		      				for(int k=countfr+1; k<=countfr+countnfr;k++) {
		      					String t=String.valueOf(frnfr.getColumnName(k));
		      					if((t.compareTo(h2))==0)
		      						col=k;
		      				}
		      				System.out.println("h1= "+h1+" h2= "+h2+" row="+row+" Col = "+col);
		      				
		      					frnfr.getModel().setValueAt(num, row, col); 
		      					frnfr.getModel().setValueAt(num, col-1, row+1); 
		      				
		      				p=p.next;
		      			}
		      		}
		      		if(E_NN!=null) {
		      			Edge1 p=E_NN;
		      			while(p!=null) {
		      				String h1=p.id1;
		      				String h2=p.id2;
		      				int num=p.value;
		      				int row=0;
		      				int col=0;
		      				for(int i=countfr;i<countfr+countnfr;i++) {
		      					String t=String.valueOf(frnfr.getValueAt(i, 0));
		      					if((t.compareTo(h1))==0)
		      						row=i;
		      				}
		      				for(int k=countfr; k<=countfr+countnfr;k++) {
		      					String t=String.valueOf(frnfr.getColumnName(k));
		      					if((t.compareTo(h2))==0)
		      						col=k;
		      				}
		      				System.out.println("h1= "+h1+" h2= "+h2+" row="+row+" Col = "+col);
		      				
		      					frnfr.getModel().setValueAt(num, row, col); 
		      					frnfr.getModel().setValueAt(num, col-1, row+1); 
		      				
		      				p=p.next;
		      			}
		      		}
		      		if(E_FF!=null) {
		      			Edge2 p=E_FF;
		      			while(p!=null) {
		      				String h1=p.id1;
		      				String h2=p.id2;
		      			
		      				int row=0;
		      				int col=0;
		      				for(int i=0;i<countfr;i++) {
		      					String t=String.valueOf(frnfr.getValueAt(i, 0));
		      					if((t.compareTo(h1))==0)
		      						row=i;
		      				}
		      				for(int k=1; k<=countfr;k++) {
		      					String t=String.valueOf(frnfr.getColumnName(k));
		      					if((t.compareTo(h2))==0)
		      						col=k;
		      				}
		      				System.out.println("h1= "+h1+" h2= "+h2+" row="+row+" Col = "+col);
		      				
		      					frnfr.getModel().setValueAt(1, row, col); 
		      					frnfr.getModel().setValueAt(-1, col-1, row+1); 
		      				
		      				p=p.next;
		      			}
		      		}
		      		 frnfr.getModel().addTableModelListener(new TableModelListener() {
		      	         public void tableChanged(TableModelEvent e) {
		      	        	 if(flag==1) {
		      	             System.out.println("Column: " + e.getColumn() + " Row: " + e.getFirstRow());
		      	             int col=e.getColumn();
		      	             int row=e.getFirstRow();
		      	             int type=0;
		      	             String s=String.valueOf(frnfr.getValueAt(row, col));
		      	             if((s.compareTo(""))!=0) {
		      	            		String s1=frnfr.getColumnName(col);
		      	        			String s2=String.valueOf(frnfr.getValueAt(row, 0));
		      	        			if((s1.compareTo(s2))==0) {
		      	        				flag=0;
		      	        				frnfr.getModel().setValueAt("", row, col);
		      	        		    	flag=1;
		      	        				JOptionPane.showMessageDialog(depframe, "Inavlid Entry");
		      	        			}
		      	        			else {	
		      	            	 int val=Integer.valueOf(s);
		      	            	 if(row>=0 && row<countfr) {
		      	            		 System.out.println("In Upper half");
		      	            		 //Upper half of the table
		      	            		 if(col>=1 && col<=countfr) {
		      	            			 //FR-FR portion
		      	            			 
		      	            			 System.out.println("Case FR-FR");
		      	            			 if(val==1 || val==-1) {
		      	                        	 setValue(row,col,1,type);
		      	                             System.out.println("Entered Value="+s);
		      	                        	 }
		      	                        	 else { 
		      	                        		 JOptionPane.showMessageDialog(depframe, "Inavlid Value");
		      	                        		 setValue(row,col,0,type);
		      	                        	 }
		      	            		 }
		      	            		 else if(col>=countfr+1 && col<=countfr+countnfr) {
		      	            			 System.out.println("Case FR-NFR");
		      	            			 //FR-NFR portion
		      	            			 type=1;
		      	            			 if(val>=0 && val<=10) {
		      	                        	 setValue(row,col,1,type);
		      	                             System.out.println("Entered Value="+s);
		      	                        	 }
		      	                        	 else { 
		      	                        		 JOptionPane.showMessageDialog(depframe, "Inavlid Value! Value must be in the range 0-10!");
		      	                        		 setValue(row,col,0,type);
		      	                        	 }
		      	            		 }
		      	            	 }
		      	            	 else if(row>=countfr && row < countfr+countnfr) {
		      	            		 System.out.println("In lower half");
		      	            		 //Lower half of the table
		      	            		 if(col>=1 && col<=countfr) {
		      	            			 System.out.println("Case FR-NFR");
		      	            			 //NFR-FR portion
		      	            			 type=1;
		      	            			 if(val>=0 && val<=10) {
		      	                        	 setValue(row,col,1,type);
		      	                             System.out.println("Entered Value="+s);
		      	                        	 }
		      	                        	 else { 
		      	                        		 JOptionPane.showMessageDialog(depframe, "Inavlid Value");
		      	                        		 setValue(row,col,0,type);
		      	                        	 }
		      	            		 }
		      	            		 else if(col>=countfr+1 && col<=countfr+countnfr) {
		      	            			 System.out.println("Case NFR-NFR");
		      	            			 //NFR-NFR portion
		      	            			 type=2;
		      	            			 if(val>=0 && val<=100) {
		      	                        	 setValue(row,col,1,type);
		      	                             System.out.println("Entered Value="+s);
		      	                        	 }
		      	                        	 else { 
		      	                        		 JOptionPane.showMessageDialog(depframe, "Inavlid Value! Value must be in the range 0-100!");
		      	                        		 setValue(row,col,0,type);
		      	                        	 }
		      	            		 }
		      	            	 }
		      	            
		      	            	 
		      	             }
		      	        	 }
		      	         }
		      	         }
		      	     });
		      	    
		        
		             }
		            
		        	
		         });
		        ////Button to save the requirements before generating PO
		         
		         JButton save_data=new JButton("Save Constraints");
		         save_data.setFont(new Font("Calibri", 2, 16));
		         save_data.setBackground(new Color(204, 204, 153));
		         save_data.setForeground(Color.black);
		         save_data.setBounds(1000, 200, 180, 30);
		         save_data.setToolTipText("Click to store the requirement constraints!!");
		       depframe.add(save_data);
		        save_data.addActionListener(new ActionListener() {
		             @Override
		             public void actionPerformed(final ActionEvent e) {
		                 	String s=String.valueOf(frnfr.getValueAt(0, 2));
		                 	loaddata=1;
		                     save_data();
		                 
		             }
		         });
		        //Button to add function point estimates of the FRs
		        JButton fpestimate= new JButton("Add FP Estimate");
				  fpestimate.setToolTipText("Click to add FP estimate for the functional requirements");
				  fpestimate.setFont(new Font("Calibri", 2, 16));
				  fpestimate.setBackground(new Color(204, 204, 153));
				  fpestimate.setForeground(Color.black);
				  fpestimate.setBounds(1000, 300, 180,30);
				      depframe.add( fpestimate);
				        fpestimate.addActionListener(new ActionListener() {
				            @Override
				             public void actionPerformed(final ActionEvent e) {
				              
				               if(countfr==0 || countnfr==0) {
				            	   JOptionPane.showMessageDialog(firstFrame,"FR/NFR count not set!!");
				               }
				               else {
				            	
				            	   addFPValues();
				               }
				             }
				         });
      
    	 	
    	 	//frnfr.getColumnModel().getColumn(1).setPreferredWidth(20);
    		
    	
    	//adding parameters to the table
  
     	
     
     	/*for(int i=0;i<n;i++) {
    		for(int k=1;k<n-1;k++) {
    			frnfr.setValueAt("", i, k);
    		}
     	}*/
     	
	JLabel l1=new JLabel("Value Range");
	l1.setBounds(1000, 420, 80,30);
	depframe.add(l1);
	JLabel l2=new JLabel("1 or -1");
	l2.setBounds(1000, 460, 80,30);
	depframe.add(l2);
	JLabel l3=new JLabel("1-10");
	l3.setBounds(1000, 530, 80,30);
	depframe.add(l3);
	JLabel l4=new JLabel("1-100");
	l4.setBounds(1000, 600, 80,30);
	depframe.add(l4);
	JLabel l5=new JLabel("Type");
	l5.setBounds(1080, 420, 80,30);
	depframe.add(l5);
	JLabel l6=new JLabel("FR-FR");
	l6.setBounds(1080, 460, 80,30);
	depframe.add(l6);
	JLabel l7=new JLabel("FR-NFR");
	l7.setBounds(1080, 530, 80,30);
	depframe.add(l7);
	JLabel l8=new JLabel("NFR-NFR");
	l8.setBounds(1080, 600, 80,30);
	depframe.add(l8);
     depframe.setVisible(true);
     JPanel p1=new JPanel();
     p1.setBounds(950, 460, 30, 30);
     depframe.add(p1);
     p1.setBackground(Color.yellow);
     JPanel p2=new JPanel();
     p2.setBounds(950, 530, 30, 30);
     depframe.add(p2);
     p2.setBackground(Color.green);
     JPanel p3=new JPanel();
     p3.setBounds(950, 600, 30, 30);
     depframe.add(p3);
     p3.setBackground(new Color(83, 130, 161));
    
    }
    public static void setValue(int row, int col, int p, int type) {
    	flag=0;
    	if(p==1) {
    	 String s=String.valueOf(frnfr.getValueAt(row, col));
    	 int val=Integer.valueOf(s);
    	 if(type==0) {
    	 if(val==1)
    		 frnfr.getModel().setValueAt("-1", col-1, row+1);
    	 else
    		 frnfr.getModel().setValueAt("1", col-1, row+1);
    	}
    	 else
    		 frnfr.getModel().setValueAt(s, col-1, row+1); 
    	}
    	else
    		 frnfr.getModel().setValueAt("", row, col);
    	flag=1;
    }

    public static class CustomRenderer implements TableCellRenderer{
        TableCellRenderer render;
        Border b;
        public CustomRenderer(TableCellRenderer r, Color top, Color left,Color bottom, Color right){
            render = r;

            //It looks funky to have a different color on each side - but this is what you asked
            //You can comment out borders if you want too. (example try commenting out top and left borders)
            b = BorderFactory.createCompoundBorder();
            b = BorderFactory.createCompoundBorder(b, BorderFactory.createMatteBorder(2,0,0,0,top));
            b = BorderFactory.createCompoundBorder(b, BorderFactory.createMatteBorder(0,2,0,0,left));
            b = BorderFactory.createCompoundBorder(b, BorderFactory.createMatteBorder(0,0,2,0,bottom));
            b = BorderFactory.createCompoundBorder(b, BorderFactory.createMatteBorder(0,0,0,2,right));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table,
                Object value, boolean isSelected, boolean hasFocus, int row,
                int column) {
            JComponent result = (JComponent)render.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            result.setBorder(b);
            
            int[][] coordinatesYellow = new int[1000][2];
            int[][] coordinatesGreen = new int[1000][2];
            int[][] coordinatesBlue = new int[1000][2];
            int count1=0, count2=0, count3=0;
            int m=0,n=0;
            for(int i=0;i<countfr;i++) {
            	for (int j=1;j<=countfr;j++) {
            		coordinatesYellow[m][n]=i;
            		n++;
            		coordinatesYellow[m][n]=j;
            		m++;
            		n=0;
            	}
            		
            }
            count1=m;
            m=0;
            n=0;
            for(int i=0;i<countfr;i++) {
            	for (int j=countfr+1;j<=countfr+countnfr;j++) {
            		coordinatesGreen[m][n]=i;
            		n++;
            		coordinatesGreen[m][n]=j;
            		m++;
            		n=0;
            	}
            		
            }
            for(int i=countfr;i<countfr+countnfr;i++) {
            	for (int j=1;j<=countfr;j++) {
            		coordinatesGreen[m][n]=i;
            		n++;
            		coordinatesGreen[m][n]=j;
            		m++;
            		n=0;
            	}
            		
            }
            count2=m;
            m=0;
            n=0;
            for(int i=countfr;i<countfr+countnfr;i++) {
            	for (int j=countfr+1;j<=countfr+countnfr;j++) {
            		coordinatesBlue[m][n]=i;
            		n++;
            		coordinatesBlue[m][n]=j;
            		m++;
            		n=0;
            	}
            		
            }
            count3=m;
            boolean isYellow = false;
            for (int i = 0; i <= count1; i++) {
                        if ((row == coordinatesYellow[i][0]) && (column == coordinatesYellow[i][1])) {
                            result.setBackground(Color.yellow);
                            isYellow = true;
                        }
                    }
            for (int i = 0; i <=count2; i++) {
                if ((row == coordinatesGreen[i][0]) && (column == coordinatesGreen[i][1])) {
                    result.setBackground(Color.green);
                    isYellow = true;
                }
            }
            for (int i = 0; i <=count3; i++) {
                if ((row == coordinatesBlue[i][0]) && (column == coordinatesBlue[i][1])) {
                    result.setBackground(new Color(83, 130, 161));
                    isYellow = true;
                }
            }
           // if( !isYellow )
             // result.setBackground(Color.white);
            return result;
        }

    }
    

   public static void do_check(int t, String s, String s2, String s3) {
	   FRup=null;
	   NFRup=null;
	   E_NNup=null;
	   E_FNup=null;
	   E_FFup=null;
	   seq_up1=null;
	   System.out.println("The type is "+t);
	   if(t==0) {
		   //Do nothing
	   }
	   else {
		   
		   // First check if the FR is previously frozen
		   System.out.println("The frozen set is ");
			 Node ro=prevFro;
			 //	String s1=fr2.getSelectedItem().toString();
			 	System.out.println("s= "+s);
			 int flag=0;
			 while(ro!=null) {
				 System.out.print("item="+ro.id+" ");
				 if((ro.id.compareTo(s))==0)
			   			flag=1;
				 ro=ro.next;
			 }
		  
		   	Node p=prevFro;
		   	
		  /* 	while(p!=null)
		   	{
		   		System.out.println("Compairing "+p.id+" "+s1);
		   		if((p.id.compareTo(s1))==0)
		   			flag=1;
		   		p=p.next;
		   	}*/
		   	System.out.println("The flag value is "+flag);
		   	if(flag==0) {
		   		//Not frozen yet so do nothing
		   	}
		   	else if(flag==1) {
		   		System.out.println("Yes its frozen");
		   		// First Check in which iteration it was frozen from flist
		   		plist k=flist;
		   		int num=0;
		   		while(k!=null) {
		   			num=k.name;
		   			sNode v=k.begin;
		   			int b=0;
		   			while(v!=null) {
		   				if((v.id.compareTo(s))==0)
		   				{
		   					b=1;
		   					break;
		   				}
		   				v=v.next;
		   			}
		   			if(b==1)
	   					break;
		   			k=k.next;
		   		}
		   		if(iteration!=0) {
		   		
		   			
		   		}
		   		else {
		   		 JOptionPane.showMessageDialog(firstFrame,"Set the iteration!!");
		   		}
		   		//Now based on the dataset in that iteration recreate the PO
		   		if(num!=0) {
		   		String path="Itr"+String.valueOf(num);
		   		FileReader f1;
		   		// Create FR list
		   		
		   		try {
		   	    	f1=new FileReader(path+"\\FRList.txt");
		   	    	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		//Reading FR
		   	    			while((i=f1.read())!=10) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    				if(i==32) {
		   	    					if((temp.compareTo("count"))==0)
		   	    						break;
		   	    				}
		   	    			}
		   	    			fe1=temp;
		   	    			if((fe1.compareTo("count"))==0)
		   	    				break;
		   	    			
		   	    			Node ed=new Node();
		   	    			ed.id=fe1;
		   	    			ed.next=null;
		   	    			if(FRup==null) {
		   	    				FRup=ed;
		   	    			}
		   	    			else {
		   	    				Node et=FRup;
		   	    				while(et.next!=null)
		   	    					et=et.next;
		   	    				et.next=ed;
		   	    			}
		   	    	}
		   	    	f1.close();
		   	    	}
		   	    	catch(IOException i) {
		   	    		
		   	    	}
		   		
		   		//Create NFR list
		   		
		   		try {
		   	    	f1=new FileReader(path+"\\NFRList.txt");
		   	    	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		//Reading FR
		   	    			while((i=f1.read())!=10) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    				if(i==32) {
		   	    					if((temp.compareTo("count"))==0)
		   	    						break;
		   	    				}
		   	    			}
		   	    			fe1=temp;
		   	    			if((fe1.compareTo("count"))==0)
		   	    				break;
		   	    			
		   	    			Node ed=new Node();
		   	    			ed.id=fe1;
		   	    			ed.priority=0;
		   	    			ed.next=null;
		   	    			if(NFRup==null) {
		   	    				NFRup=ed;
		   	    			}
		   	    			else {
		   	    				Node et=NFRup;
		   	    				while(et.next!=null)
		   	    					et=et.next;
		   	    				et.next=ed;
		   	    			}
		   	    	}
		   	    	f1.close();
		   	    	}
		   		
		   	    	catch(IOException i) {
		   	    		
		   	    	}
		   		//Adding the NFR Priorities
		   		try {
		   	    	f1=new FileReader(path+"\\Priority.txt");
		   	    	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		//Reading FR
		   	    			while((i=f1.read())!=10) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			System.out.println("Temp= "+temp);
		   	    			if((temp.compareTo(""))!=0) {
		   	    				int pr=Integer.valueOf(temp);
		   	    				Node et=NFRup;
		   	    				while(et.next!=null) {
		   	    					if(et.priority==0) {
		   	    						et.priority=pr;
		   	    						break;
		   	    					}
		   	    					et=et.next;
		   	    				}
		   	    			}

		   	    	}
		   	    	System.out.println("Priorities read");
		   	    	f1.close();
		   	    	}
		   		
		   	    	catch(IOException i) {
		   	    		
		   	    	}
		   		
		   		//Creating the sequence of that iteration
		   		
		   		
		   		try {
		   	    	f1=new FileReader(path+"\\SeqList.txt");
		   	    	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		plist node=new plist();
		   	    		node.name=1;
		   	    		node.begin=null;
		   	    		node.next=null;
		   	    		if(seq_up1==null)
		   	    			seq_up1=node;
		   	    		else {
		   	    			plist j=seq_up1;
		   	    			while(j.next!=null)
		   	    				j=j.next;
		   	    			j.next=node;
		   	    		}
		   	    		//Reading FR List
		   	    			while((i=f1.read())!=10 ) {
		   	    				if(i==-1)
		   	    					break;
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    				while((i=f1.read())!=32) {
		   	    					if(i==-1)
			   	    					break;
		   	    					c=(char)i;
			   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
			   	    					temp=temp.concat(Character.toString(c));
		   	    				}
		   	    				if(i==-1)
		   	    					break;
		   	    				System.out.println("Temp= "+temp);
		   	    				if((temp.compareTo(""))!=0) {
		   	    				sNode child=new sNode();
		   	    				child.id=temp;
		   	    				child.next=null;
		   	    				if(node.begin==null)
		   	    				{
		   	    					node.begin=child;
		   	    				}
		   	    				else {
		   	    					sNode r=node.begin;
		   	    					while(r.next!=null)
		   	    						r=r.next;
		   	    					r.next=child;
		   	    				}
		   	    				}
		   	    				temp="";
		   	    				
		   	    			}
		   	    		if(i==-1)
		   	    			break;

		   	    	}
		   	 	System.out.println("Sequence read");
		   	    	f1.close();
		   	    	}
		   		
		   	    	catch(IOException i) {
		   	    		
		   	    	}
		   		
		   		
		   		//Create Dependency list
		   		
		   		try {
		   	    	f1=new FileReader(path+"\\DepList.txt");
		   	    	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		//Reading FR
		   	    			while((i=f1.read())!=32) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			fe1=temp;
		   	    			if((fe1.compareTo("count"))==0)
		   	    				break;
		   	    			temp="";
		   	    			//Reading NFR
		   	    			while((i=f1.read())!=32) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			fe2=temp;
		   	    			//System.out.println("fe2="+fe2);
		   	    			temp="";
		   	    			//Reading value
		   	    			while((i=f1.read())!=10) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			int val=Integer.valueOf(temp);
		   	    			Edge1 ed=new Edge1();
		   	    			ed.id1=fe1;
		   	    			ed.id2=fe2;
		   	    			ed.value=val;
		   	    			ed.next=null;
		   	    			if(E_FNup==null) {
		   	    				E_FNup=ed;
		   	    			}
		   	    			else {
		   	    				Edge1 et=E_FNup;
		   	    				while(et.next!=null)
		   	    					et=et.next;
		   	    				et.next=ed;
		   	    			}
		   	    	}
		   	 	System.out.println("Dependency read");
		   	 	System.out.println("the dependency list is");
		   	 	Edge1 t1=E_FNup;
		   	 while(t1!=null) {
		   	 		if((t1.id1.compareTo(s))==0 && (t1.id2.compareTo(s2))==0)
		   	 			t1.value=Integer.valueOf(s3);
		   	 		t1=t1.next;
		   	 	}
		   	    t1=E_FNup;
		   	 	while(t1!=null) {
		   	 		System.out.println(t1.id1+" "+t1.id2+" "+t1.value);
		   	 		t1=t1.next;
		   	 	}
		   	    	f1.close();
		   	    	}
		   	    	catch(IOException i) {
		   	    		
		   	    	}
		   	 
		   		
		   		//Create Conflict list
		   		
		   	   	try {
	   	        	f1=new FileReader(path+"\\ConList.txt");
	   	        	int i;
		   	    	char c;
		   	    	String temp;
		   	    	String fe1,fe2,fe3;
		   	    	while((i=f1.read())!=-1) {
		   	    		
		   	    		c=(char)i;
		   	    	//	System.out.println("C="+c);
		   	    		temp="";
		   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    			temp=temp.concat(Character.toString(c));
		   	    		//Reading NFR
		   	    			while((i=f1.read())!=32) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			fe1=temp;
		   	    			if((fe1.compareTo("count"))==0)
		   	    				break;
		   	    			temp="";
		   	    			//Reading NFR
		   	    			while((i=f1.read())!=32) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			fe2=temp;
		   	    			//System.out.println("fe2="+fe2);
		   	    			temp="";
		   	    			//Reading conflict value
		   	    			while((i=f1.read())!=10) {
		   	    				c=(char)i;
		   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
		   	    					temp=temp.concat(Character.toString(c));
		   	    			}
		   	    			int val=Integer.valueOf(temp);
		   	    			Edge1 ed=new Edge1();
		   	    			ed.id1=fe1;
		   	    			ed.id2=fe2;
		   	    			ed.value=val;
		   	    			ed.next=null;
		   	    			if(E_NNup==null) {
		   	    				E_NNup=ed;
		   	    			}
		   	    			else {
		   	    				Edge1 et=E_NNup;
		   	    				while(et.next!=null)
		   	    					et=et.next;
		   	    				et.next=ed;
		   	    			}
		   	    	}
		   	 	System.out.println("Conflicts read");
		   	 Edge1 t1=E_NNup;
		   	 	while(t1!=null) {
		   	 		System.out.println(t1.id1+" "+t1.id2+" "+t1.value);
		   	 		t1=t1.next;
		   	 	}
		   		f1.close();
	   	        	}
	   	        	catch(IOException i) {
	   	        		
	   	        	}
		   	   	
		   		//Create Temporal list
		   		
		   	    	try {
		   	        	f1=new FileReader(path+"\\TemList.txt");
		   	        	int i;
			   	    	char c;
			   	    	String temp;
			   	    	String fe1,fe2,fe3;
			   	    	while((i=f1.read())!=-1) {
			   	    		
			   	    		c=(char)i;
			   	    	//	System.out.println("C="+c);
			   	    		temp="";
			   	    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
			   	    			temp=temp.concat(Character.toString(c));
			   	    		//Reading FR
			   	    			while((i=f1.read())!=32) {
			   	    				c=(char)i;
			   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
			   	    					temp=temp.concat(Character.toString(c));
			   	    			}
			   	    			fe1=temp;
			   	    			if((fe1.compareTo("count"))==0)
			   	    				break;
			   	    			temp="";
			   	    			//Reading FR
			   	    			while((i=f1.read())!=10) {
			   	    				c=(char)i;
			   	    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
			   	    					temp=temp.concat(Character.toString(c));
			   	    			}
			   	    			fe2=temp;
			   	    			//System.out.println("fe2="+fe2);
			   	    			
			   	    			Edge2 ed=new Edge2();
			   	    			ed.id1=fe1;
			   	    			ed.id2=fe2;
			   	    			ed.next=null;
			   	    			if(E_FFup==null) {
			   	    				E_FFup=ed;
			   	    			}
			   	    			else {
			   	    				Edge2 et=E_FFup;
			   	    				while(et.next!=null)
			   	    					et=et.next;
			   	    				et.next=ed;
			   	    			}
			   	    	}
			   	 	System.out.println("Temporal read");   	        	
			   	    	f1.close();
		   	        	}
		   	    	
		   	        	catch(IOException i) {
		   	        		
		   	        	}
		   	    	//Create the clusters
		   	 	System.out.println("choice="+choice);
		   	    	if(choice==0) {
		   	    		System.out.println("choice="+choice);
		   	    		try {
		   	    		FileReader fp=new FileReader(path+"\\Parameter.txt");
		   	    		int i=0;
		   	    		String temp="";
		   	    		while((i=fp.read())!=-1) {
		   	    			System.out.println("i="+i);
		   	    			char c=(char)i;
		   	    			if(i!=10 && i!=13)
		   	    				temp=temp.concat(Character.toString(c));
		   	    			
		   	    			
		   	    		}
		   	    		System.out.println("temp="+temp);
		   	    		choice=Integer.valueOf(temp);
		   	    		}catch(IOException pz) {
		   	    			
		   	    		}
		   	    	}
		   	    	create_basicClustersup();
		   	    	create_macroClustersup();
		   	    	create_requirementSetup();
		   	    	generate_POup();
		   	    	PO d=prootup;
		   	    	System.out.println("The partial order");
		   	    	while(d!=null) {
		   	    		System.out.println(d.id1+"->"+d.id2);
		   	    		d=d.next;
		   	    	}
		   	    	remove_transitiveup();
		   	    	exist_pathup();
		   	    	setTextup();
		   	    	int vio=compare_PO();
		   	    	if(vio==1) {
		   	    		final JPanel panel1 = new JPanel();
		          	   JButton v=new JButton("View PO");
		          	 
		          	  v.addActionListener(new ActionListener() {
		                  @Override
		                  public void actionPerformed(final ActionEvent e) {
		                      System.out.println("here to display");
		                	  Node p=FRup;
		                  	System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
		                  	 Graph graph=new MultiGraph("");
		                  	if(choice==1) {
		                  		 graph = new MultiGraph("Optimal Partial Order || Parameter: NFR Conflict");
		                      	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: NFR Conflict");
		                  	}
		                  	else if(choice==2) {
		                  		graph = new MultiGraph("Optimal Partial Order || Parameter: NFR Priority");
		                      	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: NFR Priority");	
		                  	}
		                  	else if(choice==3) {
		                  		graph = new MultiGraph("Optimal Partial Order || Parameter: Product");
		                      	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: Product");
		                  	}
		                  	else if(choice==4) {
		                  	graph = new MultiGraph("Optimal Partial Order || Parameter: Weighted Sum");
		                      graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: Weighted Sum");
		                  	}
		                      graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;text-size: 16;fill-color: yellow;text-mode:normal; text-style: bold; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
		                      
		                  	while(p!=null) {
		                  		graph.addNode(p.id);
		                  		p=p.next;
		                  	}
		                  	PO k=prootup;
		                  	while(k!=null) {
		                  		String ed=k.id1+k.id2;
		                  		//System.out.println("Edge is"+k.id1+"->"+k.id2);
		                  		final Edge edge = graph.addEdge(ed, k.id1, k.id2, true);
		                         edge.addAttribute("layout.weight", 6);


		                  		k=k.next;
		                  	}
		                  	for (final org.graphstream.graph.Node node : graph) {
		                          node.addAttribute("ui.label", node.getId());
		                          node.addAttribute("layout.weight", 150);
		                          String s=node.getId();
		                         
		                      }
		                  	Viewer viewer = graph.display();
		                  
		                  	 viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);

		                      
		                  }
		              });
		          	 panel1.add(v);
		          	   JOptionPane.showMessageDialog(firstFrame, panel1,"Partial Order changed!!",JOptionPane.OK_CANCEL_OPTION);
		          	 
		   	    	}
		   	    	else {
		   	    	 JOptionPane.showMessageDialog(firstFrame,"Partial Order relation remains intact!! Change can be accepted.");
		   	    	}
		   	    	
		   	}
		   	}		
		   	
	   }
		   	
   }

   public static void create_basicClustersup() {
       Node nfr = NFRup;
       bcHeadup = null;
       while (nfr != null) {
           final BC temp = new BC();
           temp.Nid = nfr.id;
           Edge1 fn = E_FNup;
           FRDep flist = null;
           while (fn != null) {
               if (fn.id2.compareTo(nfr.id) == 0) {
                   final FRDep fnode = new FRDep();
                   fnode.id = fn.id1;
                   fnode.val = fn.value;
                   fnode.next = null;
                   if (flist == null) {
                       flist = fnode;
                   }
                   else {
                       FRDep p;
                       for (p = flist; p.next != null; p = p.next) {}
                       p.next = fnode;
                   }
               }
               fn = fn.next;
           }
           if (flist != null) {
               temp.begin = flist;
           }
           temp.next = null;
           if (bcHeadup == null) {
               bcHeadup = temp;
           }
           else {
               BC q;
               for (q = bcHeadup; q.next != null; q = q.next) {}
               q.next = temp;
           }
           nfr = nfr.next;
       }
       display_BasicClustersup();
   }
   public static void display_BasicClustersup() {
       BC p = bcHeadup;
       //System.out.println();
       System.out.println("The basic clusters are:");
       //System.out.println();
       while (p != null) {
           System.out.println("NFR: " + p.Nid);
           for (FRDep q = p.begin; q != null; q = q.next) {
               System.out.println("FR: " + q.id);
               System.out.println("Dependency Edge Weight: " + q.val);
           }
           //System.out.println();
           p = p.next;
       }
   }
   public static void create_macroClustersup() {
       Edge1 Nconflict = E_NNup;
       mcHeadup = null;
       while (Nconflict != null) {
           BC p = bcHeadup;
           final MC temp = new MC();
           temp.next = null;
           temp.Blist = null;
           temp.CEdge = 1;
           while (p != null) {
               if (p.Nid.compareTo(Nconflict.id1) == 0 || p.Nid.compareTo(Nconflict.id2) == 0) {
                   final BC newBC = new BC();
                   newBC.Nid = p.Nid;
                   newBC.begin = p.begin;
                   newBC.next = null;
                   if (temp.Blist == null) {
                       temp.Blist = newBC;
                   }
                   else {
                       BC q;
                       for (q = temp.Blist; q.next != null; q = q.next) {}
                       q.next = newBC;
                   }
               }
               p = p.next;
           }
           if (mcHeadup == null) {
               mcHeadup = temp;
           }
           else {
               MC r;
               for (r = mcHeadup; r.next != null; r = r.next) {}
               r.next = temp;
           }
           Nconflict = Nconflict.next;
       }
     
   }

   public static void create_requirementSetup() {
       rootup = null;
       for (Node p = FRup; p.next != null; p = p.next) {
           for (Node q = p.next; q != null; q = q.next) {
               final Rpair temp = new Rpair();
               temp.id1 = p.id;
               temp.id2 = q.id;
               temp.done = 0;
               temp.next = null;
               if (rootup == null) {
                   rootup = temp;
               }
               else {
                   Rpair s;
                   for (s = rootup; s.next != null; s = s.next) {}
                   s.next = temp;
               }
           }
       }
   }

   public static void generate_POup() {
   	Node j=FRup;
   	int co=0;
   	while(j!=null)
   	{
   		co++;
   		j=j.next;
   	}
   	
       prootup = null;
       for (Rpair point = rootup; point != null; point = point.next) {
           Edge2 p = E_FFup;
           int tflag = 0;
           while (p != null) {
               if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
                   tflag = 1;
                   break;
               }
               p = p.next;
           }
           if (tflag == 1) {
               System.out.println("Temporal Edge found for : " + point.id1 + " " + point.id2);
               point.done = 1;
               final PO temp = new PO();
               temp.id1 = p.id1;
               temp.id2 = p.id2;
               temp.next = null;
               if (prootup == null) {
                   prootup = temp;
               }
               else {
                   PO r;
                   for (r = prootup; r.next != null; r = r.next) {}
                   r.next = temp;
               }
           }
       }
       for (Rpair point = rootup; point != null; point = point.next) {
           String fr1 = point.id1;
           String fr2 = point.id2;
           System.out.println("Checking for " + fr1 + " " + fr2);
           if (point.done == 0) {
               fr1 = point.id1;
               fr2 = point.id2;
               //System.out.println("Checking for " + fr1 + " " + fr2);
               int flagmc1 = 0;
               int flagmc2 = 0;
               int flagmc3 = 0;
               for (MC p2 = mcHeadup; p2 != null; p2 = p2.next) {
                   flagmc1 = 0;
                   flagmc2 = 0;
                   for (BC q = p2.Blist; q != null; q = q.next) {
                       for (FRDep r2 = q.begin; r2 != null; r2 = r2.next) {
                           if (r2.id.compareTo(fr1) == 0) {
                               flagmc1 = 1;
                           }
                           if (r2.id.compareTo(fr2) == 0) {
                               flagmc2 = 1;
                           }
                       }
                   }
                   if (flagmc1 == 1 && flagmc2 == 1) {
                       flagmc3 = 1;
                       break;
                   }
               }
               if (flagmc3 == 1) {
                   point.done = 1;
                   System.out.println("Belong to same macro cluster " + fr1 + " " + fr2);
                   System.out.println("choice ="+choice);
                   if (choice == 1) {
                       case1up(fr1, fr2);
                   }
                   else if (choice == 2) {
                       case2up(fr1, fr2);
                   }
                   else if (choice == 3) {
                       case3up(fr1, fr2);
                   }
                   else if (choice == 4) {
                       case4up(fr1, fr2);
                   }
               }
               else {
                   int rflag1 = 0;
                   int rflag2 = 0;
                   LNFR1 = null;
                   LNFR2 = null;
                   for (BC bcluster = bcHeadup; bcluster != null; bcluster = bcluster.next) {
                       FRDep s = bcluster.begin;
                       while (s != null) {
                           if (s.id.compareTo(point.id1) == 0) {
                               rflag1 = 1;
                               final Node temp2 = new Node();
                               temp2.id = bcluster.Nid;
                               temp2.next = null;
                               if (LNFR1 == null) {
                                   LNFR1 = temp2;
                                   break;
                               }
                               Node q2;
                               for (q2 = LNFR1; q2.next != null; q2 = q2.next) {}
                               q2.next = temp2;
                               break;
                           }
                           else {
                               s = s.next;
                           }
                       }
                   }
                   for (BC bcluster = bcHeadup; bcluster != null; bcluster = bcluster.next) {
                       FRDep s = bcluster.begin;
                       while (s != null) {
                           if (s.id.compareTo(point.id2) == 0) {
                               rflag2 = 1;
                               final Node temp2 = new Node();
                               temp2.id = bcluster.Nid;
                               temp2.next = null;
                               if (LNFR2 == null) {
                                   LNFR2 = temp2;
                                   break;
                               }
                               Node q2;
                               for (q2 = LNFR2; q2.next != null; q2 = q2.next) {}
                               q2.next = temp2;
                               break;
                           }
                           else {
                               s = s.next;
                           }
                       }
                   }
                   int count = 0;
                   int noteq = 0;
                   if (rflag1 == 1 && rflag2 == 1) {
                       Node l1 = LNFR1;
                       int check = 0;
                       while (l1 != null) {
                           Node l2 = LNFR2;
                           check = 0;
                           while (l2 != null) {
                               if (l1.id.compareTo(l2.id) == 0) {
                                   check = 1;
                                   ++count;
                                   break;
                               }
                               l2 = l2.next;
                           }
                           l1 = l1.next;
                           if (check == 0) {
                               noteq = 1;
                           }
                       }
                       l1 = LNFR2;
                       check = 0;
                       while (l1 != null) {
                           Node l2 = LNFR1;
                           check = 0;
                           while (l2 != null) {
                               if (l1.id.compareTo(l2.id) == 0) {
                                   check = 1;
                                   ++count;
                                   break;
                               }
                               l2 = l2.next;
                           }
                           l1 = l1.next;
                           if (check == 0) {
                               noteq = 1;
                           }
                       }
                   }
                   if (count > 0) {
                       point.done = 1;
                       caseBup(fr1, fr2);
                   }
               }
           }
           for (PO u = prootup; u != null; u = u.next) {
               if (u.next == null) {
                   //System.out.println("added edge is : " + u.id1 + "->" + u.id2);
                   break;
               }
           }
           final int f = check_cycleup();
           if (f == 1) {
               System.out.println("Loop is formed");
               PO p3 = prootup;
               PO q3 = p3.next;
               if (q3 != null) {
                   while (q3.next != null) {
                       p3 = p3.next;
                       q3 = p3.next;
                   }
                   p3.next = null;
               }
           }
           System.out.println("The partial order");
           PO d=prootup;
  	    	while(d!=null) {
  	    		System.out.println(d.id1+"->"+d.id2);
  	    		d=d.next;
  	    	}
           
           for (PO v = prootup; v != null; v = v.next) {
               v.visited = 0;
           }
    
       }
   }

   public static int check_cycleup() {
	   Node p=FRup;
   	int count=0;
   	while(p!=null) {
   		count++;
   		p=p.next;
   	}
   	 POGraph graph = new POGraph(1000); 
   	 PO q=prootup;
   	 while(q!=null) {
   		 int num1=0,num2=0;
   		
   			 Scanner in1 = new Scanner(q.id1).useDelimiter("[^0-9]+");
       		 int integer1 = in1.nextInt(); 
       		 num1=integer1;
       		 Scanner in2 = new Scanner(q.id2).useDelimiter("[^0-9]+");
       		 int integer2 = in2.nextInt(); 
       		 num2=integer2;
   		 //}
   		 graph.addEdge(num1,num2);
	       
   		 q=q.next;
   	 }
   	 if(graph.isCyclic()) 
   		 return 1;
   	 else 
   		 return 0;
   
	   
   }
   public static void caseBup(final String fr1, final String fr2) {
       Node t = NFRup;
       int pval=0;
       String maxNFR = null;
       float weight = 0;
       float maxweight=0;
       while (t != null) {
       
           BC b = bcHeadup;
           while (b != null) {
               if (b.Nid.compareTo(t.id) == 0) {
                   int flag1 = 0;
                   int flag2 = 0;
                   int v1=0,v2=0;
               	weight=(float) ((float)t.priority*0.5);
                   for (FRDep k = b.begin; k != null; k = k.next) {
                       if (k.id.compareTo(fr1) == 0) {
                           flag1 = 1;
                           v1=k.val;
                           
                       }
                       if (k.id.compareTo(fr2) == 0) {
                           flag2 = 1;
                           v2=k.val;
                       }
                   }
                   if(flag1==1 && flag2==1) {
                   	weight=weight+(float)(((float)v1+(float)v2)*0.5);
                   	if(maxweight<weight)
                   	{
                   		maxweight=weight;
                   	    maxNFR = t.id;
                   	    pval=t.priority;
                   	    break;
                   	}
                   }
                   break;
               }
               else {
                   b = b.next;
               }
           }
           t = t.next;
       }
       //System.out.println("Max NFR is: " + maxNFR);
       BC b = bcHeadup;
       int val1 = 0;
       int val2 = 0;
       while (b != null) {
           if (b.Nid.compareTo(maxNFR) == 0) {
               final int flag3 = 0;
               final int flag4 = 0;
               for (FRDep i = b.begin; i != null; i = i.next) {
                   if (i.id.compareTo(fr1) == 0) {
                       val1 = i.val;
                   }
                   if (i.id.compareTo(fr2) == 0) {
                       val2 = i.val;
                   }
               }
           }
           b = b.next;
       }
   	Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
       int integer = in.nextInt();
       Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
       int integer2 = in2.nextInt();
      
       final PO temp = new PO();
        if (val1 >= val2) {
            if(val1==val2) {
		        if(integer>integer2) {
		            temp.id1 = fr1;
		            temp.id2 = fr2;
		        }
		        else {
		            temp.id1 = fr2;
		            temp.id2 = fr1;
		        }
	        }
            else {
           temp.id1 = fr1;
           temp.id2 = fr2;
           
           }
         
          // conflict_weight[integer-1][integer2-1]=priority;
           double val;
           val=Math.abs(val1-val2);
           if(val<=2)
           {
           	val=val1;
           }
           else {
           	val=(double)((double)val1+(double)val2)/(double)2;
           }
           //System.out.println("Called caseB. Inserting at "+integer+" | "+integer2+". The value "+priority+" and dep "+val);
          // dep_weight[integer-1][integer2-1]=val;
       
         
       }
       else if (val1 < val2) {
           temp.id1 = fr2;
           temp.id2 = fr1;
      
         //  conflict_weight[integer2-1][integer-1]=priority;
           double val;
           val=Math.abs(val1-val2);
           if(val<=2)
           {
           	val=val2;
           }
           else {
           	val=(double)((double)val1+(double)val2)/(double)2;
           }
           
           //System.out.println("Called caseB. Inserting at "+integer2+" | "+integer+". The value "+priority+" and dep "+val);
           //dep_weight[integer2-1][integer-1]=val;
           //System.out.println("dep_weight["+integer+"]["+integer2+"]: "+dep_weight[integer-1][integer2-1]);

       }
       if (prootup == null) {
           prootup = temp;
       }
       else {
           PO r;
           for (r = prootup; r.next != null; r = r.next) {}
           r.next = temp;
       }
       
   }
   public static void case1up(final String fr1, final String fr2) {
   	
       int max = 0;
       String nfr1 = null;
       String nfr2 = null;
       for (MC p = mcHeadup;p != null; p = p.next) {
           int flagmc1 = 0;
           int flagmc2 = 0;
           String N1 = null;
           String N2 = null;
           for (BC q = p.Blist; q != null; q = q.next) {
               for (FRDep r = q.begin; r != null; r = r.next) {
                   if (r.id.compareTo(fr1) == 0) {
                       flagmc1 = 1;
                   }
                   if (r.id.compareTo(fr2) == 0) {
                       flagmc2 = 1;
                   }
               }
           }
           if (flagmc1 == 1 && flagmc2 == 1) {
               BC q = p.Blist;
               N1 = q.Nid;
               q = q.next;
               N2 = q.Nid;
               for (Edge1 conflict = E_NNup; conflict != null; conflict = conflict.next) {
                   if (((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) && max < conflict.value) {
                       max = conflict.value;
                       nfr1 = N1;
                       nfr2 = N2;
                   }
               }
           }
       }
       //System.out.println("The NFRs are " + nfr1 + " " + nfr2);
       String maxNFR = null;
       String minNFR = null;
       int val1 = 0;
       int val2 = 0;
       for (Node t = NFRup; t != null; t = t.next) {
           if (t.id.compareTo(nfr1) == 0) {
               val1 = t.priority;
           }
           else if (t.id.compareTo(nfr2) == 0) {
               val2 = t.priority;
           }
       }
       if (val1 > val2) {
           maxNFR = nfr1;
           minNFR = nfr2;
       }
       else if (val1 < val2) {
           maxNFR = nfr2;
           minNFR = nfr1;
       }
       Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
       int integer = in.nextInt();
       Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
       int integer2 = in2.nextInt();
       //System.out.println("The values are val1= "+val1+" val2= "+val2+"Conflict degree= "+max);
       double deg=((double)(((double)val1+(double)val2)/(double)2))*(double)max;
       double dep;
       //System.out.println("Max NFR is: " + maxNFR);
       BC bclist = bcHeadup;
       int flag1 = 0;
       int flag2 = 0;
       int v1 = 0;
       int v2 = 0;
       while (bclist != null) {
           flag1 = 0;
           flag2 = 0;
           if (maxNFR.compareTo(bclist.Nid) == 0) {
               for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                   if (flist.id.compareTo(fr1) == 0) {
                       flag1 = 1;
                       v1 = flist.val;
                   }
                   else if (flist.id.compareTo(fr2) == 0) {
                       flag2 = 1;
                       v2 = flist.val;
                   }
               }
               break;
           }
           bclist = bclist.next;
       }
       final PO temp = new PO();
       if (flag1 == 1 && flag2 == 1) {
       	dep=Math.abs(v1-v2);
           if (v1 >= v2) {
               if(v1==v2) {
   	    		
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		            
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		            
   		        }
   	        }
               else {
               temp.id1 = fr1;
               temp.id2 = fr2;
               
               }
               
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
              // conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
               
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v2;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
               
              // conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;
           }
         
         
       }
       else if (flag1 == 1) {
           temp.id1 = fr1;
           temp.id2 = fr2;
          bclist = bcHeadup;
          int v=0;
           while (bclist != null) {
               flag1 = 0;
               flag2 = 0;
               if (minNFR.compareTo(bclist.Nid) == 0) {
                   for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                       if (flist.id.compareTo(fr2) == 0)
                           v = flist.val;
                      
                   }
                   break;
               }
               bclist = bclist.next;
           }
           dep=Math.abs(v1-v);
           if(dep<=2)
           {
          	 if(v1>v)
          		 dep=v1;
          	 else
          		 dep=v;
           }
           else {
          	 dep=(double)((double)v1+(double)v)/(double)2;
           }
           
          // conflict_weight[integer-1][integer2-1]=deg;
           //dep_weight[integer-1][integer2-1]=dep;
           
       }
       else if (flag2 == 1) {
           temp.id1 = fr2;
           temp.id2 = fr1;
           bclist = bcHeadup;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr1) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v2-v);
            if(dep<=2)
            {
           	 if(v2>v)
           		 dep=v2;
           	 else
           		 dep=v;
            }
            else {
           	 dep=(double)((double)v2+(double)v)/(double)2;
            }
           
            //conflict_weight[integer2-1][integer-1]=deg;
            //dep_weight[integer2-1][integer-1]=dep;
       }
       else {
           System.out.println("Executing else with Min NFR is: " + minNFR);
           bclist = bcHeadup;
           v1 = 0;
           v2 = 0;
           while (bclist != null) {
               flag1 = 0;
               flag2 = 0;
               if (minNFR.compareTo(bclist.Nid) == 0) {
                   for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                       if (flist2.id.compareTo(fr1) == 0) {
                           v1 = flist2.val;
                       }
                       else if (flist2.id.compareTo(fr2) == 0) {
                           v2 = flist2.val;
                       }
                   }
                   break;
               }
               bclist = bclist.next;
           }
           dep=Math.abs(v1-v2);
           
           if (v1 >= v2) {
           	 if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		          
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		          
    		        }
    	        }
                else {
                
               temp.id1 = fr1;
               temp.id2 = fr2;
               
                }
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
              // conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v2;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
               //conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;
           }
       }
       if (prootup == null) {
           prootup = temp;
       }
       else {
           PO r2;
           for (r2 = prootup; r2.next != null; r2 = r2.next) {}
           r2.next = temp;
       }
      
   }
   public static void case2up(final String fr1, final String fr2) {
 
       final int max = 0;
       final String nfr1 = null;
       final String nfr2 = null;
       MC p = mcHeadup;
       Node nlist = null;
       while (p != null) {
           int flagmc1 = 0;
           int flagmc2 = 0;
           String N1 = null;
           String N2 = null;
           for (BC q = p.Blist; q != null; q = q.next) {
               for (FRDep r = q.begin; r != null; r = r.next) {
                   if (r.id.compareTo(fr1) == 0) {
                       flagmc1 = 1;
                   }
                   if (r.id.compareTo(fr2) == 0) {
                       flagmc2 = 1;
                   }
               }
           }
           if (flagmc1 == 1 && flagmc2 == 1) {
               BC q = p.Blist;
               N1 = q.Nid;
               q = q.next;
               N2 = q.Nid;
               final Node temp1 = new Node();
               temp1.id = N1;
               final Node temp2 = new Node();
               temp2.id = N2;
               if (nlist == null) {
                   nlist = temp1;
                   temp1.next = temp2;
               }
               else {
                   Node j;
                   for (j = nlist; j.next != null; j = j.next) {}
                   j.next = temp1;
                   temp1.next = temp2;
               }
           }
           p = p.next;
       }
       for (Node f = nlist; f != null; f = f.next) {
           System.out.println(f.id);
       }
       String maxNFR = null;
       final String minNFR = null;
       final int val1 = 0;
       final int val2 = 0;
       Node t = nlist;
       int priority = 0;
       while (t != null) {
           for (Node k = NFRup; k != null; k = k.next) {
               if (k.id.compareTo(t.id) == 0 && priority < k.priority) {
                   priority = k.priority;
                   maxNFR = t.id;
               }
           }
           t = t.next;
       }
       Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
       int integer = in.nextInt();
       Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
       int integer2 = in2.nextInt();
       System.out.println("Max NFR is: " + maxNFR);
       BC bclist = bcHeadup;
       int flag1 = 0;
       int flag2 = 0;
       int v1 = 0;
       int v2 = 0;
       while (bclist != null) {
           flag1 = 0;
           flag2 = 0;
           if (maxNFR.compareTo(bclist.Nid) == 0) {
               for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                   if (flist.id.compareTo(fr1) == 0) {
                       flag1 = 1;
                       v1 = flist.val;
                   }
                   else if (flist.id.compareTo(fr2) == 0) {
                       flag2 = 1;
                       v2 = flist.val;
                   }
               }
               break;
           }
           bclist = bclist.next;
       }
       /*MC m=mcHead;
       while(m!=null) {
       	BC b=m.Blist;
       	String s1=b.Nid;
       	b=b.next;
       	String s2=b.Nid;
       	if((s1.compareTo(maxNFR))==0) {
       		
       	}
       	else if((s2.compareTo(maxNFR))==0) {
       		
       	}
       	m=m.next;
       }*/
       final PO temp3 = new PO();
       if (flag1 == 1 && flag2 == 1) {
           if (v1 >= v2) {
           	if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp3.id1 = fr1;
    		            temp3.id2 = fr2;
    		          
    		        }
    		        else {
    		            temp3.id1 = fr2;
    		            temp3.id2 = fr1;
    		          
    		        }
    	        }
           	else {
               temp3.id1 = fr1;
               temp3.id2 = fr2;
              
           	}
         
              // conflict_weight[integer-1][integer2-1]=priority;
              double v=Math.abs(v1-v2);
               if(v<=2)
               	v=v1;
               else
               	v=(double)((double)v1+(double)v2)/(double)2;
         
           
               //dep_weight[integer-1][integer2-1]=v;
           }
           else {
               temp3.id1 = fr2;
               temp3.id2 = fr1;
             
               //conflict_weight[integer2-1][integer-1]=priority;
               double v=Math.abs(v1-v2);
               if(v<=2)
               	v=v2;
               else
               	v=(double)((double)v1+(double)v2)/(double)2;
              
               //dep_weight[integer2-1][integer-1]=v;
           }
       }
       else if (flag1 == 1) {
           temp3.id1 = fr1;
           temp3.id2 = fr2;
       
           //conflict_weight[integer-1][integer2-1]=priority;
           MC m=mcHeadup;
          double v=0;
           int c=0;
           while(m!=null) {
           	BC b=m.Blist;
           	String s1=b.Nid;
           	b=b.next;
           	String s2=b.Nid;
           	if((s1.compareTo(maxNFR))==0) {
           		BC k=bcHeadup;
           		while(k!=null) {
           			if((k.Nid.compareTo(s2))==0) {
           				FRDep f=k.begin;
           				while(f!=null) {
           					if((f.id.compareTo(fr2))==0) {
           						v=v+f.val;
           						c++;
           					}
           					f=f.next;
           				}
           			}
           			k=k.next;
           		}
           	}
           	else if((s2.compareTo(maxNFR))==0) {
           		BC k=bcHeadup;
           		while(k!=null) {
           			if((k.Nid.compareTo(s1))==0) {
           				FRDep f=k.begin;
           				while(f!=null) {
           					if((f.id.compareTo(fr2))==0) {
           						v=v+f.val;
           						c++;
           					}
           					f=f.next;
           				}
           			}
           			k=k.next;
           		}
           	}
           	m=m.next;
           }
           v=v/c;
           if(v<=2)
           {
           	if(v<v1)
           		v=v1;
           }
           else {
           	v=(double)((double)v1+(double)v)/(double)2;
           }
          
           //dep_weight[integer-1][integer2-1]=v;
       }
       else if (flag2 == 1) {
           temp3.id1 = fr2;
           temp3.id2 = fr1;
           MC m=mcHeadup;
           double v=0;
            int c=0;
            while(m!=null) {
            	BC b=m.Blist;
            	String s1=b.Nid;
            	b=b.next;
            	String s2=b.Nid;
            	if((s1.compareTo(maxNFR))==0) {
            		BC k=bcHeadup;
            		while(k!=null) {
            			if((k.Nid.compareTo(s2))==0) {
            				FRDep f=k.begin;
            				while(f!=null) {
            					if((f.id.compareTo(fr2))==0) {
            						v=v+f.val;
            						c++;
            					}
            					f=f.next;
            				}
            			}
            			k=k.next;
            		}
            	}
            	else if((s2.compareTo(maxNFR))==0) {
            		BC k=bcHeadup;
            		while(k!=null) {
            			if((k.Nid.compareTo(s1))==0) {
            				FRDep f=k.begin;
            				while(f!=null) {
            					if((f.id.compareTo(fr2))==0) {
            						v=v+f.val;
            						c++;
            					}
            					f=f.next;
            				}
            			}
            			k=k.next;
            		}
            	}
            	m=m.next;
            }
            v=v/c;
            if(v<=2)
            {
            	if(v<v2)
            		v=v2;
            }
            else {
            	v=(double)((double)v2+(double)v)/(double)2;
            }
           
          // conflict_weight[integer2-1][integer-1]=priority;
           //dep_weight[integer2-1][integer-1]=v2;
       }
       else {
           System.out.println("entering else");
           t = nlist;
           priority = 0;
           int complete = 0;
           String min = "";
           int exists = 1;
           while (exists == 1) {
               exists = 0;
               Node q2;
               t = (q2 = nlist);
               while (t != null) {
                   if (t.id.compareTo(maxNFR) == 0) {
                       if (t == nlist) {
                           nlist = t.next;
                           break;
                       }
                       System.out.println("In else");
                       q2.next = t.next;
                       break;
                   }
                   else {
                       q2 = t;
                       t = t.next;
                   }
               }
               for (Node r2 = nlist; r2 != null; r2 = r2.next) {
                   System.out.println(r2.id);
                   if (r2.id.compareTo(maxNFR) == 0) {
                       exists = 1;
                   }
               }
           }
           System.out.println("Done deletion");
           while (complete == 0) {
               t = nlist;
               priority = 0;
               while (t != null) {
                   Node i = NFRup;
                   System.out.println("compairing " + t.id);
                   while (i != null) {
                       if (i.id.compareTo(t.id) == 0) {
                           System.out.println("Priority is of k:" + i.id + " " + i.priority);
                           if (priority < i.priority) {
                               priority = i.priority;
                               min = i.id;
                           }
                       }
                       i = i.next;
                   }
                   System.out.println("Priority is" + priority);
                   t = t.next;
               }
               System.out.println("NFR selected =" + min);
               flag1 = 0;
               flag2 = 0;
               v1 = 0;
               v2 = 0;
               for (bclist = bcHeadup; bclist != null; bclist = bclist.next) {
                   if (min.compareTo(bclist.Nid) == 0) {
                       for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                           if (flist2.id.compareTo(fr1) == 0) {
                               flag1 = 1;
                               v1 = flist2.val;
                           }
                           else if (flist2.id.compareTo(fr2) == 0) {
                               flag2 = 1;
                               v2 = flist2.val;
                           }
                       }
                       break;
                   }
               }
               System.out.println("flag1 and flag2: " + flag1 + " " + flag2);
               if (flag1 == 1 || flag2 == 1) {
                   complete = 1;
                   if (flag1 == 1 && flag2 == 1) {
                       if (v1 >= v2) {
                       	if(v1==v2) {
                	    		
                		        if(integer>integer2) {
                		            temp3.id1 = fr1;
                		            temp3.id2 = fr2;
                		          
                		        }
                		        else {
                		            temp3.id1 = fr2;
                		            temp3.id2 = fr1;
                		          
                		        }
                	        }
                       else {
                           temp3.id1 = fr1;
                           temp3.id2 = fr2;
                          
                       }
                           
                          // conflict_weight[integer-1][integer2-1]=priority;
                           double v=Math.abs(v1-v2);
                           if(v<=2)
                           	v=v1;
                           else
                           	v=(double)((double)v1+(double)v2)/(double)2;
                          
                          // dep_weight[integer-1][integer2-1]=v;
                           
                       }
                       else {
                           temp3.id1 = fr2;
                           temp3.id2 = fr1;
                          
                          // conflict_weight[integer2-1][integer-1]=priority;
                           double v=Math.abs(v1-v2);
                           if(v<=2)
                           	v=v2;
                           else
                           	v=(double)((double)v1+(double)v2)/(double)2;
                           
                           //dep_weight[integer2-1][integer-1]=v;
                       }
                   }
                   else if (flag1 == 1) {
                       temp3.id1 = fr1;
                       temp3.id2 = fr2;
                       MC m=mcHeadup;
                       double v=0;
                        int c=0;
                        while(m!=null) {
                        	BC b=m.Blist;
                        	String s1=b.Nid;
                        	b=b.next;
                        	String s2=b.Nid;
                        	if((s1.compareTo(min))==0) {
                        		BC k=bcHeadup;
                        		while(k!=null) {
                        			if((k.Nid.compareTo(s2))==0) {
                        				FRDep f=k.begin;
                        				while(f!=null) {
                        					if((f.id.compareTo(fr2))==0) {
                        						v=v+f.val;
                        						c++;
                        					}
                        					f=f.next;
                        				}
                        			}
                        			k=k.next;
                        		}
                        	}
                        	else if((s2.compareTo(min))==0) {
                        		BC k=bcHeadup;
                        		while(k!=null) {
                        			if((k.Nid.compareTo(s1))==0) {
                        				FRDep f=k.begin;
                        				while(f!=null) {
                        					if((f.id.compareTo(fr2))==0) {
                        						v=v+f.val;
                        						c++;
                        					}
                        					f=f.next;
                        				}
                        			}
                        			k=k.next;
                        		}
                        	}
                        	m=m.next;
                        }
                        v=v/c;
                        if(v<=2)
                        {
                        	if(v<v1)
                        		v=v1;
                        }
                        else {
                        	v=(double)((double)v1+(double)v)/(double)2;
                        }
                       
                        //conflict_weight[integer-1][integer2-1]=priority;
                        //dep_weight[integer-1][integer2-1]=v;
                   }
                   else if (flag2 == 1) {
                       temp3.id1 = fr2;
                       temp3.id2 = fr1;
                       MC m=mcHeadup;
                       double v=0;
                        int c=0;
                        while(m!=null) {
                        	BC b=m.Blist;
                        	String s1=b.Nid;
                        	b=b.next;
                        	String s2=b.Nid;
                        	if((s1.compareTo(min))==0) {
                        		BC k=bcHeadup;
                        		while(k!=null) {
                        			if((k.Nid.compareTo(s2))==0) {
                        				FRDep f=k.begin;
                        				while(f!=null) {
                        					if((f.id.compareTo(fr2))==0) {
                        						v=v+f.val;
                        						c++;
                        					}
                        					f=f.next;
                        				}
                        			}
                        			k=k.next;
                        		}
                        	}
                        	else if((s2.compareTo(min))==0) {
                        		BC k=bcHeadup;
                        		while(k!=null) {
                        			if((k.Nid.compareTo(s1))==0) {
                        				FRDep f=k.begin;
                        				while(f!=null) {
                        					if((f.id.compareTo(fr2))==0) {
                        						v=v+f.val;
                        						c++;
                        					}
                        					f=f.next;
                        				}
                        			}
                        			k=k.next;
                        		}
                        	}
                        	m=m.next;
                        }
                        v=v/c;
                        if(v<=2)
                        {
                        	if(v<v2)
                        		v=v2;
                        }
                        else {
                        	v=(double)((double)v2+(double)v)/(double)2;
                        }
                        
                        //conflict_weight[integer2-1][integer-1]=priority;
                        //dep_weight[integer2-1][integer-1]=v;
                   }
               }
               exists = 1;
               while (exists == 1) {
                   Node h;
                   Node l = h = nlist;
                   exists = 0;
                   while (l != null) {
                       if (l.id.compareTo(min) == 0) {
                           if (l == nlist) {
                               nlist = l.next;
                               break;
                           }
                           h.next = l.next;
                           break;
                       }
                       else {
                           h = l;
                           l = l.next;
                       }
                   }
                   for (l = nlist; l != null; l = l.next) {
                       if (l.id.compareTo(min) == 0) {
                           exists = 1;
                       }
                   }
               }
           }
       }
       if (prootup == null) {
           prootup = temp3;
       }
       else {
           PO r3;
           for (r3 = prootup; r3.next != null; r3 = r3.next) {}
           r3.next = temp3;
       }
   }
   public static void case3up(final String fr1, final String fr2) {
   	
       float max = 0.0f;
       String nfr1 = null;
       String nfr2 = null;
       int p2 = 0;
       int p3 = 0;
       int degree = 0;
       for (MC p = mcHeadup; p != null; p = p.next) {
           int flagmc1 = 0;
           int flagmc2 = 0;
           String N1 = null;
           String N2 = null;
           for (BC q = p.Blist; q != null; q = q.next) {
               for (FRDep r = q.begin; r != null; r = r.next) {
                   if (r.id.compareTo(fr1) == 0) {
                       flagmc1 = 1;
                   }
                   if (r.id.compareTo(fr2) == 0) {
                       flagmc2 = 1;
                   }
               }
           }
           if (flagmc1 == 1 && flagmc2 == 1) {
               BC q = p.Blist;
               N1 = q.Nid;
               q = q.next;
               N2 = q.Nid;
               System.out.println("N1 and N2 are" + N1 + " " + N2);
               Edge1 conflict = E_NNup;
               
               while (conflict != null) {
                   if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                       degree = conflict.value;
                   }
                   conflict = conflict.next;
               }
               System.out.println("The degree is " + degree);
              
               for (Node k = NFRup; k != null; k = k.next) {
                   if (k.id.compareTo(N1) == 0) {
                       p2 = k.priority;
                   }
                   if (k.id.compareTo(N2) == 0) {
                       p3 = k.priority;
                   }
               }
               System.out.println("p1 and p2 are" + p2 + " " + p3);
               final float product = (degree - 40) * ((p2 + p3) / 200.0f);
               System.out.println("Product is" + product);
               if (max < product) {
                   max = product;
                   nfr1 = N1;
                   nfr2 = N2;
               }
           }
       }
       Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
       int integer = in.nextInt();
       Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
       int integer2 = in2.nextInt();
     double deg=((p2+p3)/2)*degree;
       double dep;
       System.out.println("The NFRs are " + nfr1 + " " + nfr2);
       String maxNFR = null;
       String minNFR = null;
       int val1 = 0;
       int val2 = 0;
       for (Node t = NFRup; t != null; t = t.next) {
           if (t.id.compareTo(nfr1) == 0) {
               val1 = t.priority;
           }
           else if (t.id.compareTo(nfr2) == 0) {
               val2 = t.priority;
           }
       }
       if (val1 > val2) {
           maxNFR = nfr1;
           minNFR = nfr2;
       }
       else if (val1 < val2) {
           maxNFR = nfr2;
           minNFR = nfr1;
       }
       BC bclist = bcHeadup;
       int flag1 = 0;
       int flag2 = 0;
       int v1 = 0;
       int v2 = 0;
       while (bclist != null) {
           flag1 = 0;
           flag2 = 0;
           if (maxNFR.compareTo(bclist.Nid) == 0) {
               for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                   if (flist.id.compareTo(fr1) == 0) {
                       flag1 = 1;
                       v1 = flist.val;
                   }
                   else if (flist.id.compareTo(fr2) == 0) {
                       flag2 = 1;
                       v2 = flist.val;
                   }
               }
               break;
           }
           bclist = bclist.next;
       }
       final PO temp = new PO();
       if (flag1 == 1 && flag2 == 1) {
       	dep=Math.abs(v1-v2);
           if (v1 >= v2) {
           	if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		        	 
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		          
    		        }
    	        }
           	else {
           		
               temp.id1 = fr1;
               temp.id2 = fr2;
           	}
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
              
               //conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
               
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
               
               //conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;

           }
       }
       else if (flag1 == 1) {
           temp.id1 = fr1;
           temp.id2 = fr2;
           bclist = bcHeadup;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr2) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v);
            if(dep<=2)
            {
           	 if(v1>v)
            	dep=v1;
           	 else
           		 dep=v;
            }
            	else
            	dep=(double)((double)v1+(double)v2)/(double)2;
            
           // conflict_weight[integer-1][integer2-1]=deg;
            //dep_weight[integer-1][integer2-1]=dep;
       }
       else if (flag2 == 1) {
           temp.id1 = fr2;
           temp.id2 = fr1;
           bclist = bcHeadup;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr1) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v2-v);
            if(dep<=2)
            {
           	 if(v2>v)
            	dep=v2;
           	 else
           		 dep=v;
            }
            	else
            	dep=(double)((double)v+(double)v2)/(double)2;
            
           // conflict_weight[integer2-1][integer-1]=deg;
            //dep_weight[integer2-1][integer-1]=dep;
       }
       else {
           bclist = bcHeadup;
           v1 = 0;
           v2 = 0;
           while (bclist != null) {
               flag1 = 0;
               flag2 = 0;
               if (minNFR.compareTo(bclist.Nid) == 0) {
                   for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                       if (flist2.id.compareTo(fr1) == 0) {
                           v1 = flist2.val;
                       }
                       else if (flist2.id.compareTo(fr2) == 0) {
                           v2 = flist2.val;
                       }
                   }
                   break;
               }
               bclist = bclist.next;
           }
           dep=Math.abs(v1-v2);
           if (v1 >= v2) {
           	if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		           
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		          
    		        }
    	        }
           else {
           	  
               temp.id1 = fr1;
               temp.id2 = fr2;
           }
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
             
               //conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v2;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
               //conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;
           }
       }
       if (prootup == null) {
           prootup = temp;
       }
       else {
           PO r2;
           for (r2 = prootup; r2.next != null; r2 = r2.next) {}
           r2.next = temp;
       }
       
   }

   public static void case4up(final String fr1, final String fr2) {
   	
       float max = 0.0f;
       String nfr1 = null;
       String nfr2 = null;
       int p2 = 0;
       int p3 = 0;
       int degree = 0;
       for (MC p = mcHeadup; p != null; p = p.next) {
           int flagmc1 = 0;
           int flagmc2 = 0;
           String N1 = null;
           String N2 = null;
           for (BC q = p.Blist; q != null; q = q.next) {
               for (FRDep r = q.begin; r != null; r = r.next) {
                   if (r.id.compareTo(fr1) == 0) {
                       flagmc1 = 1;
                   }
                   if (r.id.compareTo(fr2) == 0) {
                       flagmc2 = 1;
                   }
               }
           }
           if (flagmc1 == 1 && flagmc2 == 1) {
               BC q = p.Blist;
               N1 = q.Nid;
               q = q.next;
               N2 = q.Nid;
               Edge1 conflict = E_NNup;
            
               while (conflict != null) {
                   if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                       degree = conflict.value;
                   }
                   conflict = conflict.next;
               }
            
               for (Node k = NFRup; k != null; k = k.next) {
                   if (k.id.compareTo(N1) == 0) {
                       p2 = k.priority;
                   }
                   if (k.id.compareTo(N2) == 0) {
                       p3 = k.priority;
                   }
               }
               final float sum = (float)w1 * degree + (p2 + p3) * (float)w2;
               System.out.println("The sum is" + sum);
               if (max < sum) {
                   max = sum;
                   nfr1 = N1;
                   nfr2 = N2;
               }
           }
       }
       Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
       int integer = in.nextInt();
       Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
       int integer2 = in2.nextInt();
       double deg=((p2+p3)/2)*degree;
       double dep;
       System.out.println("The NFRs are " + nfr1 + " " + nfr2);
       String maxNFR = null;
       String minNFR = null;
       int val1 = 0;
       int val2 = 0;
       for (Node t = NFRup; t != null; t = t.next) {
           if (t.id.compareTo(nfr1) == 0) {
               val1 = t.priority;
           }
           else if (t.id.compareTo(nfr2) == 0) {
               val2 = t.priority;
           }
       }
       if (val1 > val2) {
           maxNFR = nfr1;
           minNFR = nfr2;
       }
       else if (val1 < val2) {
           maxNFR = nfr2;
           minNFR = nfr1;
       }
       BC bclist = bcHeadup;
       int flag1 = 0;
       int flag2 = 0;
       int v1 = 0;
       int v2 = 0;
       while (bclist != null) {
           flag1 = 0;
           flag2 = 0;
           if (maxNFR.compareTo(bclist.Nid) == 0) {
               for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                   if (flist.id.compareTo(fr1) == 0) {
                       flag1 = 1;
                       v1 = flist.val;
                   }
                   else if (flist.id.compareTo(fr2) == 0) {
                       flag2 = 1;
                       v2 = flist.val;
                   }
               }
               break;
           }
           bclist = bclist.next;
       }
       final PO temp = new PO();
       if (flag1 == 1 && flag2 == 1) {
       	dep=Math.abs(v1-v2);
           if (v1 >= v2) {
           	if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		          
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		           
    		        }
    	        }
           	else {
               temp.id1 = fr1;
               temp.id2 = fr2;
           	}
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
            
              
               //conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v2;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
              // conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;
           }
       }
       else if (flag1 == 1) {
           temp.id1 = fr1;
           temp.id2 = fr2;
           bclist = bcHeadup;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr2) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v1-v);
            if(dep<=2)
            {
           	 if(v1>v)
           		 dep=v1;
           	 else
           		 dep=v;
            }
            else
            	dep=(double)((double)v1+(double)v)/(double)2;
         
           // conflict_weight[integer-1][integer2-1]=deg;
            //dep_weight[integer-1][integer2-1]=dep;
       }
       else if (flag2 == 1) {
           temp.id1 = fr2;
           temp.id2 = fr1;
           bclist = bcHeadup;
           int v=0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                        if (flist.id.compareTo(fr1) == 0)
                            v = flist.val;
                       
                    }
                    break;
                }
                bclist = bclist.next;
            }
            dep=Math.abs(v2-v);
            if(dep<=2)
            {
           	 if(v2>v)
           		 dep=v2;
           	 else
           		 dep=v;
            }
            else
            	dep=(double)((double)v2+(double)v)/(double)2;
         
            //conflict_weight[integer2-1][integer-1]=deg;
            //dep_weight[integer2-1][integer-1]=dep;
       }
       else {
           bclist = bcHeadup;
           v1 = 0;
           v2 = 0;
           while (bclist != null) {
               flag1 = 0;
               flag2 = 0;
               if (minNFR.compareTo(bclist.Nid) == 0) {
                   for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                       if (flist2.id.compareTo(fr1) == 0) {
                           v1 = flist2.val;
                       }
                       else if (flist2.id.compareTo(fr2) == 0) {
                           v2 = flist2.val;
                       }
                   }
                   break;
               }
               bclist = bclist.next;
           }
           dep=Math.abs(v1-v2);
           if (v1 >= v2) {
           	if(v1==v2) {
    	    		
    		        if(integer>integer2) {
    		            temp.id1 = fr1;
    		            temp.id2 = fr2;
    		           
    		            
    		        }
    		        else {
    		            temp.id1 = fr2;
    		            temp.id2 = fr1;
    		          
    		        }
    	        }
           	else {
           		
               temp.id1 = fr1;
               temp.id2 = fr2;
           	}
               if(dep<=2)
               	dep=v1;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
             
              
              // conflict_weight[integer-1][integer2-1]=deg;
               //dep_weight[integer-1][integer2-1]=dep;
           }
           else {
               temp.id1 = fr2;
               temp.id2 = fr1;
               if(dep<=2)
               	dep=v2;
               else
               	dep=(double)((double)v1+(double)v2)/(double)2;
              
              // conflict_weight[integer2-1][integer-1]=deg;
               //dep_weight[integer2-1][integer-1]=dep;
           }
       }
       if (prootup == null) {
           prootup = temp;
       }
       else {
           PO r2;
           for (r2 = prootup; r2.next != null; r2 = r2.next) {}
           r2.next = temp;
       }
       
   }
   public static void remove_transitiveup() {
	    PO j=prootup;
	    while(j!=null) {
	    	j.visited=0;
	    	j=j.next;
	    }
	    for(Node p=FRup;p!=null;p=p.next) {
	    	for(Node q=FRup;q!=null;q=q.next) {
	    		for(Node r=FRup;r!=null;r=r.next) {
	    			String s1=p.id;
	    			String s2=q.id;
	    			PO k=prootup;
	    			int flag1=0;
	    			while(k!=null) {
	    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
	    					flag1=1;
	    					break;
	    				}
	    				k=k.next;
	    			}
	    			s1=q.id;
	    			s2=r.id;
	    			k=prootup;
	    			int flag2=0;
	    			while(k!=null) {
	    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
	    					flag2=1;
	    					break;
	    				}
	    				k=k.next;
	    			}
	    			if(flag1==1 && flag2==1) {
	        			s1=p.id;
	        			s2=r.id;
	        			System.out.println("removing "+p.id+" -> "+r.id+" due to "+p.id+" -> "+q.id+" and "+q.id+" -> "+r.id);
	        			
	        			PO m=prootup;
	        			PO n=m;
	        			int found=0;
	        			while(m!=null) {
	        				if((m.id1.compareTo(s1))==0 && (m.id2.compareTo(s2))==0) {
	        					found=1;
	        					m.visited=1;
	        					break;
	        				}
	        				n=m;
	        				m=m.next;
	        			}
	        			
	    		}
	    	
	    			
	    		}
	    	}
	    }
	    PO p=prootup;
	    int flag=1;
	    while(flag==1) {
	    	flag=0;
	    	PO m=prootup;
			PO n=m;
			int found=0;
			while(m!=null) {
				if(m.visited==1) {
					found=1;
					break;
				}
				n=m;
				m=m.next;
			}
			System.out.println("Found "+m.id1+" -> "+m.id2);
			if(found==1) {
				if(m==prootup) {
					if(m.next!=null) {
						m=m.next;
						prootup=m;
					}
					else
						prootup=null;
				}
				else if(m.next==null) {
					n.next=null;
				}
				else {
					m=m.next;
					n.next=m;
				}
			}
	    	PO g=prootup;
	    	while(g!=null) {
	    		if(g.visited==1)
	    			flag=1;
	    		g=g.next;
	    	}
	    }
	    System.out.println("After removing transitive edges");
	    PO r=prootup;
	    while(r!=null) {
	    	System.out.println(r.id1+" -> "+r.id2);
	    	r=r.next;
	    }
	    }
   
   public static void exist_pathup() {
  	 PO remove=null;
  	   	PO k=prootup;
  	   	int count=0;
  	   	while(k!=null) {
  	   		count++;
  	   		System.out.println("Edge:  "+k.id1+" -> "+k.id2);
  	   		k=k.next;
  	   	}
  	   	System.out.println("Number of edges are : "+count);
  	   	Node q=FRup;
  	   	int V=0;
  	   	while(q!=null) {
  	   		V++;
  	   		q=q.next;
  	   	}
  		System.out.println("Number of FRs are : "+V);
  	   	PO p=prootup;
  	   	int [][] edges;
  	   	while(p!=null) {
  	   		String s1=p.id1;
  	   		String s2=p.id2;
  	   	 Scanner ins = new Scanner(p.id1).useDelimiter("[^0-9]+");
  	        int i1 = ins.nextInt();
  	        Scanner ins2 = new Scanner(p.id2).useDelimiter("[^0-9]+");
  	        int i2 = ins2.nextInt();
  	   		System.out.println("checking for "+s1+" -> "+s2);
  	   		edges=new int[count][2];
  	   		int j=0;
  	   		k=prootup;
  	   		int m=0;
  	   		while(m<count) {
  	   			if(k!=null) {
  	   			for(int n=0;n<2;n++) {
  	   				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
  	   				}else {
  	   					//System.out.println("adding "+k.id1+" -> "+k.id2);
  	   					 Scanner in = new Scanner(k.id1).useDelimiter("[^0-9]+");
  	   			            int integer = in.nextInt();
  	   			            Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
  	   			            int integer2 = in2.nextInt();
  	   			            //System.out.println("the integer form "+integer+" -> "+integer2);
  	   			            edges[m][n]=integer;
  	   			            n++;
  	   			            edges[m][n]=integer2;
  	   			            m++;
  	   				}
  	   			}
  	   			k=k.next;
  	   		}
  	   			else
  	   				break;
  	   			
  	   		}
  	   		//System.out.println("the passed edges are:");

  	   		for(m=0;m<count;m++) {
  	   			
  	   				//System.out.println(edges[m][0]+" -> "+edges[m][1]);
  	   			
  	   		}
  	   		 if (existPath(V, edges, i1, i2,count)) {
  	   			 System.out.print("Yes\n");
  	   			 PO temp=new PO();
  	   			 temp.id1=s1;
  	   			 temp.id2=s2;
  	   			 if(remove==null)
  	   				 remove=temp;
  	   			 else {
  	   				 PO t=remove;
  	   				 while(t.next!=null)
  	   					 t=t.next;
  	   				 t.next=temp;
  	   			 }
  	   		 }
  	   		       
  	   		    else
  	   		        System.out.print("No\n");
  	           
  	   		p=p.next;
  	   	}
  	   //	System.out.println("The extras are: ");
  	   	PO t=remove;
  	   	while(t!=null) {
  	   		PO j=prootup;
  	   		PO s=j;
  	   		while(j!=null) {
  	   			if((j.id1.compareTo(t.id1))==0 && (j.id2.compareTo(t.id2))==0) {
  	   				break;
  	   			}
  	   			s=j;
  	   			j=j.next;
  	   		}
  	   		
  	   		if(j==prootup) {
  				if(j.next!=null) {
  					j=j.next;
  					prootup=j;
  				}
  				else
  					prootup=null;
  			}
  			else if(j.next==null) {
  				s.next=null;
  			}
  			else {
  				j=j.next;
  				s.next=j;
  			}
  	   		
  	   		t=t.next;
  	   	}
  }

   public static void setTextup() {
   	seq_up2=null;
   	//At first find the source vertices
   	Node source2=null;
   	Node k=FRup;
   	while(k!=null) {
   		String s=k.id;
   		int exists=0;
   		int found=0;
   		PO p=prootup;
   		while(p!=null) {
   			if((p.id2.compareTo(s))==0)
   			{
   				exists=1;
   				break;
   			}
   			if((p.id1.compareTo(s))==0)
   				found=1;
   			p=p.next;
   		}
   		if(exists==0) {
   			if(found==1) {
   			System.out.println("Source="+k.id);
   			Node temp=new Node();
   			temp.id=s;
   			temp.next=null;
   			if(source2==null)
   				source2=temp;
   			else {
   				Node j=source2;
   				while(j.next!=null)
   					j=j.next;
   				j.next=temp;
   			}
   			}
   		}
   	
   	
   		k=k.next;
   }
  //Count outgoing edge from each source
   	Node j=source2;
   	while(j!=null) {
   		String s=j.id;
   		PO m=prootup;
   		int c=0;
   		while(m!=null) {
   			if((m.id1.compareTo(s))==0)
   				c++;
   			m=m.next;
   		}
   		j.priority=c;
   		j=j.next;
   	}
   	//Setting visited to 0;
   	PO l=prootup;
   	while(l!=null) {
   		l.visited=0;
   		l=l.next;
   	}
   	//creating a duplicate proot list
   	PO pr=null;
   	PO pt=prootup;
   	while(pt!=null) {
   		PO temp=new PO();
   		temp.id1=pt.id1;
   		temp.id2=pt.id2;
   		temp.visited=0;
   		temp.next=null;
   		if(pr==null)
   			pr=temp;
   		else {
   			PO v=pr;
   			while(v.next!=null)
   				v=v.next;
   			v.next=temp;
   		}
   		pt=pt.next;
   	}
   	//Creating the sequences
   	//plist root=null;
   	j=source2;
   	int seq=1;
   	while(j!=null) {
   		
   		PO t=prootup;
   		plist temp=new plist();
   		while(t!=null) {
   			if((t.id1.compareTo(j.id))==0 && t.visited==0) {
   		
   				temp.name=seq;
   				seq++;
   				temp.next=null;
   				sNode temp2=new sNode();
   				temp2.id=t.id1;
   				temp2.next=null;
   				sNode temp3=new sNode();
   				temp3.id=t.id2;
   				temp3.next=null;
   				temp2.next=temp3;
   				temp.begin=temp2;
   				if(seq_up2==null)
   					seq_up2=temp;
   				else {
   					plist g=seq_up2;
   					while(g.next!=null)
   						g=g.next;
   					g.next=temp;
   				}
   				j.priority--;
   				t.visited=1;
   				PO x=pr;
   				while(x!=null) {
   					if((x.id1.compareTo(t.id1))==0 && (x.id2.compareTo(t.id2))==0)
   						x.visited=1;
   					x=x.next;
   				}
   				break;
   			
   			}
   			t=t.next;
   		}
   		int found=1;
   		while(found==1) {
   			found=0;
   			sNode m=temp.begin;
   			while(m.next!=null)
   				m=m.next;
   			String s=m.id;
   			PO n=prootup;
   			while(n!=null) {
   				if((n.id1.compareTo(s))==0 && n.visited==0) {
   					sNode temp4=new sNode();
       				temp4.id=n.id2;
       				temp4.next=null;
       				m.next=temp4;
       				found=1;
       				PO x=pr;
       				while(x!=null) {
       					if((x.id1.compareTo(n.id1))==0 && (x.id2.compareTo(n.id2))==0)
       						x.visited=1;
       					x=x.next;
       				}
       				break;
       				
   				}
   				n=n.next;
   			}
   		}
   		
   		if(j.priority==0)
   		{
   			j=j.next;
   		}
   	}
   	//Creating remaining sequences
   	PO h=pr;
   	plist root2=null;
   	//int prevseq=0;
   	while(h!=null) {
   		
   		if(h.visited==0) {
   	
   			plist v=seq_up2;
   			while(v!=null) {
   				plist temp=new plist();
   				temp.name=seq;
       			seq++;
       			temp.begin=null;
   				int found=0;
   				sNode i=v.begin;
   				while(i!=null) {
   					if((i.id.compareTo(h.id1))==0)
   					{
   						System.out.println("Yes Found"+h.id1);
       					sNode wi=v.begin;
       					while((wi.id.compareTo(h.id1))!=0) {
       						sNode temp5=new sNode();
       						temp5.id=wi.id;
       						temp5.next=null;
       						System.out.println("Inserting "+temp5.id);
       						sNode f=temp.begin;
       						if(temp.begin==null)
       							temp.begin=temp5;
       						else {
       							sNode z=temp.begin;
       							while(z.next!=null)
       								z=z.next;
       							z.next=temp5;
       						}
       						wi=wi.next;
       					}
       					
       					break;
   					}
   					i=i.next;
   					
   				}
   				sNode temp1=new sNode();
	    			temp1.id=h.id1;
	    			temp1.next=null;
	    			sNode f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp1;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp1;
					}
	    			sNode temp2=new sNode();
	    			temp2.id=h.id2;
	    			temp2.next=null;
	    			f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp2;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp2;
					}
	    			if(root2==null)
	    				root2=temp;
	    			else
	    			{
	    				plist b=root2;
	    				while(b.next!=null)
	    					b=b.next;
	    				b.next=temp;
	    			}
	    			int ex=1;
	        		while(ex==1) {
	        			ex=0;
	        			sNode m=temp.begin;
	        			while(m.next!=null)
	        				m=m.next;
	        			String s=m.id;
	        			PO n=proot;
	        			while(n!=null) {
	        				if((n.id1.compareTo(s))==0 && n.visited==0) {
	        					sNode temp4=new sNode();
	            				temp4.id=n.id2;
	            				temp4.next=null;
	            				m.next=temp4;
	            				m=m.next;
	            				ex=1;
	            				break;
	            				
	        				}
	        				n=n.next;
	        			}
	        		}
	        		System.out.println("list created");
	        		System.out.println("V id: "+v.name);
   				v=v.next;
   				//break;
   			}
   			System.out.println("Done once");
   		}
   		h=h.next;
   	}
   	//Adding remaining to main list
   	plist q=root2;
   	while(q!=null) {
   		plist temp=new plist();
   		temp.name=q.name;
   		temp.begin=q.begin;
   		if(seq_up2==null)
   			seq_up2=temp;
   		else {
   			plist x=seq_up2;
   			while(x.next!=null)
   				x=x.next;
   			x.next=temp;
   		}
   		q=q.next;
   	}
   	//Checking duplicate sequence
   	plist k2=seq_up2;
   	while(k2!=null) {
   		String temp1="";
   		sNode p=k2.begin;
   		while(p!=null) {
   			temp1=temp1.concat(p.id);
   			p=p.next;
   		}
   		plist m=seq_up2;
   		int e=0;
   		while(m!=null) {
   			sNode q2=m.begin;
   			String temp2="";
   			while(q2!=null) {
   				temp2=temp2.concat(q2.id);
   				q2=q2.next;
   			}
   			if(temp2.contains(temp1)) {
   				if((temp1.compareTo(temp2))!=0) {
   					k2.name=0;
   				}
   			}
   		m=m.next;	
   		}
   		
   		k2=k2.next;
   	}
   	// Removing duplicate
   	int del=1;
   	while(del==1) {
   		del=0;
   		plist v2=seq_up2;
   		plist v3=v2;
   		while(v2!=null) {
   			if(v2.name==0) {
   				del=1;
   				break;
   			}
   				
   			v3=v2;
   			v2=v2.next;
   		}
   		if(del==1) {
   			if(v2==seq_up2) {
   				if(v2.next!=null) {
   					v2=v2.next;
   					seq_up2=v2;
   				}
   				else
   					seq_up2=null;
   			}
   			else if(v2.next==null)
   				v3.next=null;
   			else {
   				v2=v2.next;
   				v3.next=v2;
   			}
   		}
   	}
   	System.out.println("The sequence for Optimal PO");
   	plist c=seq_up2;
   	while(c!=null) {
   		
   		System.out.println("The sequence S"+c.name);
		sNode r=c.begin;
		while(r!=null) {
			if(r.next!=null) {
				System.out.print(r.id+" -> ");
			}
			else {
				System.out.print(r.id);
				System.out.println();
			}
			r=r.next;
		}
		c=c.next;
   	}
   }
   public static int compare_PO() {
	   int vio=0;
	   plist p=seq_up1;
	  
	   while(p!=null) {
		   int sat=0;
		   sNode k=p.begin;
		   while(k!=null) {
			   sNode j=k.next;
			  while(j!=null) {
				  sat=0;
				  String s1=k.id;
				  String s2=j.id;
				  plist q=seq_up2;
				  while(q!=null) {
					  sNode t=q.begin;
					  while(t!=null) {
					  sNode r=t.next;
					  while(r!=null) {
					   if((s1.compareTo(t.id))==0 && (s2.compareTo(r.id))==0)
						   sat=1;
					   r=r.next;
				   }
				   t=t.next;
			   }
			   q=q.next;
		   }
			if(sat==0)
				vio=1;
		   j=j.next;
			  }
		   k=k.next;
		   }
		   p=p.next;
	   }
	  return vio;
	  // if(vio==1)
		//   JOptionPane.showMessageDialog(firstFrame,"Partial Order relation changes due to update!! User may require to unfreeze requirements!!");
   }
    public static void ComputeResults(int num) {
    	//Find the list of frozen requirements in increment num and create an array arr
    	plist m=flist;
    	//First finding the number of frozen requirements
    	int count=0;
    	while(m!=null) {
    		if(m.name==num) {
    			sNode n=m.begin;
    			while(n!=null) {
    				if(n.visited==1 && n.flag==0)
    					count++;
    				n=n.next;
    			}
    			break;
    		}
    		m=m.next;
    	}
    	String arr[]=new String[count];
    	//Now copy the frozen requirements
    	int i=0;
    	while(m!=null) {
    		if(m.name==num) {
    			sNode n=m.begin;
    			while(n!=null) {
    				if(n.visited==1 && n.flag==0) {
    					arr[i]=n.id;
    					i++;
    				}
    				n=n.next;
    			}
    			break;
    		}
    		m=m.next;
    	}
    	//Now create all possible combinations
    	combo=null;
    	for(int j=1;j<=count;j++) {
    		 createCombination(arr, count, j); 
    	}
    	//Print Combinations
    	/*System.out.println("The list is: ");
    	plist k=combo;
    	while(k!=null) {
    		sNode t=k.begin;
    		while(t!=null) {
    			System.out.print(t.id+" ");
    			t=t.next;
    		}
    		System.out.println();
    		k=k.next;
    	}*/
    	//Now for each combination create the partial order
    	//Keeping copy of original items of Fro;
		Node dummy=null;
		Node k=Fro;
		while(k!=null) {
			Node temp=new Node();
			temp.id=k.id;
			temp.next=null;
			k=k.next;
			if(dummy==null)
				dummy=temp;
			else {
				Node p=dummy;
				while(p.next!=null)
					p=p.next;
				p.next=temp;
			}
		}
    	plist t=combo;
    	System.out.println("The combinations are");
    	while(t!=null) {
    		sNode r=t.begin;
    		while(r!=null) {
    			System.out.print(r.id+" ");
    			r=r.next;
    		}
    		System.out.println();
    		t=t.next;
    	}
    	int state=1;
    	if(Fro==null)
    		state=0;
    	double original=0;
    	t=combo;
    	while(t!=null) {
    		rint=0;
    	//Create the list
    		if(state==1) {
    			//Copying original set
    			Node k2=dummy;
    			//Fro=null;
    			while(k2!=null) {
    				Node temp=new Node();
    				temp.id=k2.id;
    				temp.next=null;
    				k2=k2.next;
    				int flag4=0;
    				if(Fro==null)
    					Fro=temp;
    				else {
    					Node p=Fro;
    					while(p.next!=null)
    					{	
    						p=p.next;
    					}
    					
    						p.next=temp;
    				}
    			}
    			compare3();
    			original=RiskExp2;
    		}
    		//removes items in the list x
    		sNode j=t.begin;
    		while(j!=null) {
    			String s=j.id;
     			Node t2=Fro;
     			 Node q=t2;
     			 int match=0;
     			 if(Fro!=null) {
     				while(t2!=null) {
          			if((t2.id.compareTo(s))==0) {
          				match=1;
          				break;
          			}
          		
          			q=t2;
          			t2=t2.next;
          		}
     			if(match==1) {	
          		if(q==Fro)
          			Fro=t2.next;
          		else if(t2.next==null)
          			q.next=null;
          		else {
          			t2=t2.next;
          			q.next=t2;
          		}
     			 }
     		 }
    			j=j.next;
    		}
    		if(prevFro!=null) {
        		Node v=prevFro;
        		while(v!=null) {
        			
        		int flag=0;
        		sNode x=t.begin;
        		while(x!=null) {
        			if((x.id.compareTo(v.id))==0)
        				flag=1;
        			x=x.next;
        		}
        		
        		if(flag==0) {
        			Node t2=new Node();
        			t2.id=v.id;
        			t2.next=null;
        			if(Fro==null) {
        				Fro=t2;
        			
        			}
        			else {
        				Node k3=Fro;
        				int flagz=0;
        				while(k3.next!=null) {
        					if((k3.id.compareTo(t2.id))==0)
        						flagz=1;
        					k3=k3.next;
        			}
        				if((k3.id.compareTo(t2.id))==0)
    						flagz=1;
        				if(flagz==0)
        					k3.next=t2;
        			}
        		}
        			v=v.next;
        		}
        		
    		}
        	//against each list created
    		if(Fro!=null) {
        		recreate_basicClusters();
           	 recreate_macroClusters();
           	 recreate_FRList();
           	 recreate_requirementSet();
           	 recreate_PO();
           	 Reremove_transitive();
           	 //display_PartialOrder2();
           	 obtain_source();
           	 create_frozenrequirementset();
           	 create_frozenPO();
           	 remove_frozentransitive();
           	 find_sink();
           	 add_remainEdge();
           	 Reexist_path();
           	 display_PartialOrder2();
           	 PO t1=proot2;
           	 while(t1!=null) {
           		 PO t2=proot2;
           		 int count2=0;
           		 while(t2!=null) {
           			 if((t1.id1.compareTo(t2.id1))==0)
           			 {
           				 if((t1.id2.compareTo(t2.id2))==0) 
           					count2++;
           			 }
           				 t2=t2.next;
           		 }
           		// System.out.println("Count for "+t1.id1+"->"+t1.id2+"is : "+count);
           		 if(count2>1) {
           			 PO t3=proot2;
           			 PO t4=t3;
           			 while(t3!=null) {
           				 if((t1.id1.compareTo(t3.id1))==0 && ((t1.id2.compareTo(t3.id2))==0))
               			 {
               			 if(t3==proot2)
               			 {
               				 t3=t3.next;
               				 proot2=t3;
               			 }
               			 else if(t3.next==null){
               				 t4.next=null;
               			 }
               			 else {
               				 t3=t3.next;
               				 t4.next=t3;
               			 }
               			 break;
               			 }
           				 t4=t3;
           				 t3=t3.next;
           			 }
           		 }
           		 t1=t1.next;
           	 }
           	if(state==0)
           		Fro=null;
          // 	compare3();
          //Re-calculate risk!!
     		FileReader f1=null;
     		try {
     			String st="Conflicting Precedences that are removed are: \n";
     			//int count=iteration-1;
     			int found=0;
     			String name="Iteration"+num+".txt";
     			f1=new FileReader(name);
     			int total=0;
     			int conflict=0;
     			double risk=0;
     			double impact=0;
     			int num2=0;
     			char c;
     			//System.out.println("Name is"+name);
     			String temp="";
     			while((i=f1.read())!=-1) {
     				temp="";
     				c=(char)i;
     				temp=temp.concat(Character.toString(c));
     			//	System.out.println("c is"+c);
     				while((i=f1.read())!=32)
     				{
     					c=(char)i;
     				//	System.out.println("c is"+c);
         				temp=temp.concat(Character.toString(c));
     				}
     				//System.out.println("Temp first is"+temp);
     				if((temp.compareTo("Total"))==0) {
     					temp="";
     					while((i=f1.read())!=10)
         				{
         					c=(char)i;
         					if(i!=13)
         						temp=temp.concat(Character.toString(c));
         				}
     					//System.out.println("Temp second is"+temp);
     					total=Integer.parseInt(temp);
     				}
     				else if((temp.compareTo("Conflict"))==0) {
     					temp="";
     					while((i=f1.read())!=10)
         				{
         					c=(char)i;
         					if(i!=13)
         						temp=temp.concat(Character.toString(c));
         				}
     					//System.out.println("Temp is"+temp);
     					conflict=Integer.parseInt(temp);
     				}
     				else if((temp.compareTo("Risk"))==0) {
     					temp="";
     					while((i=f1.read())!=10)
         				{
         					c=(char)i;
         					if(i!=13)
         						temp=temp.concat(Character.toString(c));
         				}
     					//System.out.println("Temp is"+temp);
     					risk=Double.parseDouble(temp);
     				}
     				else
     				{
     					//Check if second FR matches with the selected unfrozen FR
     					String v=temp;
     					temp="";
     					while((i=f1.read())!=32)
         				{
     						if(i!=13) {
         					c=(char)i;
             				temp=temp.concat(Character.toString(c));
     						}
         				}
     					//System.out.println("Temp is"+temp);
     					sNode z=t.begin;
     					int f=0;
     					String s="";
     					while(z!=null) {
     						s=z.id;
     						if((temp.compareTo(s))==0) 
     							f=1;
     						z=z.next;
     					}
     					if(f==1) {
     						num2++;
     						found=1;
     						while((i=f1.read())!=10) {
     							
     						}
     						st=st.concat(v+" -> "+temp+"\n");
     						}
     					//keep the impact value of other FR pair violation if found becomes true will be used to create new impact
     					else {
     						temp="";
         					while((i=f1.read())!=10)
             				{
         						if(i!=13) {
             					c=(char)i;
                 				temp=temp.concat(Character.toString(c));
         						}
             				}
         					//System.out.println("Temp third is"+temp);
         					impact=impact+Double.parseDouble(temp);
     					}
     					
     				
     				
     					
     				}
     				
     			}
     			if(found==1) //Then break from the loop
     			{
     				f1.close();
     				//Calculate the new risk
     				/*if(RiskExp2!=0) {
     					RiskExp2=RiskExp2-risk;
     					conflict=conflict-num;
     					total=total-num;
     					double prob=(double)((double)conflict/(double)total);
     					prob = Math.round(prob * 100.0) / 100.0;
     	        		System.out.println("probability is"+prob);
     	        		System.out.println("Impact is before scaling"+impact);
     	        		System.out.println("Num is "+num);
     	        		impact=((double)(1-0)*(double)(impact-1))/(double)(1000*conflict-1)+0;
     	        		System.out.println("Impact is before rounding"+impact);
     	        		impact = Math.round(impact * 100.0) / 100.0;
     	        		//impact=Double.valueOf(df.format(impact));
     	        		System.out.println("Impact is after rounding"+impact);
     	        		risk=prob*impact;
     	        		//risk=Double.valueOf(df.format(risk));
     	        		risk = Math.round(risk * 100.0) / 100.0;
     	        		RiskExp2=RiskExp2+risk;
     	        		RiskExp2 = Math.round(RiskExp2 * 100.0) / 100.0;
     	        		JOptionPane.showMessageDialog(firstFrame, "Risk has been reduced to "+RiskExp2);
     				}
     				else {*/
     					//RiskExp=RiskExp-risk;
     				double risknew=0;
     					
     						risknew=RiskExp;
     				//	double org=risknew;
     					risknew=risknew-risk;
     					conflict=conflict-num;
     					total=total-num;
     					double prob=(double)((double)conflict/(double)total);
     					prob = Math.round(prob * 100.0) / 100.0;
     	        		//System.out.println("probability is"+prob);
     	        		//System.out.println("Impact is before scaling"+impact);
     	        		//System.out.println("Num is "+num);
     	        		impact=((double)(1-0)*(double)(impact-1))/(double)(1000*conflict-1)+0;
     	        		//System.out.println("Impact is before rounding"+impact);
     	        		impact = Math.round(impact * 100.0) / 100.0;
     	        		//impact=Double.valueOf(df.format(impact));
     	        		//System.out.println("Impact is after rounding"+impact);
     	        		risk=prob*impact;
     	        		//risk=Double.valueOf(df.format(risk));
     	        		risk = Math.round(risk * 100.0) / 100.0;
     	        		risknew=risknew+risk;
     	        		
     	        		if(state!=0)
     	        			 risknew=risknew+rint;
     	        		if(state==0)
     	        			original=RiskExp;
     	        		//System.out.println("rint is"+rint);
     	        		//System.out.println("Added is"+risk);
     	        		//System.out.println("New risk is"+risknew);
     	        		//System.out.println("Org risk is"+original);
     	        		risknew = Math.round(risknew * 100.0) / 100.0;
     	        	t.val=((original-risknew)/original)*100;
     			}
     		}
     			catch(Exception e) {
     				
     			}
    		}
    		else
    		{
    			t.val=100;
    		}
    		t=t.next;
    	}
    	// print the results
    	t=combo;
    	while(t!=null) {
    		sNode h=t.begin;
    		while(h!=null) {
    			//System.out.print(h.id+" ");
    			h=h.next;
    		}
    	//	System.out.print(" val= "+t.val);
    		//System.out.println();
    		t=t.next;
    	}
    	//Now putting the data in an excel sheet
    	/*XSSFWorkbook workbook = new XSSFWorkbook(); 
    	  
        // Create a blank sheet 
        XSSFSheet sheet = workbook.createSheet("Risk reduction Analysis"); 
  
        // This data needs to be written (Object[]) 
        Map<String, Object[]> data = new TreeMap<String, Object[]>(); 
        t=combo;
        int i2=1;
        String tt=String.valueOf(i2);
        data.put(tt, new Object[]{ "FRs", " % Risk Reduced" }); 
        while(t!=null) {
        	String s="";
        	sNode r=t.begin;
        	while(r!=null) {
        		s=s.concat(r.id+" ");
        		r=r.next;
        	}
        	i2++;
        	tt=String.valueOf(i2);
        	data.put(tt, new Object[]{ s, String.valueOf(t.val) }); 
        	t=t.next;
        }
          // Iterate over data and write to sheet 
        Set<String> keyset = data.keySet(); 
        int rownum = 0; 
        for (String key : keyset) { 
            // this creates a new row in the sheet 
            Row row = sheet.createRow(rownum++); 
            Object[] objArr = data.get(key); 
            int cellnum = 0; 
            for (Object obj : objArr) { 
                // this line creates a cell in the next column of that row 
                Cell cell = row.createCell(cellnum++); 
                if (obj instanceof String) 
                    cell.setCellValue((String)obj); 
                else if (obj instanceof Integer) 
                    cell.setCellValue((Integer)obj); 
            } 
        } 
        try { 
            // this Writes the workbook gfgcontribute 
            FileOutputStream out = new FileOutputStream(new File("RiskAnalysis.xlsx")); 
            workbook.write(out); 
            out.close(); 
            System.out.println("RiskAnalysis.xlsx written successfully on disk."); 
        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } */

    	
    }
   public static void createCombination(String arr[], int count, int j) 
    { 
        // A temporary array to store all combination one by one 
      String data[]=new String[j]; 
  
        // Print all combination using temprary array 'data[]' 
        combinationUtil(arr, data, 0, count-1, 0, j); 
    } 
	public   static void combinationUtil(String arr[], String data[], int start, 
	           int end, int index, int r) 
	{ 
	// Current combination is ready to be printed, print it 
	if (index == r) 
	{ 
	plist temp=new plist();
	temp.name=1;
	temp.next=null;
	temp.begin=null;
	if(combo==null)
		combo=temp;
	else {
		plist v=combo;
		while(v.next!=null)
			v=v.next;
		v.next=temp;
	}
	for (int j=0; j<r; j++) {
	System.out.print(data[j]+" "); 
	sNode temp2=new sNode();
	temp2.id=data[j];
	temp2.next=null;
	if(temp.begin==null)
		temp.begin=temp2;
	else {
		sNode k=temp.begin;
		while(k.next!=null)
			k=k.next;
		k.next=temp2;
	}
	}
	//System.out.println("Done"); 
	//System.out.println(""); 
	return; 
	} 
	
	// replace index with all possible elements. The condition 
	// "end-i+1 >= r-index" makes sure that including one element 
	// at index will make a combination with remaining elements 
	// at remaining positions 
	for (int i=start; i<=end && end-i+1 >= r-index; i++) 
	{ 
	data[index] = arr[i]; 
	combinationUtil(arr, data, i+1, end, index+1, r); 
	} 
	} 

   
    public static void compare2() {
    	//System.out.println("Compare 2 is called!!");
    	PO op=null;
    	PO ap=null;

    	vroot=null;
    	int totalpred=0;
    	if(rootOp==null || rootFRo==null) {
    		
    	}
    	else {
    		/* Constructing precedence for optimal order*/
    		plist p=rootOp;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				temp.next=null;
    				//PO t1=op;
    				if(op==null) {
    					op=temp;
    					totalpred++;
    				}
    				else {
    					int dup=0;
    					PO t2=op;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						//System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    						totalpred++;
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		
    		/* Constructing precedence for alternate order*/
    		//System.out.println("the precedences for alternate order are: ");
    	 p=rootFRo;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				
    				temp.next=null;
    				//PO t1=op;
    				if(ap==null) {
    					//System.out.println("Checking for "+s1+" -> "+s2);
    					ap=temp;
    					
    				}
    				else {
    					int dup=0;
    					PO t2=ap;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						//System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    					
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		vedges=null;
    		PO temp1=op;
    		while(temp1!=null) {
    			//System.out.println("Violation of temp1.id1"+temp1.id1+"->"+temp1.id2);
    			int v=0;
    			int f=0;
    			PO temp2=ap;
    			while(temp2!=null) {
    				//System.out.println("Checking against "+temp2.id1+"->"+temp2.id2);
    				if((temp2.id1.compareTo(temp1.id2))==0 && (temp2.id2.compareTo(temp1.id1))==0)
    					v=1;
    				else if((temp2.id1.compareTo(temp1.id1))==0 && (temp2.id2.compareTo(temp1.id2))==0)
    					f=1; 
    				temp2=temp2.next;
    			}
    			//Precedence directly violated
    			if(v==1) {
    			//System.out.println("Violate");
    			PO temp=new PO();
    			temp.id1=temp1.id1;
    			temp.id2=temp1.id2;
    			if(vedges==null) {
    				vedges=temp;
    			}
    			else {
    				PO h=vedges;
    				while(h.next!=null)
    					h=h.next;
    				h.next=temp;
    				}
    			}
    			//Precedence no longer exists
    			if(v==0 && f==0) {
    				//System.out.println("Non existant");
    				PO temp=new PO();
        			temp.id1=temp1.id1;
        			temp.id2=temp1.id2;
        			if(vedges==null) {
        				vedges=temp;
        			}
        			else {
        				PO h=vedges;
        				while(h.next!=null)
        					h=h.next;
        				h.next=temp;
        				}
    			}
    			temp1=temp1.next;
    		}
    		double risk=0;
    		int vpred=0;
    		double val1=0, val2=0;
    		if(vedges!=null) {
    			BufferedWriter b1=null;
        		String name="Iteration"+iteration+".txt";
        		 //System.out.println("name is "+name);
        	//System.out.println("The violating pairs are");
        	//textOrder1.append("The conflicting precedences in this iteration are");
        	//textOrder1.append("\n");
        	PO k=vedges;
        	double impact=0;
        	int num=0;
        	try {
        		
        		 b1 = new BufferedWriter(new FileWriter(name, false));
        	
        	while(k!=null) {
        		int flag=1;
        		val1=0;
        		val2=0;
        		if(VprevEdges!=null) {
        			PO j=VprevEdges;
        			while(j!=null) {
        				if((j.id1.compareTo(k.id1))==0 && (j.id2.compareTo(k.id2))==0)
        					flag=0;
        				j=j.next;
        			}
        			Node m=prevFro;
            		int ex=0;
            		while(m!=null) {
            			if((m.id.compareTo(k.id1))==0)
            				ex=1;
            			if((m.id.compareTo(k.id2))==0)
            				ex=1;
            			m=m.next;
            		}
        		if(flag==1 && ex==0) {	
        		vpred++;
        		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
    	        int integer1 = in1.nextInt();
    	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
    	        int integer2 = in2.nextInt();
        		String s=k.id1+"->"+k.id2;
        		//textOrder1.append(s);
        		//textOrder1.append("\n");
        		matrix t1=wd;
        		
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val1=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		t1=wn;
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val2=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		}
        		}
        		else {
        			Node m=prevFro;
            		int ex=0;
            		while(m!=null) {
            			if((m.id.compareTo(k.id1))==0)
            				ex=1;
            			if((m.id.compareTo(k.id2))==0)
            				ex=1;
            			m=m.next;
            		}
            		if(ex==0) {
        			vpred++;
            		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
        	        int integer1 = in1.nextInt();
        	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
        	        int integer2 = in2.nextInt();
            		String s=k.id1+"->"+k.id2;
            		//textOrder1.append(s);
            		//textOrder1.append("\n");
            		matrix t1=wd;
            		
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val1=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
            		t1=wn;
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val2=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
        		}
        		}		
        	
        		if(val1!=0 && val2!=0) {
        			num++;
        			//System.out.println("Val 2 is "+val2);
        			//System.out.println("for Edge "+k.id1+" -> "+k.id2);
        		if(val2>100) {
        			val2=((double)(100-1)*(double)(val2-1))/(double)(10000-1)+1;
        			val2=Math.round(val2 * 100.0) / 100.0;
        		}
        		
        		impact=impact+val1*val2;
        		b1.append(k.id1+" "+k.id2+" "+val1*val2);
        		b1.newLine();
        		}
        		
        		k=k.next;
        	
        		}
        	if(vpred==0) {
        		//textOrder1.append("None");
        		probability=0;
        		impact=0;
        	}
        	else {
        		double prob=(double)((double)vpred/(double)totalpred);
        	//	prob=Double.valueOf(df.format(prob));
        		prob = Math.round(prob * 100.0) / 100.0;
        		b1.append("Total "+totalpred);
        		b1.newLine();
        		b1.append("Conflict "+vpred);
        		b1.newLine();
        		//System.out.println("probability is"+prob);
        		//System.out.println("Impact is before scaling"+impact);
        		//System.out.println("Num is "+num);
        		if (impact!=0)
        			impact=((double)(1-0)*(double)(impact-1))/(double)(1000*num-1)+0;
        		//System.out.println("Impact is before rounding"+impact);
        		impact = Math.round(impact * 100.0) / 100.0;
        		//impact=Double.valueOf(df.format(impact));
        		//System.out.println("Impact is after rounding"+impact);
        		risk=prob*impact;
        		//risk=Double.valueOf(df.format(risk));
        		risk = Math.round(risk * 100.0) / 100.0;

        		//System.out.println("Risk Exposure in this iteration is"+risk);
        		 RiskExp2=RiskExp+risk;
        		b1.append("Risk "+risk);
         		b1.newLine();
         		b1.close();
        		//System.out.println("total risk is"+RiskExp2);
        	//	textOrder1.append("Probability is: ");
        	//	textOrder1.append(String.valueOf(prob));
        	//	textOrder1.append("\n Impact is: ");
        	//	textOrder1.append(String.valueOf(impact));
        	//	textOrder1.append("\n Risk in this iteration: ");
        	//	textOrder1.append(String.valueOf(risk));
        	//	textOrder1.append("\n Total Risk is: ");
        	//	textOrder1.append(String.valueOf(RiskExp2));
        		probability=prob;
        		impval=impact;
        	}
        }
        catch(IOException ez) {
        	
        }
        		
        	}
    	
    		
    	}
    	plist t1=new plist();
        t1.name=iteration;
        t1.next=null;
        t1.begin=null;
        Node g=Fro;
        while(g!=null) {
        	int flag=0;
        	Node h=prevFro;
        	while(h!=null) {
        		if((g.id.compareTo(h.id))==0)
        			flag=1;
        		h=h.next;
        	}
        	if(flag==0) {
        		sNode t2=new sNode();
        		t2.id=g.id;
        		t2.flag=0;
        		t2.visited=0;
        		//This loop checks whether the FR violates or not..
        		PO temp=vedges;
        		while(temp!=null) {
        		//	System.out.println("temp.id= "+temp.id2+" t2.id= "+t2.id);
        			if((temp.id2.compareTo(t2.id))==0) {
        				t2.visited=1;
        				break;
        			}
        			temp=temp.next;
        		}
        		if(t1.begin==null)
        			t1.begin=t2;
        		else {
        			sNode r=t1.begin;
        			while(r.next!=null)
        				r=r.next;
        			r.next=t2;
        		}
        	}
        	g=g.next;
        }
        if(flist==null)
        	flist=t1;
        else {
       	 plist q=flist;
       	 int fl=0;
       	 while(q!=null) {
       		 if(q.name==t1.name) {
       			 q.begin=null;
       			 q.begin=t1.begin;
       			 fl=1;
       			 break;
       		 }
       		 q=q.next;
       	 }
       	 if(fl==0) {
        	 q=flist;
        	while(q.next!=null)
        		q=q.next;
        	q.next=t1;
       	 }
        }

    }
    public static void show_riskReport() {
    	System.out.println("called for risk report");
    	String p=null;
    	String i=null;
    	String r=null;
    	String r2=null;
    	//categorizing probability
    	if(probability >=0 && probability<=0.2)
    		p="low";
    	else if (probability >0.2 && probability<=0.4)
    		p="moderate";
    	else if (probability >0.4 && probability<=0.6)
    		p="significant";
    	else if (probability >0.6 && probability<=0.8)
    		p="major";
    	else if (probability >0.8 && probability<=1.0)
    		p="high";
    	//System.out.println("P as "+p);
    	//Categorizing impact
    	if(impval >=0 && impval<=0.2)
    		i="low";
    	else if (impval >0.2 && impval<=0.4)
    		i="moderate";
    	else if (impval >0.4 && impval<=0.6)
    		i="significant";
    	else if (impval >0.6 && impval<=0.8)
    		i="major";
    	else if (impval >0.8 && impval<=1.0)
    		i="high";
     	//System.out.println("i as "+i);
    	//Categorzing risk in current iteration
    	if((p.compareTo("low"))==0 && ((i.compareTo("low"))==0 || (i.compareTo("moderate"))==0 || (i.compareTo("significant"))==0))
				r="low";
    	else if((p.compareTo("low"))==0 && ((i.compareTo("major"))==0 || (i.compareTo("high"))==0))
    			r="moderate";
    	else if((i.compareTo("low"))==0 && ((p.compareTo("moderate"))==0 || (p.compareTo("significant"))==0))
			r="low";
    	else if((i.compareTo("moderate"))==0 && ((p.compareTo("moderate"))==0 || (p.compareTo("significant"))==0))
			r="moderate";
    	else if((i.compareTo("significant"))==0 && ((p.compareTo("moderate"))==0))
			r="moderate";
    	else if((i.compareTo("low"))==0 && ((p.compareTo("major"))==0 || (p.compareTo("high"))==0))
			r="moderate";
    	else if((p.compareTo("moderate"))==0 && ((i.compareTo("major"))==0 || (i.compareTo("high"))==0))
			r="significant";
    	else if((p.compareTo("significant"))==0 && ((i.compareTo("major"))==0 || (i.compareTo("significant"))==0))
			r="significant";
    	else if((p.compareTo("major"))==0 && ((i.compareTo("moderate"))==0 || (i.compareTo("significant"))==0))
			r="significant";
    	else if((p.compareTo("high"))==0 && ((i.compareTo("moderate"))==0))
			r="significant";
    	else
    		r="high";
     	//System.out.println("r as "+r);
     	//System.out.println("RiskExp2 as "+RiskExp2);
     	//System.out.println("RiskExp as "+RiskExp);
     	if(RiskExp2!=0) {
    	//Categorizing total risk
    	if(RiskExp2>=0 && RiskExp2<=0.2)
    		r2="low";
    	else if(RiskExp2>0.2 && RiskExp2<=0.4)
    		r2="moderate";
    	else if(RiskExp2>0.4 && RiskExp2<=0.6)
    		r2="significant";
    	else if(RiskExp2>0.6)
    		r2="High";
    	}
     	else {
     		if(RiskExp!=0) {
     	    	//Categorizing total risk
     	    	if(RiskExp>=0 && RiskExp<=0.2)
     	    		r2="low";
     	    	else if(RiskExp>0.2 && RiskExp<=0.4)
     	    		r2="moderate";
     	    	else if(RiskExp>0.4 && RiskExp<=0.6)
     	    		r2="significant";
     	    	else if(RiskExp>0.6)
     	    		r2="High";
     	}
     	
     	}
     	//System.out.println("r2 as "+r2);}
     	
    	// Finding the optimal choices
		Node list=null;
		plist t=rootOp;
		while(t!=null) {
			sNode m=t.begin;
			while(m!=null) {
				int flag=0;
				String k=m.id;
				Node j=prevFro;
				/* Checking whether exists in the frozen list*/
				while(j!=null)
				{
					if((j.id.compareTo(k))==0)
						flag=1;
					
					j=j.next;
					}
				if(flag==0) {
					/*check if already added since multiple sequence may start with same FR*/
					Node n=list;
					Node temp=new Node();
					temp.id=k;
					temp.next=null;
					int check=0;
					if(n!=null) {
					while(n.next!=null) {
						if((n.id.compareTo(k))==0)
							check=1;
						n=n.next;
					}
					if((n.id.compareTo(k))==0)
						check=1;
					if(check==0) {
						n.next=temp;
					}
					}
					else
						list=temp;
						
					break;
				}
				m=m.next;
				}
			t=t.next;
		}
	 	//System.out.println("End of loop");
		String start="Increment should start with implementing FRs: ";
		Node n=list;
		while(n!=null) {
			if(n.next!=null)
				start=start.concat(n.id+" or ");
			else
				start=start.concat(n.id);
			n=n.next;
		}
		start=start.concat(". And any other requirements that follows from these!!");
	 	//System.out.println("start as "+start);
		
    	/* For total risk 0-0.2: low 0.2-0.4 Moderate 0.4-0.6 Significant 0.6-above high*/
    	if((r.compareTo("low"))==0)
    	{
    		if(r2.compareTo("low")==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+"\n User can continue with the decision.", "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("moderate"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!!", "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("significant"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("high"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the unfreezing some frozen requirements.", "Risk Analysis", JOptionPane.OK_OPTION);

    	}
    	else if((r.compareTo("moderate"))==0) {
    		if(r2.compareTo("low")==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!!", "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("moderate"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!!", "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("significant"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("high"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the unfreezing some frozen requirements.", "Risk Analysis", JOptionPane.OK_OPTION);

    
    	}	else if((r.compareTo("significant"))==0) {
    		if(r2.compareTo("low")==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("moderate"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("significant"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("high"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the unfreezing some frozen requirements.", "Risk Analysis", JOptionPane.OK_OPTION);

    	}
    	else if((r.compareTo("high"))==0) {
    		if(r2.compareTo("low")==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("moderate"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		if((r2.compareTo("significant"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the choice. It may have later greater impact in the project objectives!! "+start, "Risk Analysis", JOptionPane.OK_OPTION);
    		else if((r2.compareTo("high"))==0)
    			JOptionPane.showMessageDialog(po_frame, " The probability of conflicting precedences is: "+probability+" that is: "+p.toUpperCase()+"\n The impact value is: "+impval+" that is "+i.toUpperCase()+"\n The risk exposure in this iteration : "+r.toUpperCase()+".  \n Total Risk is also: "+r2.toUpperCase()+" \n User may reconsider the unfreezing some frozen requirements.", "Risk Analysis", JOptionPane.OK_OPTION);
    	}
    }
    public static void recreate_basicClusters() {
    	bcHead2=null;
    	if(bcHead==null) {
    		create_BasicClusters();
    		
    	}
    	display_BasicClusters();
    	BC b=bcHead;
    	while(b!=null) {
    		
    		BC temp=new BC();
    		temp.Nid=b.Nid;
    		temp.next=null;
    		temp.begin=null;
    		if(bcHead2==null)
    			bcHead2=temp;
    		else {
    			BC q=bcHead2;
    			while(q.next!=null)
    				q=q.next;
    			q.next=temp;
    		}
    		FRDep f=b.begin;
    		int max=0;
    		int flag=0;
    		while(f!=null) {
    			String check=f.id;
    			int found=0;
    			Node p=Fro;
    			while(p!=null) {
    				if((p.id.compareTo(f.id))==0) {
    					found=1;
    					if(f.val>max)
    						max=f.val;
    			
    				}
    				p=p.next;
    			}
    			if(found==1) {
    				flag=1;
    				
    			}
    			else {
    				FRDep temp2=new FRDep();
    				temp2.id=f.id;
    				temp2.val=f.val;
    				temp2.next=null;
    				if(temp.begin==null)
    					temp.begin=temp2;
    				else {
    					FRDep m=temp.begin;
    					while(m.next!=null)
    						m=m.next;
    					m.next=temp2;
    				}
    			}
    			f=f.next;
    			
    		}
    		if(flag==1) {
    			FRDep temp2=new FRDep();
				temp2.id="fb";
				temp2.val=max;
				temp2.next=null;
				if(temp.begin==null)
					temp.begin=temp2;
				else {
					FRDep m=temp.begin;
					while(m.next!=null)
						m=m.next;
					m.next=temp2;
				}
    		}
    		b=b.next;
    	}
    	//System.out.println("Re-created");
    	 BC p = bcHead2;
         //System.out.println();
         //System.out.println("The basic clusters are:");
         //System.out.println();
         while (p != null) {
             //System.out.println("NFR: " + p.Nid);
             for (FRDep q = p.begin; q != null; q = q.next) {
                 //System.out.println("FR: " + q.id);
                 //System.out.println("Dependency Edge Weight: " + q.val);
             }
             //System.out.println();
             p = p.next;
         }
    }
    public static void recreate_macroClusters()
    {
    	Edge1 Nconflict = E_NN;
        mcHead2 = null;
        while (Nconflict != null) {
            BC p = bcHead2;
            final MC temp = new MC();
            temp.next = null;
            temp.Blist = null;
            temp.CEdge = 1;
            while (p != null) {
                if (p.Nid.compareTo(Nconflict.id1) == 0 || p.Nid.compareTo(Nconflict.id2) == 0) {
                    final BC newBC = new BC();
                    newBC.Nid = p.Nid;
                    newBC.begin = p.begin;
                    newBC.next = null;
                    if (temp.Blist == null) {
                        temp.Blist = newBC;
                    }
                    else {
                        BC q;
                        for (q = temp.Blist; q.next != null; q = q.next) {}
                        q.next = newBC;
                    }
                }
                p = p.next;
            }
            if (mcHead2 == null) {
                mcHead2 = temp;
            }
            else {
                MC r;
                for (r = mcHead2; r.next != null; r = r.next) {}
                r.next = temp;
            }
            Nconflict = Nconflict.next;
        }
        MC p = mcHead2;
        //System.out.println();
        //System.out.println("The macro clusters are:");
        //System.out.println();
        while (p != null) {
            //System.out.println("A macro cluster");
            for (BC q = p.Blist; q != null; q = q.next) {
                //System.out.println("NFR: " + q.Nid);
                for (FRDep r = q.begin; r != null; r = r.next) {
                    //System.out.println("FR: " + r.id);
                    //System.out.println("Dependency Edge Weight: " + r.val);
                }
                //System.out.println();
            }
            p = p.next;
        }
    }
    public static void recreate_FRList() {
    	FR2=null;
    	Node p=FR;
    	int flag=0;
    	while(p!=null) {
    		int found=0;
    		Node q=Fro;
    		while(q!=null) {
    			if((p.id.compareTo(q.id))==0) {
    				found=1;
    				break;
    			}
    			q=q.next;
    		}
    		if(found==1) {
    			flag=1;
    		}
    		else {
    			Node temp=new Node();
    			temp.id=p.id;
    			temp.next=null;
    			if(FR2==null)
    				FR2=temp;
    			else {
    				Node r=FR2;
    				while(r.next!=null)
    					r=r.next;
    				r.next=temp;
    			}
    		}
    		p=p.next;
    	}
    	if(flag==1) {
    		Node temp=new Node();
			temp.id="fb";
			temp.next=null;
			if(FR2==null)
				FR2=temp;
			else {
				Node r=FR2;
				while(r.next!=null)
					r=r.next;
				r.next=temp;
			}
    	}
    	
    }
    public static void recreate_requirementSet() {
    	 root2 = null;
         for (Node p = FR2; p.next != null; p = p.next) {
             for (Node q = p.next; q != null; q = q.next) {
                 final Rpair temp = new Rpair();
                 temp.id1 = p.id;
                 temp.id2 = q.id;
                 temp.done = 0;
                 temp.next = null;
                 if (root2 == null) {
                     root2 = temp;
                 }
                 else {
                     Rpair s;
                     for (s = root2; s.next != null; s = s.next) {}
                     s.next = temp;
                 }
             }
         }
         Rpair p = root2;
         int count = 0;
         //System.out.println("The requirements pair are: ");
         while (p != null) {
             //System.out.println(String.valueOf(p.id1) + " " + p.id2);
             p = p.next;
             ++count;
         }
         //System.out.println("The count is : " + count);
    }
    public static void recreate_PO() {
    	proot2 = null;
        for (Rpair point = root2; point != null; point = point.next) {
            Edge2 p = E_FF;
            int tflag = 0;
            while (p != null) {
                if ((p.id1.compareTo(point.id1) == 0 && p.id2.compareTo(point.id2) == 0) || (p.id1.compareTo(point.id2) == 0 && p.id2.compareTo(point.id1) == 0)) {
                    tflag = 1;
                    break;
                }
                p = p.next;
            }
            if (tflag == 1) {
               // System.out.println("Temporal Edge found for : " + point.id1 + " " + point.id2);
                point.done = 1;
                final PO temp = new PO();
                temp.id1 = p.id1;
                temp.id2 = p.id2;
                temp.next = null;
                int check=0;
                Node k=Fro;
                while(k!=null) {
                	if((p.id1.compareTo(k.id))==0)
                		check=1;
                	k=k.next;
                }
                if(check==0) {
                if (proot2 == null) {
                    proot2 = temp;
                }
                else {
                    PO r;
                    for (r = proot2; r.next != null; r = r.next) {}
                    r.next = temp;
                }
               }
            }
        }
        for (Rpair point = root2; point != null; point = point.next) {
            String fr1 = point.id1;
            String fr2 = point.id2;
            //System.out.println("Checking for " + fr1 + " " + fr2);
            if (point.done == 0) {
                fr1 = point.id1;
                fr2 = point.id2;
              //  System.out.println("Checking for " + fr1 + " " + fr2);
                int flagmc1 = 0;
                int flagmc2 = 0;
                int flagmc3 = 0;
                for (MC p2 = mcHead2; p2 != null; p2 = p2.next) {
                    flagmc1 = 0;
                    flagmc2 = 0;
                    for (BC q = p2.Blist; q != null; q = q.next) {
                        for (FRDep r2 = q.begin; r2 != null; r2 = r2.next) {
                            if (r2.id.compareTo(fr1) == 0) {
                                flagmc1 = 1;
                            }
                            if (r2.id.compareTo(fr2) == 0) {
                                flagmc2 = 1;
                            }
                        }
                    }
                    if (flagmc1 == 1 && flagmc2 == 1) {
                        flagmc3 = 1;
                        break;
                    }
                }
                if (flagmc3 == 1) {
                    point.done = 1;
                //    System.out.println("Belong to same macro cluster " + fr1 + " " + fr2);
                    if (choice == 1) {
                        recreate_case1(fr1, fr2);
                    }
                    else if (choice == 2) {
                        recreate_case2(fr1, fr2);
                    }
                    else if (choice == 3) {
                        recreate_case3(fr1, fr2);
                    }
                    else if (choice == 4) {
                        recreate_case4(fr1, fr2);
                    }
                }
                else {
                    int rflag1 = 0;
                    int rflag2 = 0;
                    LNFR1 = null;
                    LNFR2 = null;
                    for (BC bcluster = bcHead2; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id1) == 0) {
                                rflag1 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (LNFR1 == null) {
                                    LNFR1 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = LNFR1; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    for (BC bcluster = bcHead2; bcluster != null; bcluster = bcluster.next) {
                        FRDep s = bcluster.begin;
                        while (s != null) {
                            if (s.id.compareTo(point.id2) == 0) {
                                rflag2 = 1;
                                final Node temp2 = new Node();
                                temp2.id = bcluster.Nid;
                                temp2.next = null;
                                if (LNFR2 == null) {
                                    LNFR2 = temp2;
                                    break;
                                }
                                Node q2;
                                for (q2 = LNFR2; q2.next != null; q2 = q2.next) {}
                                q2.next = temp2;
                                break;
                            }
                            else {
                                s = s.next;
                            }
                        }
                    }
                    int count = 0;
                    int noteq = 0;
                    if (rflag1 == 1 && rflag2 == 1) {
                        Node l1 = LNFR1;
                        int check = 0;
                        while (l1 != null) {
                            Node l2 = LNFR2;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                        l1 = LNFR2;
                        check = 0;
                        while (l1 != null) {
                            Node l2 = LNFR1;
                            check = 0;
                            while (l2 != null) {
                                if (l1.id.compareTo(l2.id) == 0) {
                                    check = 1;
                                    ++count;
                                    break;
                                }
                                l2 = l2.next;
                            }
                            l1 = l1.next;
                            if (check == 0) {
                                noteq = 1;
                            }
                        }
                    }
                    if (count > 0) {
                        point.done = 1;
                        recreate_caseB(fr1, fr2);
                    }
                }
            }
            for (PO j = proot2; j != null; j = j.next) {
                if (j.next == null) {
                    //System.out.println("added edge is : " + j.id1 + "->" + j.id2);
                    break;
                }
            }
            final int f = recheck_cycle();
            if (f == 1) {
                //System.out.println("Loop is formed");
                PO p3 = proot2;
                PO q3 = p3.next;
                if (q3 != null) {
                    while (q3.next != null) {
                        p3 = p3.next;
                        q3 = p3.next;
                    }
                    p3.next = null;
                }
            }
            for (PO v = proot2; v != null; v = v.next) {
                v.visited = 0;
            }
           /* for (PO rt = proot2; rt != null; rt = rt.next) {
                final String p4 = rt.id2;
                final String g = rt.id1;
                for (PO ct = proot2; ct != null; ct = ct.next) {
                    if (ct.id1.compareTo(p4) == 0) {
                        Rpair k = root2;
                        final String t1 = p4;
                        final String t2 = ct.id2;
                        while (k != null) {
                            if ((k.id1.compareTo(g) != 0 || k.id2.compareTo(t2) != 0) && k.id1.compareTo(t2) == 0) {
                                k.id2.compareTo(g);
                            }
                            k = k.next;
                        }
                    }
                }
            }*/
        }
    }
    public static void recreate_case1(final String fr1, final String fr2) {
        int max = 0;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = mcHead2;p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                for (Edge1 conflict = E_NN; conflict != null; conflict = conflict.next) {
                    if (((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) && max < conflict.value) {
                        max = conflict.value;
                        nfr1 = N1;
                        nfr2 = N2;
                    }
                }
            }
        }
        //System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        //System.out.println("Max NFR is: " + maxNFR);
        BC bclist = bcHead2;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
              
            	 if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
            		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                      int integer = in.nextInt();
                      Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                      int integer2 = in2.nextInt();
     		        if(integer>integer2) {
     		            temp.id1 = fr1;
     		            temp.id2 = fr2;
     		        }
     		        else {
     		            temp.id1 = fr2;
     		            temp.id2 = fr1;
     		        }
     	        }else {
                temp.id1 = fr1;
                temp.id2 = fr2;
     	        }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            //System.out.println("Executing else with Min NFR is: " + minNFR);
            bclist = bcHead2;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		        }
   	        }
            else {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if((temp.id2.compareTo("fb"))!=0) {
        if (proot2 == null) {
            proot2 = temp;
        }
        else {
            PO r2;
            for (r2 = proot2; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
        } 
    }
    
    public static void recreate_case2(final String fr1, final String fr2) {
        final int max = 0;
        final String nfr1 = null;
        final String nfr2 = null;
        MC p = mcHead2;
        Node nlist = null;
        while (p != null) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                final Node temp1 = new Node();
                temp1.id = N1;
                final Node temp2 = new Node();
                temp2.id = N2;
                if (nlist == null) {
                    nlist = temp1;
                    temp1.next = temp2;
                }
                else {
                    Node j;
                    for (j = nlist; j.next != null; j = j.next) {}
                    j.next = temp1;
                    temp1.next = temp2;
                }
            }
            p = p.next;
        }
        for (Node f = nlist; f != null; f = f.next) {
            //System.out.println(f.id);
        }
        String maxNFR = null;
        final String minNFR = null;
        final int val1 = 0;
        final int val2 = 0;
        Node t = nlist;
        int priority = 0;
        while (t != null) {
            for (Node k = NFR; k != null; k = k.next) {
                if (k.id.compareTo(t.id) == 0 && priority < k.priority) {
                    priority = k.priority;
                    maxNFR = t.id;
                }
            }
            t = t.next;
        }
        //System.out.println("Max NFR is: " + maxNFR);
        BC bclist = bcHead2;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp3 = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp3.id1 = fr1;
   		            temp3.id2 = fr2;
   		        }
   		        else {
   		            temp3.id1 = fr2;
   		            temp3.id2 = fr1;
   		        }
   	        }
            else {
                temp3.id1 = fr1;
                temp3.id2 = fr2;
            }
            }
            else {
                temp3.id1 = fr2;
                temp3.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp3.id1 = fr1;
            temp3.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp3.id1 = fr2;
            temp3.id2 = fr1;
        }
        else {
            //System.out.println("entering else");
            t = nlist;
            priority = 0;
            int complete = 0;
            String min = "";
            int exists = 1;
            while (exists == 1) {
                exists = 0;
                Node q2;
                t = (q2 = nlist);
                while (t != null) {
                    if (t.id.compareTo(maxNFR) == 0) {
                        if (t == nlist) {
                            nlist = t.next;
                            break;
                        }
                        //System.out.println("In else");
                        q2.next = t.next;
                        break;
                    }
                    else {
                        q2 = t;
                        t = t.next;
                    }
                }
                for (Node r2 = nlist; r2 != null; r2 = r2.next) {
                    //System.out.println(r2.id);
                    if (r2.id.compareTo(maxNFR) == 0) {
                        exists = 1;
                    }
                }
            }
            //System.out.println("Done deletion");
            while (complete == 0) {
                t = nlist;
                priority = 0;
                while (t != null) {
                    Node i = NFR;
                    //System.out.println("compairing " + t.id);
                    while (i != null) {
                        if (i.id.compareTo(t.id) == 0) {
                            //System.out.println("Priority is of k:" + i.id + " " + i.priority);
                            if (priority < i.priority) {
                                priority = i.priority;
                                min = i.id;
                            }
                        }
                        i = i.next;
                    }
                    //System.out.println("Priority is" + priority);
                    t = t.next;
                }
                //System.out.println("NFR selected =" + min);
                flag1 = 0;
                flag2 = 0;
                v1 = 0;
                v2 = 0;
                for (bclist = bcHead2; bclist != null; bclist = bclist.next) {
                    if (min.compareTo(bclist.Nid) == 0) {
                        for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                            if (flist2.id.compareTo(fr1) == 0) {
                                flag1 = 1;
                                v1 = flist2.val;
                            }
                            else if (flist2.id.compareTo(fr2) == 0) {
                                flag2 = 1;
                                v2 = flist2.val;
                            }
                        }
                        break;
                    }
                }
                //System.out.println("flag1 and flag2: " + flag1 + " " + flag2);
                if (flag1 == 1 || flag2 == 1) {
                    complete = 1;
                    if (flag1 == 1 && flag2 == 1) {
                        if (v1 >= v2) {
                        	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
                      		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                                int integer = in.nextInt();
                                Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                                int integer2 = in2.nextInt();
               		        if(integer>integer2) {
               		            temp3.id1 = fr1;
               		            temp3.id2 = fr2;
               		        }
               		        else {
               		            temp3.id1 = fr2;
               		            temp3.id2 = fr1;
               		        }
               	        }
                        else {
                            temp3.id1 = fr1;
                            temp3.id2 = fr2;
                        }
                        }
                        else {
                            temp3.id1 = fr2;
                            temp3.id2 = fr1;
                        }
                    }
                    else if (flag1 == 1) {
                        temp3.id1 = fr1;
                        temp3.id2 = fr2;
                    }
                    else if (flag2 == 1) {
                        temp3.id1 = fr2;
                        temp3.id2 = fr1;
                    }
                }
                exists = 1;
                while (exists == 1) {
                    Node h;
                    Node l = h = nlist;
                    exists = 0;
                    while (l != null) {
                        if (l.id.compareTo(min) == 0) {
                            if (l == nlist) {
                                nlist = l.next;
                                break;
                            }
                            h.next = l.next;
                            break;
                        }
                        else {
                            h = l;
                            l = l.next;
                        }
                    }
                    for (l = nlist; l != null; l = l.next) {
                        if (l.id.compareTo(min) == 0) {
                            exists = 1;
                        }
                    }
                }
            }
        }
        if((temp3.id1.compareTo("fb"))!=0) {
        if (proot2 == null) {
            proot2 = temp3;
        }
        else {
            PO r3;
            for (r3 = proot2; r3.next != null; r3 = r3.next) {}
            r3.next = temp3;
        }
        }
    }
    
    public static void recreate_case3(final String fr1, final String fr2) {
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = mcHead2; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                //System.out.println("N1 and N2 are" + N1 + " " + N2);
                Edge1 conflict = E_NN;
                int degree = 0;
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
                //System.out.println("The degree is " + degree);
                int p2 = 0;
                int p3 = 0;
                for (Node k = NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                //System.out.println("p1 and p2 are" + p2 + " " + p3);
                final float product = (degree - 40) * ((p2 + p3) / 200.0f);
                //System.out.println("Product is" + product);
                if (max < product) {
                    max = product;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        //System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = bcHead2;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		        }
   	        }
            else {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            bclist = bcHead2;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		        }
   	        }else {
                temp.id1 = fr1;
                temp.id2 = fr2;
   	        }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if((temp.id2.compareTo("fb"))!=0) {
        if (proot2 == null) {
            proot2= temp;
        }
        else {
            PO r2;
            for (r2 = proot2; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
        }
    }
    
    public static void recreate_case4(final String fr1, final String fr2) {
        float max = 0.0f;
        String nfr1 = null;
        String nfr2 = null;
        for (MC p = mcHead2; p != null; p = p.next) {
            int flagmc1 = 0;
            int flagmc2 = 0;
            String N1 = null;
            String N2 = null;
            for (BC q = p.Blist; q != null; q = q.next) {
                for (FRDep r = q.begin; r != null; r = r.next) {
                    if (r.id.compareTo(fr1) == 0) {
                        flagmc1 = 1;
                    }
                    if (r.id.compareTo(fr2) == 0) {
                        flagmc2 = 1;
                    }
                }
            }
            if (flagmc1 == 1 && flagmc2 == 1) {
                BC q = p.Blist;
                N1 = q.Nid;
                q = q.next;
                N2 = q.Nid;
                Edge1 conflict = E_NN;
                int degree = 0;
                while (conflict != null) {
                    if ((N1.compareTo(conflict.id1) == 0 && N2.compareTo(conflict.id2) == 0) || (N1.compareTo(conflict.id2) == 0 && N2.compareTo(conflict.id1) == 0)) {
                        degree = conflict.value;
                    }
                    conflict = conflict.next;
                }
                int p2 = 0;
                int p3 = 0;
                for (Node k = NFR; k != null; k = k.next) {
                    if (k.id.compareTo(N1) == 0) {
                        p2 = k.priority;
                    }
                    if (k.id.compareTo(N2) == 0) {
                        p3 = k.priority;
                    }
                }
                final float sum = (float)w1 * degree + (p2 + p3) * (float)w2;
                //System.out.println("The sum is" + sum);
                if (max < sum) {
                    max = sum;
                    nfr1 = N1;
                    nfr2 = N2;
                }
            }
        }
        //System.out.println("The NFRs are " + nfr1 + " " + nfr2);
        String maxNFR = null;
        String minNFR = null;
        int val1 = 0;
        int val2 = 0;
        for (Node t = NFR; t != null; t = t.next) {
            if (t.id.compareTo(nfr1) == 0) {
                val1 = t.priority;
            }
            else if (t.id.compareTo(nfr2) == 0) {
                val2 = t.priority;
            }
        }
        if (val1 > val2) {
            maxNFR = nfr1;
            minNFR = nfr2;
        }
        else if (val1 < val2) {
            maxNFR = nfr2;
            minNFR = nfr1;
        }
        BC bclist = bcHead2;
        int flag1 = 0;
        int flag2 = 0;
        int v1 = 0;
        int v2 = 0;
        while (bclist != null) {
            flag1 = 0;
            flag2 = 0;
            if (maxNFR.compareTo(bclist.Nid) == 0) {
                for (FRDep flist = bclist.begin; flist != null; flist = flist.next) {
                    if (flist.id.compareTo(fr1) == 0) {
                        flag1 = 1;
                        v1 = flist.val;
                    }
                    else if (flist.id.compareTo(fr2) == 0) {
                        flag2 = 1;
                        v2 = flist.val;
                    }
                }
                break;
            }
            bclist = bclist.next;
        }
        final PO temp = new PO();
        if (flag1 == 1 && flag2 == 1) {
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		        }
   	        }
            else {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        else if (flag1 == 1) {
            temp.id1 = fr1;
            temp.id2 = fr2;
        }
        else if (flag2 == 1) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        else {
            bclist = bcHead2;
            v1 = 0;
            v2 = 0;
            while (bclist != null) {
                flag1 = 0;
                flag2 = 0;
                if (minNFR.compareTo(bclist.Nid) == 0) {
                    for (FRDep flist2 = bclist.begin; flist2 != null; flist2 = flist2.next) {
                        if (flist2.id.compareTo(fr1) == 0) {
                            v1 = flist2.val;
                        }
                        else if (flist2.id.compareTo(fr2) == 0) {
                            v2 = flist2.val;
                        }
                    }
                    break;
                }
                bclist = bclist.next;
            }
            if (v1 >= v2) {
            	if(v1==v2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
          		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                    int integer = in.nextInt();
                    Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                    int integer2 = in2.nextInt();
   		        if(integer>integer2) {
   		            temp.id1 = fr1;
   		            temp.id2 = fr2;
   		        }
   		        else {
   		            temp.id1 = fr2;
   		            temp.id2 = fr1;
   		        }
   	        }
            else {
                temp.id1 = fr1;
                temp.id2 = fr2;
            }
            }
            else {
                temp.id1 = fr2;
                temp.id2 = fr1;
            }
        }
        if((temp.id2.compareTo("fb"))!=0)
        if (proot2 == null) {
            proot2 = temp;
        }
        else {
            PO r2;
            for (r2 = proot2; r2.next != null; r2 = r2.next) {}
            r2.next = temp;
        }
    }
    public static void recreate_caseB(final String fr1, final String fr2) {
    //	System.out.println("Called Recreate_caseB");
        Node t = NFR;
        String maxNFR = null;
        int priority = 0;
        while (t != null) {
            BC b = bcHead2;
            while (b != null) {
                if (b.Nid.compareTo(t.id) == 0) {
                    int flag1 = 0;
                    int flag2 = 0;
                    for (FRDep k = b.begin; k != null; k = k.next) {
                        if ((k.id.compareTo(fr1)) == 0) {
                            flag1 = 1;
                        }
                        if ((k.id.compareTo(fr2)) == 0) {
                            flag2 = 1;
                        }
                    }
                    System.out.println("NFR is"+t.id+" with priority "+t.priority);
                    if (flag1 == 1 && flag2 == 1 && priority < t.priority) {
                        priority = t.priority;
                        maxNFR = t.id;
                        break;
                    }
                    break;
                }
                else {
                    b = b.next;
                }
            }
            t = t.next;
        }
        System.out.println("Max NFR is: " + maxNFR);
        BC b = bcHead2;
        int val1 = 0;
        int val2 = 0;
        while (b != null) {
            if (b.Nid.compareTo(maxNFR) == 0) {
                final int flag3 = 0;
                final int flag4 = 0;
                for (FRDep i = b.begin; i != null; i = i.next) {
                    if (i.id.compareTo(fr1) == 0) {
                        val1 = i.val;
                    }
                    if (i.id.compareTo(fr2) == 0) {
                        val2 = i.val;
                    }
                }
            }
            b = b.next;
        }
        final PO temp = new PO();
        
        if (val1 >= val2) {
        	if(val1==val2 && (fr1.compareTo("fb"))!=0 && (fr2.compareTo("fb"))!=0) {
      		  Scanner in = new Scanner(fr1).useDelimiter("[^0-9]+");
                int integer = in.nextInt();
                Scanner in2 = new Scanner(fr2).useDelimiter("[^0-9]+");
                int integer2 = in2.nextInt();
		        if(integer>integer2) {
		            temp.id1 = fr1;
		            temp.id2 = fr2;
		        }
		        else {
		            temp.id1 = fr2;
		            temp.id2 = fr1;
		        }
	        }
        	else {
            temp.id1 = fr1;
            temp.id2 = fr2;
        	}
        }
        else if (val1 < val2) {
            temp.id1 = fr2;
            temp.id2 = fr1;
        }
        if((temp.id2.compareTo("fb"))!=0) {
        if (proot2 == null) {
            proot2 = temp;
        }
        else {
            PO r;
            for (r = proot2; r.next != null; r = r.next) {}
            r.next = temp;
        }
        }
    }
    public static int recheck_cycle() {
    	Node p=FR;
    	int count=0;
    	while(p!=null) {
    		count++;
    		p=p.next;
    	}
    	int[] arr=new int[count];
    	int max=0;
    	p=FR;
    	int i=0;
    	//Storing integer portion of each FR label in an array.
    	while(p!=null) {
    		Scanner in = new Scanner(p.id).useDelimiter("[^0-9]+");
    	        int integer = in.nextInt();
    	        arr[i]=integer;
    		
    		p=p.next;
    	}
    	//searching the maximum integer label.
    	int j=0;
    	while(j<i) {
    		if(max<arr[j])
    			max=arr[j];
    		j++;
    	}
    	 POGraph graph = new POGraph(1000); 
    	 PO q=proot2;
    	 while(q!=null) {
    		 int num1=0,num2=0;
    		 if((q.id1.compareTo("fb"))==0) {
    			 num1=max+1;
    		 Scanner in1 = new Scanner(q.id2).useDelimiter("[^0-9]+");
    		 int integer = in1.nextInt();
    		 num2=integer;
    		 }
    		 else {
    			 Scanner in1 = new Scanner(q.id1).useDelimiter("[^0-9]+");
        		 int integer1 = in1.nextInt(); 
        		 num1=integer1;
        		 Scanner in2 = new Scanner(q.id2).useDelimiter("[^0-9]+");
        		 int integer2 = in2.nextInt(); 
        		 num2=integer2;
    		 }
    		 graph.addEdge(num1,num2);
 	       
    		 q=q.next;
    	 }
    	 if(graph.isCyclic()) 
    		 return 1;
    	 else 
    		 return 0;
    }
    public static void remove_transitive() {
    PO j=proot;
    while(j!=null) {
    	j.visited=0;
    	j=j.next;
    }
    for(Node p=FR;p!=null;p=p.next) {
    	for(Node q=FR;q!=null;q=q.next) {
    		for(Node r=FR;r!=null;r=r.next) {
    			String s1=p.id;
    			String s2=q.id;
    			PO k=proot;
    			int flag1=0;
    			while(k!=null) {
    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
    					flag1=1;
    					break;
    				}
    				k=k.next;
    			}
    			s1=q.id;
    			s2=r.id;
    			k=proot;
    			int flag2=0;
    			while(k!=null) {
    				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
    					flag2=1;
    					break;
    				}
    				k=k.next;
    			}
    			if(flag1==1 && flag2==1) {
        			s1=p.id;
        			s2=r.id;
        			System.out.println("removing "+p.id+" -> "+r.id+" due to "+p.id+" -> "+q.id+" and "+q.id+" -> "+r.id);
        			
        			PO m=proot;
        			PO n=m;
        			int found=0;
        			while(m!=null) {
        				if((m.id1.compareTo(s1))==0 && (m.id2.compareTo(s2))==0) {
        					found=1;
        					m.visited=1;
        					break;
        				}
        				n=m;
        				m=m.next;
        			}
        			/*if(found==1) {
        				if(m==proot) {
        					if(m.next!=null) {
        						m=m.next;
        						proot=m;
        					}
        					else
        						proot=null;
        				}
        				else if(m.next==null) {
        					n.next=null;
        				}
        				else {
        					m=m.next;
        					n.next=m;
        				}
        			}*/
    		}
    	
    			
    		}
    	}
    }
    PO p=proot;
    int flag=1;
    while(flag==1) {
    	flag=0;
    	PO m=proot;
		PO n=m;
		int found=0;
		while(m!=null) {
			if(m.visited==1) {
				found=1;
				break;
			}
			n=m;
			m=m.next;
		}
		System.out.println("Found "+m.id1+" -> "+m.id2);
		if(found==1) {
			if(m==proot) {
				if(m.next!=null) {
					m=m.next;
					proot=m;
				}
				else
					proot=null;
			}
			else if(m.next==null) {
				n.next=null;
			}
			else {
				m=m.next;
				n.next=m;
			}
		}
    	PO g=proot;
    	while(g!=null) {
    		if(g.visited==1)
    			flag=1;
    		g=g.next;
    	}
    }
    System.out.println("After removing transitive edges");
    PO r=proot;
    while(r!=null) {
    	System.out.println(r.id1+" -> "+r.id2);
    	r=r.next;
    }
    }
    public static void Reremove_transitive() {
    	PO j=proot2;
    	while(j!=null) {
    		j.visited=0;
    		j=j.next;
    	}
        for(Node p=FR;p!=null;p=p.next) {
        	for(Node q=FR;q!=null;q=q.next) {
        		for(Node r=FR;r!=null;r=r.next) {
        			String s1=p.id;
        			String s2=q.id;
        			PO k=proot2;
        			int flag1=0;
        			while(k!=null) {
        				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
        					flag1=1;
        					break;
        				}
        				k=k.next;
        			}
        			s1=q.id;
        			s2=r.id;
        			k=proot2;
        			int flag2=0;
        			while(k!=null) {
        				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
        					flag2=1;
        					break;
        				}
        				k=k.next;
        			}
        			if(flag1==1 && flag2==1) {
            			s1=p.id;
            			s2=r.id;
            			PO m=proot2;
            			PO n=m;
            			
            			int found=0;
            			while(m!=null) {
            				if((m.id1.compareTo(s1))==0 && (m.id2.compareTo(s2))==0) {
            					System.out.println("removing "+p.id+" -> "+r.id+" due to "+p.id+" -> "+q.id+" and "+q.id+" -> "+r.id);
            					m.visited=1;
            					found=1;
            					break;
            				}
            				n=m;
            				m=m.next;
            			}
            			/*if(found==1) {
            				if(m==proot2) {
            					if(m.next!=null) {
            						m=m.next;
            						proot2=m;
            					}
            					else
            						proot2=null;
            				}
            				else if(m.next==null) {
            					n.next=null;
            				}
            				else {
            					m=m.next;
            					n.next=m;
            				}
            			}*/
        		}
        	
        			
        		}
        	}
        }
        PO p=proot2;
        int flag=1;
        while(flag==1) {
        	flag=0;
        	PO m=proot2;
    		PO n=m;
    		int found=0;
    		while(m!=null) {
    			if(m.visited==1) {
    				found=1;
    				break;
    			}
    			n=m;
    			m=m.next;
    		}
    		//System.out.println("Found "+m.id1+" -> "+m.id2);
    		if(found==1) {
    			if(m==proot2) {
    				if(m.next!=null) {
    					m=m.next;
    					proot2=m;
    				}
    				else
    					proot2=null;
    			}
    			else if(m.next==null) {
    				n.next=null;
    			}
    			else {
    				m=m.next;
    				n.next=m;
    			}
    		}
        	PO g=proot2;
        	while(g!=null) {
        		if(g.visited==1)
        			flag=1;
        		g=g.next;
        	}
        }
        }
    public static void exist_path() {
    	 PO remove=null;
    	   	PO k=proot;
    	   	int count=0;
    	   	while(k!=null) {
    	   		count++;
    	   		System.out.println("Edge:  "+k.id1+" -> "+k.id2);
    	   		k=k.next;
    	   	}
    	   	System.out.println("Number of edges are : "+count);
    	   	Node q=FR;
    	   	int V=0;
    	   	while(q!=null) {
    	   		V++;
    	   		q=q.next;
    	   	}
    		System.out.println("Number of FRs are : "+V);
    	   	PO p=proot;
    	   	int [][] edges;
    	   	while(p!=null) {
    	   		String s1=p.id1;
    	   		String s2=p.id2;
    	   	 Scanner ins = new Scanner(p.id1).useDelimiter("[^0-9]+");
    	        int i1 = ins.nextInt();
    	        Scanner ins2 = new Scanner(p.id2).useDelimiter("[^0-9]+");
    	        int i2 = ins2.nextInt();
    	   		System.out.println("checking for "+s1+" -> "+s2);
    	   		edges=new int[count][2];
    	   		int j=0;
    	   		k=proot;
    	   		int m=0;
    	   		while(m<count) {
    	   			if(k!=null) {
    	   			for(int n=0;n<2;n++) {
    	   				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
    	   				}else {
    	   					//System.out.println("adding "+k.id1+" -> "+k.id2);
    	   					 Scanner in = new Scanner(k.id1).useDelimiter("[^0-9]+");
    	   			            int integer = in.nextInt();
    	   			            Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
    	   			            int integer2 = in2.nextInt();
    	   			            //System.out.println("the integer form "+integer+" -> "+integer2);
    	   			            edges[m][n]=integer;
    	   			            n++;
    	   			            edges[m][n]=integer2;
    	   			            m++;
    	   				}
    	   			}
    	   			k=k.next;
    	   		}
    	   			else
    	   				break;
    	   			
    	   		}
    	   		//System.out.println("the passed edges are:");

    	   		for(m=0;m<count;m++) {
    	   			
    	   				//System.out.println(edges[m][0]+" -> "+edges[m][1]);
    	   			
    	   		}
    	   		 if (existPath(V, edges, i1, i2,count)) {
    	   			 System.out.print("Yes\n");
    	   			 PO temp=new PO();
    	   			 temp.id1=s1;
    	   			 temp.id2=s2;
    	   			 if(remove==null)
    	   				 remove=temp;
    	   			 else {
    	   				 PO t=remove;
    	   				 while(t.next!=null)
    	   					 t=t.next;
    	   				 t.next=temp;
    	   			 }
    	   		 }
    	   		       
    	   		    else
    	   		        System.out.print("No\n");
    	           
    	   		p=p.next;
    	   	}
    	   //	System.out.println("The extras are: ");
    	   	PO t=remove;
    	   	while(t!=null) {
    	   		PO j=proot;
    	   		PO s=j;
    	   		while(j!=null) {
    	   			if((j.id1.compareTo(t.id1))==0 && (j.id2.compareTo(t.id2))==0) {
    	   				break;
    	   			}
    	   			s=j;
    	   			j=j.next;
    	   		}
    	   		
    	   		if(j==proot) {
    				if(j.next!=null) {
    					j=j.next;
    					proot=j;
    				}
    				else
    					proot=null;
    			}
    			else if(j.next==null) {
    				s.next=null;
    			}
    			else {
    				j=j.next;
    				s.next=j;
    			}
    	   		
    	   		t=t.next;
    	   	}
    	    
    	       /* PO p = proot2;
    	        System.out.println("The partial order is :");
    	        while (p != null) {
    	            System.out.println(String.valueOf(p.id1) + "->" + p.id2);
    	            p = p.next;
    	        }*/

    }
   public static void Reexist_path() {
	   PO remove=null;
   	PO k=proot2;
   	int count=0;
   	while(k!=null) {
   		count++;
   		//System.out.println("Edge:  "+k.id1+" -> "+k.id2);
   		k=k.next;
   	}
   	System.out.println("Number of edges are : "+count);
   	Node q=FR;
   	int V=0;
   	while(q!=null) {
   		V++;
   		q=q.next;
   	}
	System.out.println("Number of FRs are : "+V);
   	PO p=proot2;
   	int [][] edges;
   	while(p!=null) {
   		String s1=p.id1;
   		String s2=p.id2;
   	 Scanner ins = new Scanner(p.id1).useDelimiter("[^0-9]+");
        int i1 = ins.nextInt();
        Scanner ins2 = new Scanner(p.id2).useDelimiter("[^0-9]+");
        int i2 = ins2.nextInt();
   		System.out.println("checking for "+s1+" -> "+s2);
   		edges=new int[count][2];
   		int j=0;
   		k=proot2;
   		int m=0;
   		while(m<count) {
   			if(k!=null) {
   			for(int n=0;n<2;n++) {
   				if((k.id1.compareTo(s1))==0 && (k.id2.compareTo(s2))==0) {
   				}else {
   					//System.out.println("adding "+k.id1+" -> "+k.id2);
   					 Scanner in = new Scanner(k.id1).useDelimiter("[^0-9]+");
   			            int integer = in.nextInt();
   			            Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
   			            int integer2 = in2.nextInt();
   			            //System.out.println("the integer form "+integer+" -> "+integer2);
   			            edges[m][n]=integer;
   			            n++;
   			            edges[m][n]=integer2;
   			            m++;
   				}
   			}
   			k=k.next;
   		}
   			else
   				break;
   			
   		}
   		//System.out.println("the passed edges are:");

   		for(m=0;m<count;m++) {
   			
   				//System.out.println(edges[m][0]+" -> "+edges[m][1]);
   			
   		}
   		 if (existPath(V, edges, i1, i2,count)) {
   			 System.out.print("Yes\n");
   			 PO temp=new PO();
   			 temp.id1=s1;
   			 temp.id2=s2;
   			 if(remove==null)
   				 remove=temp;
   			 else {
   				 PO t=remove;
   				 while(t.next!=null)
   					 t=t.next;
   				 t.next=temp;
   			 }
   		 }
   		       
   		    else
   		        System.out.print("No\n");
           
   		p=p.next;
   	}
   //	System.out.println("The extras are: ");
   	PO t=remove;
   	while(t!=null) {
   		PO j=proot2;
   		PO s=j;
   		while(j!=null) {
   			if((j.id1.compareTo(t.id1))==0 && (j.id2.compareTo(t.id2))==0) {
   				break;
   			}
   			s=j;
   			j=j.next;
   		}
   		
   		if(j==proot2) {
			if(j.next!=null) {
				j=j.next;
				proot2=j;
			}
			else
				proot2=null;
		}
		else if(j.next==null) {
			s.next=null;
		}
		else {
			j=j.next;
			s.next=j;
		}
   		
   		t=t.next;
   	}
    
       /* PO p = proot2;
        System.out.println("The partial order is :");
        while (p != null) {
            System.out.println(String.valueOf(p.id1) + "->" + p.id2);
            p = p.next;
        }*/
    }
    public static void obtain_source() {
    	source=null;
    	Node k=FR2;
    	while(k!=null) {
    		if((k.id.compareTo("fb"))!=0) {
    		String s=k.id;
    		int exists=0;
    		int found=0;
    		PO p=proot2;
    		while(p!=null) {
    			if((p.id2.compareTo(s))==0)
    			{
    				exists=1;
    				break;
    			}
    			if((p.id1.compareTo(s))==0)
    				found=1;
    			p=p.next;
    		}
    		if(exists==0) {
    			if(found==1) {
    			System.out.println("Source="+k.id);
    			Node temp=new Node();
    			temp.id=s;
    			temp.next=null;
    			if(source==null)
    				source=temp;
    			else {
    				Node j=source;
    				while(j.next!=null)
    					j=j.next;
    				j.next=temp;
    			}
    			}
    			else if(found==0) {
    				System.out.println("Source="+k.id);
        			Node temp=new Node();
        			temp.id=s;
        			temp.next=null;
        			if(source==null)
        				source=temp;
        			else {
        				Node j=source;
        				while(j.next!=null)
        					j=j.next;
        				j.next=temp;
        			}
    			}
    		}
    	
    	}
    		k=k.next;
    }
    	Node j=source;
    	System.out.println("the source vertices are");
    	while(j!=null) {
    		System.out.println(j.id);
    		j=j.next;
    	}
    }
    public static void find_sink() {
    	sink=null;
    	Node p=Fro;
    	while(p!=null) {
    		System.out.println("The Frozen is:"+p.id);
    		int found=0;
    		int exists=0;
    		PO k=proot3;
    		while(k!=null) {
    			if((k.id1.compareTo(p.id))==0)
    				found=1;
    			if((k.id1.compareTo(p.id))==0 || (k.id2.compareTo(p.id))==0)
    				exists=1;
    			k=k.next;
    		}
    		System.out.println("The exists and found value are:"+exists+" "+found);
    		if(found==0) {
    			if(exists==1) {
    				Node temp=new Node();
    				temp.id=p.id;
    				temp.next=null;
    				if(sink==null)
    					sink=temp;
    				else {
    					Node j=sink;
    					while(j.next!=null)
    						j=j.next;
    					j.next=temp;
    				}
    			}
    			else if(exists==0) {
    				Node temp=new Node();
    				temp.id=p.id;
    				temp.next=null;
    				if(sink==null)
    					sink=temp;
    				else {
    					Node j=sink;
    					while(j.next!=null)
    						j=j.next;
    					j.next=temp;
    				}
    			}
    		}
    		p=p.next;
    	}
    PO h=proot3;
    if(h==null) {
    	p=Fro;
    	while(p!=null) {
    		Node temp=new Node();
			temp.id=p.id;
			temp.next=null;
			if(sink==null)
				sink=temp;
			else {
				Node j=sink;
				while(j.next!=null)
					j=j.next;
				j.next=temp;
			}
    		p=p.next;
    	}
    }
    	System.out.println("the sink vertices are");
    	Node g=sink;
    	while(g!=null) {
    		System.out.println(g.id);
    		g=g.next;
    	}
    }
    public static void set_data() {
    	loaddata=1;
    	FileReader f1=null;
    	E_FN=null;
    	E_NN=null;
    	E_FF=null;
    	FR=null;
    	NFR=null;
    	try {
    		f1=new FileReader("count.txt");
    		int i;
    		char c;
    		String temp="";
    		while((i=f1.read())!=-1) {
    			if(i>=48 && i<=57) {
    				c=(char)i;
    				temp=temp.concat(Character.toString(c));
    			}
    		}
    		iteration=Integer.valueOf(temp);
    		ita.setText(temp);
    	
    		//Obtaining the last Risk value
    		f1=new FileReader("TotalRisk.txt");
    		temp="";
    		while((i=f1.read())!=-1) {
    			if((i>=48 && i<=57) || (i==46)) {
    				c=(char)i;
    				temp=temp.concat(Character.toString(c));
    			}
    		}
    		RiskExp=Double.parseDouble(temp);
    		System.out.println("total risk is "+RiskExp);
    			prevFro=null;
    			//addFrozen.setEnabled(true);
    			//delFrozen.setEnabled(true);
    			//frofr.setEnabled(true);
    		 	 //generate2.setEnabled(true);
            	 //viewgraph2.setEnabled(true);
            	 //risk.setEnabled(true);
    			f1=new FileReader("FroFR.txt");
    			temp="";
    			while((i=f1.read())!=-1) {
    				temp="";
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57)) {
    					c=(char)i;
        				
        				temp=temp.concat(Character.toString(c));
    					
    				}
    				while((i=f1.read())!=10)
    				{
    					if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57)) {
        					c=(char)i;
            				//System.out.println("temp is"+temp);
            				temp=temp.concat(Character.toString(c));
        					
        				}
    				}
    				System.out.println("temp is"+temp);
    				
    					Node t=new Node();
    					t.id=temp;
    					t.next=null;
    					if(prevFro==null)
    						prevFro=t;
    					else {
    						Node j=prevFro;
    						while(j.next!=null)
    							j=j.next;
    						j.next=t;
    					}
    					temp="";
        			}
    			System.out.println("finished reading frozen");
        		System.out.println("the frozen list is");
        		Node k=prevFro;
        		while(k!=null)
        		{
        			System.out.println(k.id);
        			k=k.next;
        		}
    		
    			
    	}catch(Exception v) {
    		
    	}
    	
    	//Recording the Vedges
    	
    	try {
    		VprevEdges=null;
        	f1=new FileReader("VEdges.txt");
        	int i;
        	char c;
        	String temp;
        	String fe1,fe2,fe3;
        	while((i=f1.read())!=-1) {
        		
        		c=(char)i;
        		//System.out.println("C="+c);
        		temp="";
        		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
        			temp=temp.concat(Character.toString(c));
        		//First Vertex
        		while((i=f1.read())!=32) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
        		System.out.println("Temp1 = "+temp);
        		fe1=temp;
        		temp="";
        		
        		//Second vertex
        		while((i=f1.read())!=10) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
        		System.out.println("Temp2 = "+temp);
        		fe2=temp;
        		temp="";
        		PO t=VprevEdges;
        		PO node=new PO();
        		node.id1=fe1;
        		node.id2=fe2;
        		node.next=null;
        		if(t==null) {
        			VprevEdges=node;
        			System.out.println("Insertion 1");
        		}
        		else {
        			PO t2=VprevEdges;
        			while(t2.next!=null)
        				t2=t2.next;
        			t2.next=node;
        			System.out.println("Insertion 2");
        		}
        	}
        	f1.close();
        	
        	System.out.println("The VEdges are");
        	PO h=VprevEdges;
        	while(h!=null) {
        		System.out.println(h.id1+" -> "+h.id2);
        		h=h.next;
        	}
        	}
        	catch(IOException u) {
        		
        	}
    	  
    	//Creating the flist used for unfreezing
    	
    			
    	try {
    		flist=null;
        	f1=new FileReader("VNodes.txt");
        	int i;
        	char c;
        	String temp;
        	String fe1,fe2,fe3;
        	int num=0;
        	while((i=f1.read())!=-1) {
        		plist node=new plist();
        		c=(char)i;
        		//System.out.println("C="+c);
        		temp="";
        		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
        			temp=temp.concat(Character.toString(c));
        		//First Vertex
        		while((i=f1.read())!=32) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
        		//System.out.println("Temp= "+temp);
        		node.name= Integer.valueOf(temp);
        		node.begin=null;
        		temp="";
        		
        		//Second vertex
        		while((i=f1.read())!=10) {
        			if(i==13)
        				break;
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    				while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        			}
    				//System.out.println("Temp= "+temp);
    				fe1=temp;
    				temp="";
    				while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        			}
    				//System.out.println("Temp= "+temp);
    				fe2=temp;
    				temp="";
    				sNode l1=new sNode();
    				l1.id=fe1;
    				l1.visited=Integer.valueOf(fe2);
    				l1.flag=0;
    				if(node.begin==null)
    					node.begin=l1;
    				else {
    					sNode r=node.begin;
    					while(r.next!=null)
    						r=r.next;
    					r.next=l1;
    				}
    			}
        		if(i==13)
    				i=f1.read();
        		//System.out.println("end of inner while!");
        		if(flist==null)
        			flist=node;
        		else {
        			plist f=flist;
        			while(f.next!=null)
        				f=f.next;
        			f.next=node;
        		}
        	
        	}
        	f1.close();
        	System.out.println("The flist is: ");
        	plist p=flist;
        	while(p!=null) {
        		System.out.print(p.name+" : ");
        		sNode r=p.begin;
        		while(r!=null) {
        			System.out.print(r.id+" ");
        			r=r.next;
        		}
        		System.out.println();
        		p=p.next;
        	}
        	
        	}
        	catch(IOException i) {
        		
        	}
    	
    	try {
    	f1=new FileReader("Dependency.txt");
    	int i;
    	char c;
    	String temp;
    	String fe1,fe2,fe3;
    	while((i=f1.read())!=-1) {
    		
    		c=(char)i;
    		System.out.println("C="+c);
    		temp="";
    		if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    			temp=temp.concat(Character.toString(c));
    		while((i=f1.read())!=10 && i != 10 && i != 13 && i!=-1) {
    			c=(char)i;
    			if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    				temp=temp.concat(Character.toString(c));
    			while((i=f1.read())!=32) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
    			fe1=temp;
    		
    			
    			
    			temp="";
    			while((i=f1.read())!=32) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) || (i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
    			fe2=temp;
    			System.out.println("fe2="+fe2);
    			temp="";
    			while((i=f1.read())!=32) {
    				c=(char)i;
    				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
    					temp=temp.concat(Character.toString(c));
    			}
    			
    			fe3=temp;
    			System.out.println("fe3="+fe3);
    			temp="";
    			System.out.println("Fetched is");
    			System.out.println(fe1+" | "+fe2+" | "+fe3);
    		
				Edge1 dep=new Edge1();
				dep.id1=fe1;
				dep.id2=fe2;
				dep.value=Integer.valueOf(fe3);
				dep.next=null;
				if(E_FN==null)
					E_FN=dep;
				else {
					Edge1 s=E_FN;
					while(s.next!=null)
						s=s.next;
					s.next=dep;
				}
    		}
    	}
    	f1.close();
    	}
    	catch(IOException i) {
    		
    	}
    	try {
        	f1=new FileReader("Conflict.txt");
        	int i;
        	char c;
        	String temp;
        	String fe1,fe2,fe3;
        	while((i=f1.read())!=-1) {
        		
        		c=(char)i;
        		System.out.println("C="+c);
        		temp="";
        		if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        			temp=temp.concat(Character.toString(c));
        		while((i=f1.read())!=10 && i != 10 && i != 13 && i!=-1) {
        			c=(char)i;
        			if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        				temp=temp.concat(Character.toString(c));
        			while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        			}
        			fe1=temp;
        			temp="";
        			while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        			}
        			fe2=temp;
        			temp="";
        			while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        			}
        			fe3=temp;
        			System.out.println("Fetched is");
        			System.out.println(fe1+" | "+fe2+" | "+fe3);
        			Edge1 dep=new Edge1();
    				dep.id1=fe1;
    				dep.id2=fe2;
    				dep.value=Integer.valueOf(fe3);
    				dep.next=null;
    				if(E_NN==null)
    					E_NN=dep;
    				else {
    					Edge1 s=E_NN;
    					while(s.next!=null)
    						s=s.next;
    					s.next=dep;
    				}
        		}
        	}
        	f1.close();
        	}
        	catch(IOException i) {
        		
        	}
    	try {
        	f1=new FileReader("Temporal.txt");
        	int i;
        	char c;
        	String temp;
        	String fe1,fe2,fe3;
        	while((i=f1.read())!=-1) {
        		
        		c=(char)i;
        		System.out.println("C="+c);
        		temp="";
        		if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        			temp=temp.concat(Character.toString(c));
        		System.out.println("i="+i);
        		while((i=f1.read())!=10 && i != 10 && i != 13 && i!=-1) {
        			c=(char)i;
        			if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        				temp=temp.concat(Character.toString(c));
        			System.out.println("i="+i);
        			while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        				System.out.println("i="+i);
        			}
        			fe1=temp;
        			temp="";
        			while((i=f1.read())!=32) {
        				c=(char)i;
        				if((i>=65 && i<=90) || (i>=97 && i<=122) ||(i>=48 && i<=57))
        					temp=temp.concat(Character.toString(c));
        				System.out.println("i="+i);
        			}
        			fe2=temp;
        			System.out.println("Fetched is");
        			System.out.println(fe1+" | "+fe2);
        			Edge2 dep=new Edge2();
    				dep.id1=fe1;
    				dep.id2=fe2;
    		
    				dep.next=null;
    				if(E_FF==null)
    					E_FF=dep;
    				else {
    					Edge2 s=E_FF;
    					while(s.next!=null)
    						s=s.next;
    					s.next=dep;
    				}
        	}
        	}	
        	f1.close();
        	}
    	
        	catch(IOException i) {
        		
        	}
    	try {
        	f1=new FileReader("FR.txt");
        	int i;
        	char c;
        	String temp="";
        	String fe1;
        	while((i=f1.read())!=-1) {
        		c=(char)i;
        		temp=temp.concat(Character.toString(c));
        		while((i=f1.read())!=10)
        		{
        			c=(char)i;
        			if(i!=13)
        				temp=temp.concat(Character.toString(c));
        		}
        		countfr++;
        		Node n=new Node();
        		n.id=temp;
        		n.next=null;
        		if(FR==null)
        			FR=n;
        		else {
        			Node h=FR;
        			while(h.next!=null)
        				h=h.next;
        			h.next=n;
        		}
        		temp="";
        	}
        	f1.close();
    	}catch(IOException i) {
    		
    	}
    	try {
        	f1=new FileReader("NFR.txt");
        	int i;
        	char c;
        	String temp="";
        	String fe1;
        	while((i=f1.read())!=-1) {
        		c=(char)i;
        		temp=temp.concat(Character.toString(c));
        		while((i=f1.read())!=32)
        		{
        			c=(char)i;
        			if(i!=13)
        				temp=temp.concat(Character.toString(c));
        		}
        		while((i=f1.read())!=10) {
        			
        		}
        		countnfr++;
        		Node n=new Node();
        		n.id=temp;
        		n.next=null;
        		if(NFR==null)
        			NFR=n;
        		else {
        			Node h=NFR;
        			while(h.next!=null)
        				h=h.next;
        			h.next=n;
        		}
        		temp="";
        	}
        	f1.close();
    	}catch(IOException i) {
    		
    	}
    	Edge1 v=E_FN;
    	while(v!=null)
    	{
    		System.out.println(v.id1+" -> "+v.id2);
    		v=v.next;
    	}
    }
    public static void delete_dep() {
    	String s1=fr2.getSelectedItem().toString();
  		String s3=nfr1.getSelectedItem().toString();
		//String s4=depvalue1.getSelectedItem().toString();
		if((s1.compareTo(""))!=0 && (s3.compareTo(""))!=0) {
			DefaultTableModel model = (DefaultTableModel)Req.getModel();
			int num=Req.getRowCount();
			int exists=0;
			for(int j=0;j<num;j++) {
				String t1=Req.getValueAt(j, 0).toString();
				String t2=Req.getValueAt(j, 1).toString();
				if((t1.compareTo(s1))==0 && (t2.compareTo(s3))==0) {
					exists=1;
					model.removeRow(j);
				}
			}
			if(exists==0) {
				JOptionPane.showMessageDialog(firstFrame,"Does not exists"); 
			}

		}
		else {
			JOptionPane.showMessageDialog(firstFrame,"Select both FR and NFR");  
			
		}
		fr2.setSelectedItem("");
		nfr1.setSelectedItem("");
    }
    public static void delete_conflict() {
    	String s1=nfr2.getSelectedItem().toString();
  		String s3=nfr3.getSelectedItem().toString();
		//String s4=depvalue1.getSelectedItem().toString();
		if((s1.compareTo(""))!=0 && (s3.compareTo(""))!=0) {
			DefaultTableModel model = (DefaultTableModel)Reqconflict.getModel();
			int num=Reqconflict.getRowCount();
			int exists=0;
			for(int j=0;j<num;j++) {
				String t1=Reqconflict.getValueAt(j, 0).toString();
				String t2=Reqconflict.getValueAt(j, 1).toString();
				if(((t1.compareTo(s1))==0 && (t2.compareTo(s3))==0)|| ((t1.compareTo(s3))==0 && (t2.compareTo(s1))==0)) {
					exists=1;
					model.removeRow(j);
				}
			}
				if(exists==0){
				JOptionPane.showMessageDialog(firstFrame,"Does not exists");  
			}

		}
		else {
			JOptionPane.showMessageDialog(firstFrame,"Select both NFRs");  
			
		}
		nfr2.setSelectedItem("");
		nfr3.setSelectedItem("");
    }
    public static void delete_temporal() {
    	String s1=fr4.getSelectedItem().toString();
  		String s3=fr5.getSelectedItem().toString();
		//String s4=depvalue1.getSelectedItem().toString();
		if((s1.compareTo(""))!=0 && (s3.compareTo(""))!=0) {
			DefaultTableModel model = (DefaultTableModel)Reqtemporal.getModel();
			int num=Reqtemporal.getRowCount();
			int exists=0;
			for(int j=0;j<num;j++) {
				System.out.println("iterating");
				String t1=Reqtemporal.getValueAt(j, 0).toString();
				String t2=Reqtemporal.getValueAt(j, 1).toString();
				if((t1.compareTo(s1))==0 && (t2.compareTo(s3))==0) {
					System.out.println("Found Match1 ");
					exists=1;
					model.removeRow(j);
				}
				//fr4.removeItem(s1);
			}
			if(exists==0) {
				JOptionPane.showMessageDialog(firstFrame,"Does not exists"); 
			}
		}
		else {
			JOptionPane.showMessageDialog(firstFrame,"Select both FRs");  
			
		}
		fr4.setSelectedItem("");
		fr5.setSelectedItem("");
    }
    //Module to save data before PO generation
public static void save_data() {
	E_FN=null;
	E_NN=null;
	FR=null;
	NFR=null;
	E_FF=null;
	int num;
	
	//Storing Dependency relation
    for(int i=0;i<=countfr;i++) {
    	for (int j=countfr+1;j<=countfr+countnfr;j++) {
    	if(frnfr.getValueAt(i, j)==null) {
    		//Do nothing
    	}
    	else {
    		String s1=String.valueOf(frnfr.getValueAt(i, 0));
    		String s3=String.valueOf(frnfr.getColumnName(j));
    		Edge1 temp=new Edge1();
    		temp.id1=s1;
    		temp.id2=s3;
    		temp.value=Integer.valueOf(String.valueOf(frnfr.getValueAt(i, j)));
    		if(E_FN==null)
    		{
    			E_FN=temp;
    		}
    		else {
    			Edge1 p=E_FN;
    			while(p.next!=null) {
    				p=p.next;
    			}
    			p.next=temp;
    		}
    	}
	
		}
	}
	
	System.out.println("Contents of E_FN:");
	Edge1 h=E_FN;
	while(h!=null) {
		System.out.println(h.id1+" | "+h.id2+" | "+h.value);
		h=h.next;
	}
	for(int i=countfr;i<countfr+countnfr;i++) {
    	for (int j=countfr+1;j<=countfr+countnfr;j++) {
    		if(frnfr.getValueAt(i, j)==null) {
        		//Do nothing
        	}
        	else {
        		String s1=String.valueOf(frnfr.getValueAt(i, 0));
        		String s3=String.valueOf(frnfr.getColumnName(j));
        		Edge1 temp=new Edge1();
        		temp.id1=s1;
        		temp.id2=s3;
        		temp.value=Integer.valueOf(String.valueOf(frnfr.getValueAt(i, j)));
        		
        		if(E_NN==null)
        		{
        			E_NN=temp;
        		}
        		else {
        			Edge1 p=E_NN;
        			//Check if already entered
        			int flag=0;
        			while(p.next!=null) {
        			if((p.id1.compareTo(s3))==0 && (p.id2.compareTo(s1))==0)
        				flag=1;
        				p=p.next;
        			}
        			if((p.id1.compareTo(s3))==0 && (p.id2.compareTo(s1))==0)
        				flag=1;
        			if(flag==0)
        				p.next=temp;
        		}
    		
    	}
	}
}
	
		System.out.println("Contents of E_NN:");
		h=E_NN;
		while(h!=null) {
			System.out.println(h.id1+" | "+h.id2+" | "+h.value);
			h=h.next;
		}
		for(int i=0;i<countfr;i++) {
	    	for (int j=1;j<=countfr;j++) {
	    	if(frnfr.getValueAt(i, j)==null) {
	    		//Do nothing
	    	}
	    	else {
	    	String s=String.valueOf(frnfr.getValueAt(i, j));
	    	if((s.compareTo(""))!=0) {
	    	int n=Integer.valueOf(s);
	    	if(n==1) {
	    		String s1=String.valueOf(frnfr.getValueAt(i, 0));
	    		String s3=String.valueOf(frnfr.getColumnName(j));
	    		Edge2 temp=new Edge2();
				temp.id1=s1;
				temp.id2=s3;
				if(E_FF==null)
				{
					E_FF=temp;
				}
				else {
					Edge2 p=E_FF;
					while(p.next!=null) {
						p=p.next;
					}
					p.next=temp;
				}
	    	}
	    	}
	    	}
			}
		}
		
		System.out.println("Contents of E_FF:");
		Edge2 h2=E_FF;
		while(h2!=null) {
			System.out.println(h2.id1+" | "+h2.id2);
			h2=h2.next;
		}
	for(int i=1;i<=countfr;i++) {
		Node temp=new Node();
		temp.id="f"+i;
		temp.next=null;
		if(FR==null)
			FR=temp;
		else {
			Node k=FR;
			while(k.next!=null)
				k=k.next;
			k.next=temp;
		}
	}
	for(int i=1;i<=countnfr;i++) {
		Node temp=new Node();
		temp.id="nf"+i;
		temp.next=null;
		if(NFR==null)
			NFR=temp;
		else {
			Node k=NFR;
			while(k.next!=null)
				k=k.next;
			k.next=temp;
		}
	}
	System.out.println("The FRs are:");
    	Node k=FR;
    	while(k!=null) {
    		System.out.println(k.id);
    		k=k.next;
    	}
    	System.out.println("The NFRs are:");
    	Node m=NFR;
    	while(m!=null) {
    		System.out.println(m.id);
    		m=m.next;
    	}
    	
    	   
}
//Storing temporal relation
    public static void Set_newTemporal() {
    	String s1=fr4.getSelectedItem().toString();
    	String s2=fr5.getSelectedItem().toString();
    	if((s1.compareTo(""))!=0 && (s2.compareTo(""))!=0) {
    		if((s1.compareTo(s2))==0) {
    			JOptionPane.showMessageDialog(firstFrame,"Dependee and depender FR cannot be same");
    		}
    		else {
    			DefaultTableModel model = (DefaultTableModel)Reqtemporal.getModel();
				Object []o = new Object[2];
				o[0]=s1;
				o[1]=s2;
				newtemp++;
				model.addRow(o);			
    		}
    	}
    	else {
    		JOptionPane.showMessageDialog(firstFrame,"Select both the FRs");
    	}
    	
    	fr4.setSelectedItem("");
    	fr5.setSelectedItem("");
    }
    
    //Saving the NFR priorities provided
    public static void setPriority() {
        int flag = 0;
        int num=NFR_priority.getRowCount();
        for (int i = 0; i < num; ++i) {
        	String s=NFR_priority.getValueAt(i, 1).toString();
            if ((s.compareTo(""))==0) {
                JOptionPane.showMessageDialog(frame1, "Enter all priority values");
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
        	
            int i=0;
            while(i<num) {
            	String s1=NFR_priority.getValueAt(i, 0).toString();
            	String s2=NFR_priority.getValueAt(i, 1).toString();
            	int val=Integer.valueOf(s2);
            	System.out.println("The value is "+s2+" | "+val);
            	Node k=NFR;
            	while(k!=null) {
            		if((k.id.compareTo(s1))==0)
            		{
            			k.priority=val;
            			break;
            		}
            		k=k.next;
            	}
            	i++;
            }
        }
        System.out.println("The priority values are");
        Node h=NFR;
        while(h!=null) {
        	System.out.println(h.id+" | "+h.priority);
        	h=h.next;
        }
    }
    //Setting the parameter
    public static void setChoice() {
        if (conflict.isSelected()) {
            choice = 1;
        }
        else if (priority.isSelected()) {
            choice = 2;
        }
        else if (both.isSelected()) {
            choice = 3;
        }
        else if (both2.isSelected()) {
            w1 = slider1.getValue() / 10.0;
            w2 = 1.0 - w1;
            choice = 4;
        }
        else if (nc.isSelected()) {
            choice = 5;
        }
        else {
            JOptionPane.showMessageDialog(frame1, "Select a parameter");
        }
    }
    //Writing optimal partial order sequence in the interface
    public static void setOrderInFrame() {
        if (choice == 1) {
            textOrder1.append("\n Conflict (Optimal PO)");
            textOrder1.append("\n");
        }
        else if (choice == 2) {
            textOrder1.append("\n NFR Priority (Optimal PO)");
            textOrder1.append("\n");
        }
        else if (choice == 3) {
            textOrder1.append("\n Product (Optimal PO)");
            textOrder1.append("\n");
        }
        else if (choice == 4) {
            textOrder1.append("\n Weighted Sum (Optimal PO)");
            textOrder1.append("\n");
        }
        else if (choice == 5) {
            textOrder1.append("\n Without considering NFR conflict");
            textOrder1.append("\n");
        }
        plist m = rootOp;
        while (m != null) {
            for (sNode n = m.begin; n != null; n = n.next) {
                String temp;
                if (n.next != null) {
                    temp = String.valueOf(n.id) + "->";
                }
                else {
                    temp = n.id;
                }
                textOrder1.append(temp);
            }
            m = m.next;
            textOrder1.append("\n");
        }
    }
    //Writing alternate partial order sequence in the interface
    public static void setOrderInFrameFro() {
        if (choice == 1) {
            textOrder2.append("\n Conflict (Alternate PO)");
            textOrder2.append("\n");
        }
        else if (choice == 2) {
            textOrder2.append("\n NFR Priority (Alternate PO)");
            textOrder2.append("\n");
        }
        else if (choice == 3) {
            textOrder2.append("\n Product (Alternate PO)");
            textOrder2.append("\n");
        }
        else if (choice == 4) {
            textOrder2.append("\n Weighted Sum (Alternate PO)");
            textOrder2.append("\n");
        }
        else if (choice == 5) {
            textOrder2.append("\n Without considering NFR conflict");
            textOrder2.append("\n");
        }
        plist m = rootFRo;
        while (m != null) {
            for (sNode n = m.begin; n != null; n = n.next) {
                String temp;
                if (n.next != null) {
                    temp = String.valueOf(n.id) + "->";
                }
                else {
                    temp = n.id;
                }
                textOrder2.append(temp);
            }
            m = m.next;
            textOrder2.append("\n");
        }
    }
    
    //Generating graph for optimal partial order
    public static void drawGraph() {
    	Reremove_transitive();
    	Node p=FR;
    	System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
    	 Graph graph=new MultiGraph("");
    	if(choice==1) {
    		 graph = new MultiGraph("Optimal Partial Order || Parameter: NFR Conflict");
        	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: NFR Conflict");
    	}
    	else if(choice==2) {
    		graph = new MultiGraph("Optimal Partial Order || Parameter: NFR Priority");
        	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: NFR Priority");	
    	}
    	else if(choice==3) {
    		graph = new MultiGraph("Optimal Partial Order || Parameter: Product");
        	graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: Product");
    	}
    	else if(choice==4) {
    	graph = new MultiGraph("Optimal Partial Order || Parameter: Weighted Sum");
        graph.setAttribute("ui.title", "Optimal Partial Order || Parameter: Weighted Sum");
    	}
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;text-size: 16;fill-color: yellow;text-mode:normal; text-style: bold; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        
    	while(p!=null) {
    		graph.addNode(p.id);
    		p=p.next;
    	}
    	PO k=proot;
    	while(k!=null) {
    		String ed=k.id1+k.id2;
    		//System.out.println("Edge is"+k.id1+"->"+k.id2);
    		final Edge edge = graph.addEdge(ed, k.id1, k.id2, true);
           edge.addAttribute("layout.weight", 6);


    		k=k.next;
    	}
    	for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
            String s=node.getId();
           // System.out.println("Id is"+s);
          /*  int exists=0;
            Node t=Fro;
            while(t!=null) {
            	if((t.id.compareTo(s))==0) {
            		exists=1;
            		break;
            	}
            	t=t.next;
            }
            if(exists==1)
            	node.addAttribute("ui.style", "fill-color: rgb(0,100,255); text-color: rgb(255,255,255);");
            	//node.addAttribute("ui.style", ");*/
        }
    	Viewer viewer = graph.display();
    
    	 viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
    	
    }

    //Generating graph for alternate partial order
    public static void drawGraphFro(){
    	Reremove_transitive();
    	Node p=FR;
    	System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
    	 Graph graph=new MultiGraph("");
    	if(choice==1) {
    		 graph = new MultiGraph("Alternate Partial Order || Parameter: NFR Conflict");
        	graph.setAttribute("ui.title", "Alternate Partial Order || Parameter: NFR Conflict");
    	}
    	else if(choice==2) {
    		graph = new MultiGraph("Alternate Partial Order || Parameter: NFR Priority");
        	graph.setAttribute("ui.title", "Alternate Partial Order || Parameter: NFR Priority");	
    	}
    	else if(choice==3) {
    		graph = new MultiGraph("Alternate Partial Order || Parameter: Product");
        	graph.setAttribute("ui.title", "Alternate Partial Order || Parameter: Product");
    	}
    	else if(choice==4) {
    	graph = new MultiGraph("Alternate Partial Order || Parameter: Weighted Sum");
        graph.setAttribute("ui.title", "Alternate Partial Order || Parameter: Weighted Sum");
    	}
        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;text-size: 16; fill-color: yellow;text-mode:normal; text-style: bold; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
        
    	while(p!=null) {
    		graph.addNode(p.id);
    		p=p.next;
    	}
    	PO k=proot2;
    	while(k!=null) {
    		String ed=k.id1+k.id2;
    		//System.out.println("Edge is"+k.id1+"->"+k.id2);
    		final Edge edge = graph.addEdge(ed, k.id1, k.id2, true);
           edge.addAttribute("layout.weight", 6);


    		k=k.next;
    	}
    	for (final org.graphstream.graph.Node node : graph) {
            node.addAttribute("ui.label", node.getId());
            node.addAttribute("layout.weight", 150);
            String s=node.getId();
           // System.out.println("Id is"+s);
            int exists=0, exists2=0;
            Node t=Fro;
            while(t!=null) {
            	if((t.id.compareTo(s))==0) {
            		exists=1;
            		break;
            	}
            	t=t.next;
            }
         t=prevFro;
            while(t!=null) {
            	if((t.id.compareTo(s))==0) {
            		exists2=1;
            		break;
            	}
            	t=t.next;
            }
            if(exists==1 && exists2==1)
            	node.addAttribute("ui.style", "fill-color: rgb(102,255,102); text-color: rgb(255,255,255);");
            if(exists==1 && exists2==0)
            	node.addAttribute("ui.style", "fill-color: rgb(0,100,255); text-color: rgb(255,255,255);");
    	}
    	Viewer viewer = graph.display();
    	 viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
       // graph.display();
    }
    //Creating sequence for optimal partial order
    public static void setText() {
    	rootOp=null;
    	//At first find the source vertices
    	Node source2=null;
    	Node k=FR;
    	while(k!=null) {
    		String s=k.id;
    		int exists=0;
    		int found=0;
    		PO p=proot;
    		while(p!=null) {
    			if((p.id2.compareTo(s))==0)
    			{
    				exists=1;
    				break;
    			}
    			if((p.id1.compareTo(s))==0)
    				found=1;
    			p=p.next;
    		}
    		if(exists==0) {
    			if(found==1) {
    			System.out.println("Source="+k.id);
    			Node temp=new Node();
    			temp.id=s;
    			temp.next=null;
    			if(source2==null)
    				source2=temp;
    			else {
    				Node j=source2;
    				while(j.next!=null)
    					j=j.next;
    				j.next=temp;
    			}
    			}
    		}
    	
    	
    		k=k.next;
    }
   //Count outgoing edge from each source
    	Node j=source2;
    	while(j!=null) {
    		String s=j.id;
    		PO m=proot;
    		int c=0;
    		while(m!=null) {
    			if((m.id1.compareTo(s))==0)
    				c++;
    			m=m.next;
    		}
    		j.priority=c;
    		j=j.next;
    	}
    	//Setting visited to 0;
    	PO l=proot;
    	while(l!=null) {
    		l.visited=0;
    		l=l.next;
    	}
    	//creating a duplicate proot list
    	PO pr=null;
    	PO pt=proot;
    	while(pt!=null) {
    		PO temp=new PO();
    		temp.id1=pt.id1;
    		temp.id2=pt.id2;
    		temp.visited=0;
    		temp.next=null;
    		if(pr==null)
    			pr=temp;
    		else {
    			PO v=pr;
    			while(v.next!=null)
    				v=v.next;
    			v.next=temp;
    		}
    		pt=pt.next;
    	}
    	//Creating the sequences
    	//plist root=null;
    	j=source2;
    	int seq=1;
    	while(j!=null) {
    		
    		PO t=proot;
    		plist temp=new plist();
    		while(t!=null) {
    			if((t.id1.compareTo(j.id))==0 && t.visited==0) {
    		
    				temp.name=seq;
    				seq++;
    				temp.next=null;
    				sNode temp2=new sNode();
    				temp2.id=t.id1;
    				temp2.next=null;
    				sNode temp3=new sNode();
    				temp3.id=t.id2;
    				temp3.next=null;
    				temp2.next=temp3;
    				temp.begin=temp2;
    				if(rootOp==null)
    					rootOp=temp;
    				else {
    					plist g=rootOp;
    					while(g.next!=null)
    						g=g.next;
    					g.next=temp;
    				}
    				j.priority--;
    				t.visited=1;
    				PO x=pr;
    				while(x!=null) {
    					if((x.id1.compareTo(t.id1))==0 && (x.id2.compareTo(t.id2))==0)
    						x.visited=1;
    					x=x.next;
    				}
    				break;
    			
    			}
    			t=t.next;
    		}
    		int found=1;
    		while(found==1) {
    			found=0;
    			sNode m=temp.begin;
    			while(m.next!=null)
    				m=m.next;
    			String s=m.id;
    			PO n=proot;
    			while(n!=null) {
    				if((n.id1.compareTo(s))==0 && n.visited==0) {
    					sNode temp4=new sNode();
        				temp4.id=n.id2;
        				temp4.next=null;
        				m.next=temp4;
        				found=1;
        				PO x=pr;
        				while(x!=null) {
        					if((x.id1.compareTo(n.id1))==0 && (x.id2.compareTo(n.id2))==0)
        						x.visited=1;
        					x=x.next;
        				}
        				break;
        				
    				}
    				n=n.next;
    			}
    		}
    		
    		if(j.priority==0)
    		{
    			j=j.next;
    		}
    	}
    	//Creating remaining sequences
    	PO h=pr;
    	plist root2=null;
    	//int prevseq=0;
    	while(h!=null) {
    		
    		if(h.visited==0) {
    	
    			plist v=rootOp;
    			while(v!=null) {
    				plist temp=new plist();
    				temp.name=seq;
        			seq++;
        			temp.begin=null;
    				int found=0;
    				sNode i=v.begin;
    				while(i!=null) {
    					if((i.id.compareTo(h.id1))==0)
    					{
    						System.out.println("Yes Found"+h.id1);
        					sNode wi=v.begin;
        					while((wi.id.compareTo(h.id1))!=0) {
        						sNode temp5=new sNode();
        						temp5.id=wi.id;
        						temp5.next=null;
        						System.out.println("Inserting "+temp5.id);
        						sNode f=temp.begin;
        						if(temp.begin==null)
        							temp.begin=temp5;
        						else {
        							sNode z=temp.begin;
        							while(z.next!=null)
        								z=z.next;
        							z.next=temp5;
        						}
        						wi=wi.next;
        					}
        					
        					break;
    					}
    					i=i.next;
    					
    				}
    				sNode temp1=new sNode();
	    			temp1.id=h.id1;
	    			temp1.next=null;
	    			sNode f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp1;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp1;
					}
	    			sNode temp2=new sNode();
	    			temp2.id=h.id2;
	    			temp2.next=null;
	    			f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp2;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp2;
					}
	    			if(root2==null)
	    				root2=temp;
	    			else
	    			{
	    				plist b=root2;
	    				while(b.next!=null)
	    					b=b.next;
	    				b.next=temp;
	    			}
	    			int ex=1;
	        		while(ex==1) {
	        			ex=0;
	        			sNode m=temp.begin;
	        			while(m.next!=null)
	        				m=m.next;
	        			String s=m.id;
	        			PO n=proot;
	        			while(n!=null) {
	        				if((n.id1.compareTo(s))==0 && n.visited==0) {
	        					sNode temp4=new sNode();
	            				temp4.id=n.id2;
	            				temp4.next=null;
	            				m.next=temp4;
	            				m=m.next;
	            				ex=1;
	            				break;
	            				
	        				}
	        				n=n.next;
	        			}
	        		}
	        		System.out.println("list created");
	        		System.out.println("V id: "+v.name);
    				v=v.next;
    				//break;
    			}
    			System.out.println("Done once");
    		}
    		h=h.next;
    	}
    	//Adding remaining to main list
    	plist q=root2;
    	while(q!=null) {
    		plist temp=new plist();
    		temp.name=q.name;
    		temp.begin=q.begin;
    		if(rootOp==null)
    			rootOp=temp;
    		else {
    			plist x=rootOp;
    			while(x.next!=null)
    				x=x.next;
    			x.next=temp;
    		}
    		q=q.next;
    	}
    	//Checking duplicate sequence
    	plist k2=rootOp;
    	while(k2!=null) {
    		String temp1="";
    		sNode p=k2.begin;
    		while(p!=null) {
    			temp1=temp1.concat(p.id);
    			p=p.next;
    		}
    		plist m=rootOp;
    		int e=0;
    		while(m!=null) {
    			sNode q2=m.begin;
    			String temp2="";
    			while(q2!=null) {
    				temp2=temp2.concat(q2.id);
    				q2=q2.next;
    			}
    			if(temp2.contains(temp1)) {
    				if((temp1.compareTo(temp2))!=0) {
    					k2.name=0;
    				}
    			}
    		m=m.next;	
    		}
    		
    		k2=k2.next;
    	}
    	// Removing duplicate
    	int del=1;
    	while(del==1) {
    		del=0;
    		plist v2=rootOp;
    		plist v3=v2;
    		while(v2!=null) {
    			if(v2.name==0) {
    				del=1;
    				break;
    			}
    				
    			v3=v2;
    			v2=v2.next;
    		}
    		if(del==1) {
    			if(v2==rootOp) {
    				if(v2.next!=null) {
    					v2=v2.next;
    					rootOp=v2;
    				}
    				else
    					rootOp=null;
    			}
    			else if(v2.next==null)
    				v3.next=null;
    			else {
    				v2=v2.next;
    				v3.next=v2;
    			}
    		}
    	}
    	System.out.println("The sequence for Optimal PO");
    	plist c=rootOp;
    	while(c!=null) {
    		
    		System.out.println("The sequence S"+c.name);
		sNode r=c.begin;
		while(r!=null) {
			if(r.next!=null) {
				System.out.print(r.id+" -> ");
			}
			else {
				System.out.print(r.id);
				System.out.println();
			}
			r=r.next;
		}
		c=c.next;
    	}
    }
    
    //Creating sequence for alternate partial order 
    public static void setTextFro() {
    	rootFRo=null;
    	//At first find the source vertices
    	Node source2=null;
    	Node k=FR;
    	while(k!=null) {
    		String s=k.id;
    		int exists=0;
    		int found=0;
    		PO p=proot2;
    		while(p!=null) {
    			if((p.id2.compareTo(s))==0)
    			{
    				exists=1;
    				break;
    			}
    			if((p.id1.compareTo(s))==0)
    				found=1;
    			p=p.next;
    		}
    		if(exists==0) {
    			if(found==1) {
    			System.out.println("Source="+k.id);
    			Node temp=new Node();
    			temp.id=s;
    			temp.next=null;
    			if(source2==null)
    				source2=temp;
    			else {
    				Node j=source2;
    				while(j.next!=null)
    					j=j.next;
    				j.next=temp;
    			}
    			}
    		}
    	
    	
    		k=k.next;
    }
   //Count outgoing edge from each source
    	Node j=source2;
    	while(j!=null) {
    		String s=j.id;
    		PO m=proot2;
    		int c=0;
    		while(m!=null) {
    			if((m.id1.compareTo(s))==0)
    				c++;
    			m=m.next;
    		}
    		j.priority=c;
    		j=j.next;
    	}
    	//Setting visited to 0;
    	PO l=proot2;
    	while(l!=null) {
    		l.visited=0;
    		l=l.next;
    	}
    	//creating a duplicate proot list
    	PO pr=null;
    	PO pt=proot2;
    	while(pt!=null) {
    		PO temp=new PO();
    		temp.id1=pt.id1;
    		temp.id2=pt.id2;
    		temp.visited=0;
    		temp.next=null;
    		if(pr==null)
    			pr=temp;
    		else {
    			PO v=pr;
    			while(v.next!=null)
    				v=v.next;
    			v.next=temp;
    		}
    		pt=pt.next;
    	}
    	//Creating the sequences
    	//plist root=null;
    	j=source2;
    	int seq=1;
    	while(j!=null) {
    		System.out.println("starting with "+j.id);
    		PO t=proot2;
    		plist temp=new plist();
    		while(t!=null) {
    			if((t.id1.compareTo(j.id))==0 && t.visited==0) {
    				System.out.println("Found first");	
    				temp.name=seq;
    				seq++;
    				temp.next=null;
    				sNode temp2=new sNode();
    				temp2.id=t.id1;
    				temp2.next=null;
    				sNode temp3=new sNode();
    				temp3.id=t.id2;
    				temp3.next=null;
    				temp2.next=temp3;
    				temp.begin=temp2;
    				if(rootFRo==null)
    					rootFRo=temp;
    				else {
    					plist g=rootFRo;
    					while(g.next!=null)
    						g=g.next;
    					g.next=temp;
    				}
    				j.priority--;
    				t.visited=1;
    				PO x=pr;
    				while(x!=null) {
    					if((x.id1.compareTo(t.id1))==0 && (x.id2.compareTo(t.id2))==0)
    						x.visited=1;
    					x=x.next;
    				}
    				break;
    			
    			}
    			t=t.next;
    		}
    		int found=1;
    		while(found==1) {
    			found=0;
    			sNode m=temp.begin;
    			while(m.next!=null)
    				m=m.next;
    			String s=m.id;
    			PO n=proot2;
    			while(n!=null) {
    				if((n.id1.compareTo(s))==0 && n.visited==0) {
    					sNode temp4=new sNode();
        				temp4.id=n.id2;
        				temp4.next=null;
        				m.next=temp4;
        				found=1;
        				PO x=pr;
        				while(x!=null) {
        					if((x.id1.compareTo(n.id1))==0 && (x.id2.compareTo(n.id2))==0)
        						x.visited=1;
        					x=x.next;
        				}
        				break;
        				
    				}
    				n=n.next;
    			}
    		}
    		
    		if(j.priority==0)
    		{
    			j=j.next;
    		}
    	}
    	//Creating remaining sequences
    	PO h=pr;
    	plist root2=null;
    	//int prevseq=0;
    	while(h!=null) {
    		
    		if(h.visited==0) {
    	
    			plist v=rootFRo;
    			while(v!=null) {
    				plist temp=new plist();
    				temp.name=seq;
        			seq++;
        			temp.begin=null;
    				int found=0;
    				sNode i=v.begin;
    				while(i!=null) {
    					if((i.id.compareTo(h.id1))==0)
    					{
    						System.out.println("Yes Found"+h.id1);
        					sNode wi=v.begin;
        					while((wi.id.compareTo(h.id1))!=0) {
        						sNode temp5=new sNode();
        						temp5.id=wi.id;
        						temp5.next=null;
        						System.out.println("Inserting "+temp5.id);
        						sNode f=temp.begin;
        						if(temp.begin==null)
        							temp.begin=temp5;
        						else {
        							sNode z=temp.begin;
        							while(z.next!=null)
        								z=z.next;
        							z.next=temp5;
        						}
        						wi=wi.next;
        					}
        					
        					break;
    					}
    					i=i.next;
    					
    				}
    				sNode temp1=new sNode();
	    			temp1.id=h.id1;
	    			temp1.next=null;
	    			sNode f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp1;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp1;
					}
	    			sNode temp2=new sNode();
	    			temp2.id=h.id2;
	    			temp2.next=null;
	    			f=temp.begin;
					if(temp.begin==null)
						temp.begin=temp2;
					else {
						sNode z=temp.begin;
						while(z.next!=null)
							z=z.next;
						z.next=temp2;
					}
	    			if(root2==null)
	    				root2=temp;
	    			else
	    			{
	    				plist b=root2;
	    				while(b.next!=null)
	    					b=b.next;
	    				b.next=temp;
	    			}
	    			int ex=1;
	        		while(ex==1) {
	        			ex=0;
	        			sNode m=temp.begin;
	        			while(m.next!=null)
	        				m=m.next;
	        			String s=m.id;
	        			PO n=proot2;
	        			while(n!=null) {
	        				if((n.id1.compareTo(s))==0 && n.visited==0) {
	        					sNode temp4=new sNode();
	            				temp4.id=n.id2;
	            				temp4.next=null;
	            				m.next=temp4;
	            				m=m.next;
	            				ex=1;
	            				break;
	            				
	        				}
	        				n=n.next;
	        			}
	        		}
	        		System.out.println("list created");
	        		System.out.println("V id: "+v.name);
    				v=v.next;
    				//break;
    			}
    			System.out.println("Done once");
    		}
    		h=h.next;
    	}
    	//Adding remaining to main list
    	plist q=root2;
    	while(q!=null) {
    		plist temp=new plist();
    		temp.name=q.name;
    		temp.begin=q.begin;
    		if(rootFRo==null)
    			rootFRo=temp;
    		else {
    			plist x=rootFRo;
    			while(x.next!=null)
    				x=x.next;
    			x.next=temp;
    		}
    		q=q.next;
    	}
    	//Checking duplicate sequence
    	plist k2=rootFRo;
    	while(k2!=null) {
    		String temp1="";
    		sNode p=k2.begin;
    		while(p!=null) {
    			temp1=temp1.concat(p.id);
    			p=p.next;
    		}
    		plist m=rootFRo;
    		int e=0;
    		while(m!=null) {
    			sNode q2=m.begin;
    			String temp2="";
    			while(q2!=null) {
    				temp2=temp2.concat(q2.id);
    				q2=q2.next;
    			}
    			if(temp2.contains(temp1)) {
    				if((temp1.compareTo(temp2))!=0) {
    					k2.name=0;
    				}
    			}
    		m=m.next;	
    		}
    		
    		k2=k2.next;
    	}
    	// Removing duplicate
    	int del=1;
    	while(del==1) {
    		del=0;
    		plist v2=rootFRo;
    		plist v3=v2;
    		while(v2!=null) {
    			if(v2.name==0) {
    				del=1;
    				break;
    			}
    				
    			v3=v2;
    			v2=v2.next;
    		}
    		if(del==1) {
    			if(v2==rootFRo) {
    				if(v2.next!=null) {
    					v2=v2.next;
    					rootFRo=v2;
    				}
    				else
    					rootFRo=null;
    			}
    			else if(v2.next==null)
    				v3.next=null;
    			else {
    				v2=v2.next;
    				v3.next=v2;
    			}
    		}
    	}
    	System.out.println("The sequence for Alternate PO");
    	plist c=rootFRo;
    	while(c!=null) {
    		
    		System.out.println("The sequence S"+c.name);
		sNode r=c.begin;
		while(r!=null) {
			if(r.next!=null) {
				System.out.print(r.id+" -> ");
			}
			else {
				System.out.print(r.id);
				System.out.println();
			}
			r=r.next;
		}
		c=c.next;
    	}
    	System.out.println("Heyy I am here to remove");
        plist r1=rootFRo;
        while(r1!=null) {
        	plist r2=r1.next;
        	while(r2!=null) {
        		sNode list1=r1.begin;
        		sNode list2=r2.begin;
        		int match=0;
        		while(list1!=null && list2!=null) {
        			if((list1.id.compareTo(list2.id))!=0)
        				match=1;
        			list1=list1.next;
        			list2=list2.next;
        		}
        		if(match==0) {
        			r2=r2.next;
        		r1.next=r2;
        		break;
        		}
        		r2=r2.next;
        	}
        	r1=r1.next;
        }
 
    }
    //Risk analysis module used generating risk report
    public static void compare() {
    	System.out.println("The matrix values are:");
    	show_matrix();
    	PO op=null;
    	PO ap=null;
    	System.out.println("hello I am compairing");
    	vroot=null;
    	int totalpred=0;
    	if(rootOp==null || rootFRo==null) {
    		JOptionPane.showMessageDialog(firstFrame, "Generate both the partial orders at first!!");
    	}
    	else {
    		/* Constructing precedence for optimal order*/
    		plist p=rootOp;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				temp.next=null;
    				//PO t1=op;
    				if(op==null) {
    					op=temp;
    					totalpred++;
    				}
    				else {
    					int dup=0;
    					PO t2=op;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    						totalpred++;
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		
    		/* Constructing precedence for alternate order*/
    		System.out.println("the precedences for alternate order are: ");
    	 p=rootFRo;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				
    				temp.next=null;
    				//PO t1=op;
    				if(ap==null) {
    					System.out.println("Checking for "+s1+" -> "+s2);
    					ap=temp;
    					
    				}
    				else {
    					int dup=0;
    					PO t2=ap;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    					
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		vedges=null;
    		PO temp1=op;
    		while(temp1!=null) {
    			int v=0;
    			int f=0;
    			PO temp2=ap;
    			while(temp2!=null) {
    				if((temp2.id1.compareTo(temp1.id2))==0 && (temp2.id2.compareTo(temp1.id1))==0)
    					v=1;
    				else if((temp2.id1.compareTo(temp1.id1))==0 && (temp2.id2.compareTo(temp1.id2))==0)
    					f=1; 
    				temp2=temp2.next;
    			}
    			//Precedence directly violated
    			if(v==1) {
    			System.out.println("Violation of temp1.id1"+temp1.id1+"->"+temp1.id2);
    			PO temp=new PO();
    			temp.id1=temp1.id1;
    			temp.id2=temp1.id2;
    			if(vedges==null) {
    				vedges=temp;
    			}
    			else {
    				PO h=vedges;
    				while(h.next!=null)
    					h=h.next;
    				h.next=temp;
    				}
    			}
    			//Precedence no longer exists
    			if(v==0 && f==0) {
    				PO temp=new PO();
        			temp.id1=temp1.id1;
        			temp.id2=temp1.id2;
        			if(vedges==null) {
        				vedges=temp;
        			}
        			else {
        				PO h=vedges;
        				while(h.next!=null)
        					h=h.next;
        				h.next=temp;
        				}
    			}
    			temp1=temp1.next;
    		}
    		double risk=0;
    		int vpred=0;
    		double val1=0, val2=0;
    		if(vedges!=null) {
        	//System.out.println("The violating pairs are");
        	textOrder3.append("The conflicting precedences in this iteration are");
        	textOrder3.append("\n");
        	PO k=vedges;
        	double impact=0;
        	int num=0;
        	while(k!=null) {
        		int flag=1;
        		val1=0;
        		val2=0;
        		if(VprevEdges!=null) {
        			PO j=VprevEdges;
        			while(j!=null) {
        				if((j.id1.compareTo(k.id1))==0 && (j.id2.compareTo(k.id2))==0)
        					flag=0;
        				j=j.next;
        			}
        		Node m=prevFro;
        		int ex=0;
        		while(m!=null) {
        			if((m.id.compareTo(k.id1))==0)
        				ex=1;
        			if((m.id.compareTo(k.id2))==0)
        				ex=1;
        			m=m.next;
        		}
        		if(flag==1 && ex==0) {	
        		vpred++;
        		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
    	        int integer1 = in1.nextInt();
    	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
    	        int integer2 = in2.nextInt();
        		String s=k.id1+"->"+k.id2;
        		textOrder3.append(s);
        		textOrder3.append("\n");
        		matrix t1=wd;
        		
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val1=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		t1=wn;
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val2=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		}
        		}
        		else {
        			Node m=prevFro;
            		int ex=0;
            		while(m!=null) {
            			if((m.id.compareTo(k.id1))==0)
            				ex=1;
            			if((m.id.compareTo(k.id2))==0)
            				ex=1;
            			m=m.next;
            		}
            		if(ex==0) {
        			vpred++;
            		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
        	        int integer1 = in1.nextInt();
        	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
        	        int integer2 = in2.nextInt();
            		String s=k.id1+"->"+k.id2;
            		textOrder3.append(s);
            		textOrder3.append("\n");
            		matrix t1=wd;
            		
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val1=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
            		t1=wn;
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val2=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
            	}
        		}
        	
        		if(val1!=0 && val2!=0) {
        			num++;
        			System.out.println("Val 2 is "+val2);
        			System.out.println("for Edge "+k.id1+" -> "+k.id2);
        		if(val2>100) {
        			val2=((double)(100-1)*(double)(val2-1))/(double)(10000-1)+1;
        			val2=Math.round(val2 * 100.0) / 100.0;
        		}
        		impact=impact+val1*val2;
        		}
        		
        		k=k.next;
        	
        		}
        	if(vpred==0) {
        		textOrder3.append("None");
        		probability=0;
        		impval=0;
        		rint=0;
        	}
        	else {
        		double prob=(double)((double)vpred/(double)totalpred);
        	//	prob=Double.valueOf(df.format(prob));
        		prob = Math.round(prob * 100.0) / 100.0;

        		System.out.println("probability is"+prob);
        		System.out.println("Impact is before scaling"+impact);
        		System.out.println("Num is "+num);
        		if(impact!=0)
        			impact=((double)(1-0)*(double)(impact-1))/(double)(1000*num-1)+0;
        		System.out.println("Impact is before rounding"+impact);
        		impact = Math.round(impact * 100.0) / 100.0;
        		//impact=Double.valueOf(df.format(impact));
        		System.out.println("Impact is after rounding"+impact);
        		risk=prob*impact;
        		//risk=Double.valueOf(df.format(risk));
        		risk = Math.round(risk * 100.0) / 100.0;
        		rint=risk;
        		System.out.println("Risk Exposure in this iteration is"+risk);
        		 RiskExp2=RiskExp+risk;
        		 RiskExp2 = Math.round(RiskExp2 * 100.0) / 100.0;
        		System.out.println("total risk is"+RiskExp2);
        		textOrder3.append("Probability is: ");
        		textOrder3.append(String.valueOf(prob));
        		textOrder3.append("\n Impact is: ");
        		textOrder3.append(String.valueOf(impact));
        		textOrder3.append("\n Risk in this iteration: ");
        		textOrder3.append(String.valueOf(risk));
        		textOrder3.append("\n Total Risk is: ");
        		textOrder3.append(String.valueOf(RiskExp2));
        		probability=prob;
        		impval=impact;
        	}
        		
        	}
    	
    		
    	}
    	plist t1=new plist();
        t1.name=iteration;
        t1.next=null;
        t1.begin=null;
        Node g=Fro;
        while(g!=null) {
        	int flag=0;
        	Node h=prevFro;
        	while(h!=null) {
        		if((g.id.compareTo(h.id))==0)
        			flag=1;
        		h=h.next;
        	}
        	if(flag==0) {
        		sNode t2=new sNode();
        		t2.id=g.id;
        		t2.flag=0;
        		t2.visited=0;
        		//This loop checks whether the FR violates or not..
        		PO temp=vedges;
        		while(temp!=null) {
        		//	System.out.println("temp.id= "+temp.id2+" t2.id= "+t2.id);
        			if((temp.id2.compareTo(t2.id))==0) {
        				t2.visited=1;
        				break;
        			}
        			temp=temp.next;
        		}
        		if(t1.begin==null)
        			t1.begin=t2;
        		else {
        			sNode r=t1.begin;
        			while(r.next!=null)
        				r=r.next;
        			r.next=t2;
        		}
        	}
        	g=g.next;
        }
        if(flist==null)
        	flist=t1;
        else {
       	 plist q=flist;
       	 int fl=0;
       	 while(q!=null) {
       		 if(q.name==t1.name) {
       			 q.begin=null;
       			 q.begin=t1.begin;
       			 fl=1;
       			 break;
       		 }
       		 q=q.next;
       	 }
       	 if(fl==0) {
        	 q=flist;
        	while(q.next!=null)
        		q=q.next;
        	q.next=t1;
       	 }
        }
    	
    }
    
    //Risk analysis module used when unfreezing
    public static void compare3() {
    	System.out.println("The matrix values are:");
    	show_matrix();
    	PO op=null;
    	PO ap=null;
    	System.out.println("hello I am compairing");
    	vroot=null;
    	int totalpred=0;
    	if(rootOp==null || rootFRo==null) {
    		JOptionPane.showMessageDialog(firstFrame, "Generate both the partial orders at first!!");
    	}
    	else {
    		/* Constructing precedence for optimal order*/
    		plist p=rootOp;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				temp.next=null;
    				//PO t1=op;
    				if(op==null) {
    					op=temp;
    					totalpred++;
    				}
    				else {
    					int dup=0;
    					PO t2=op;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    						totalpred++;
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		
    		/* Constructing precedence for alternate order*/
    		System.out.println("the precedences for alternate order are: ");
    	 p=rootFRo;
    		while(p!=null) {
    			sNode q=p.begin;
    			while(q.next!=null) {
    				
    			sNode r=q.next;
    			//System.out.println("In outer loop in sequence s"+p.name);
    			while(r!=null) {
    				String s1=q.id;
    				String s2=r.id;
    				PO temp=new PO();
    				temp.id1=s1;
    				temp.id2=s2;
    				
    				temp.next=null;
    				//PO t1=op;
    				if(ap==null) {
    					System.out.println("Checking for "+s1+" -> "+s2);
    					ap=temp;
    					
    				}
    				else {
    					int dup=0;
    					PO t2=ap;
    					while(t2.next!=null) {
    						if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
    							dup=1;
    						t2=t2.next;
    					}
    					if((t2.id1.compareTo(s1))==0 && (t2.id2.compareTo(s2))==0)
							dup=1;
    					if(dup==0)
    					{
    						System.out.println("Checking for "+s1+" -> "+s2);
    						t2.next=temp;
    					
    					}
    				}
    				r=r.next;
    			}
    			q=q.next;
    		}
    			p=p.next;
    		}
    		vedges=null;
    		PO temp1=op;
    		while(temp1!=null) {
    			int v=0;
    			int f=0;
    			PO temp2=ap;
    			while(temp2!=null) {
    				if((temp2.id1.compareTo(temp1.id2))==0 && (temp2.id2.compareTo(temp1.id1))==0)
    					v=1;
    				else if((temp2.id1.compareTo(temp1.id1))==0 && (temp2.id2.compareTo(temp1.id2))==0)
    					f=1; 
    				temp2=temp2.next;
    			}
    			//Precedence directly violated
    			if(v==1) {
    			System.out.println("Violation of temp1.id1"+temp1.id1+"->"+temp1.id2);
    			PO temp=new PO();
    			temp.id1=temp1.id1;
    			temp.id2=temp1.id2;
    			if(vedges==null) {
    				vedges=temp;
    			}
    			else {
    				PO h=vedges;
    				while(h.next!=null)
    					h=h.next;
    				h.next=temp;
    				}
    			}
    			//Precedence no longer exists
    			if(v==0 && f==0) {
    				PO temp=new PO();
        			temp.id1=temp1.id1;
        			temp.id2=temp1.id2;
        			if(vedges==null) {
        				vedges=temp;
        			}
        			else {
        				PO h=vedges;
        				while(h.next!=null)
        					h=h.next;
        				h.next=temp;
        				}
    			}
    			temp1=temp1.next;
    		}
    		double risk=0;
    		int vpred=0;
    		double val1=0, val2=0;
    		if(vedges!=null) {
        	//System.out.println("The violating pairs are");
        	//textOrder1.append("The conflicting precedences in this iteration are");
        	//textOrder1.append("\n");
        	PO k=vedges;
        	double impact=0;
        	int num=0;
        	while(k!=null) {
        		int flag=1;
        		val1=0;
        		val2=0;
        		if(VprevEdges!=null) {
        			PO j=VprevEdges;
        			while(j!=null) {
        				if((j.id1.compareTo(k.id1))==0 && (j.id2.compareTo(k.id2))==0)
        					flag=0;
        				j=j.next;
        			}
        		Node m=prevFro;
        		int ex=0;
        		while(m!=null) {
        			if((m.id.compareTo(k.id1))==0)
        				ex=1;
        			if((m.id.compareTo(k.id2))==0)
        				ex=1;
        			m=m.next;
        		}
        		if(flag==1 && ex==0) {	
        		vpred++;
        		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
    	        int integer1 = in1.nextInt();
    	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
    	        int integer2 = in2.nextInt();
        		String s=k.id1+"->"+k.id2;
        		//textOrder1.append(s);
        		//textOrder1.append("\n");
        		matrix t1=wd;
        		
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val1=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		t1=wn;
        		while(t1!=null)
        		{
        			if(t1.row==integer1 && t1.col==integer2) {
        				val2=t1.val;
        				break;
        			}
        			t1=t1.next;
        		}
        		}
        		}
        		else {
        			Node m=prevFro;
            		int ex=0;
            		while(m!=null) {
            			if((m.id.compareTo(k.id1))==0)
            				ex=1;
            			if((m.id.compareTo(k.id2))==0)
            				ex=1;
            			m=m.next;
            		}
            		if(ex==0) {
        			vpred++;
            		Scanner in1 = new Scanner(k.id1).useDelimiter("[^0-9]+");
        	        int integer1 = in1.nextInt();
        	        Scanner in2 = new Scanner(k.id2).useDelimiter("[^0-9]+");
        	        int integer2 = in2.nextInt();
            		String s=k.id1+"->"+k.id2;
            		//textOrder1.append(s);
            		//textOrder1.append("\n");
            		matrix t1=wd;
            		
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val1=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
            		t1=wn;
            		while(t1!=null)
            		{
            			if(t1.row==integer1 && t1.col==integer2) {
            				val2=t1.val;
            				break;
            			}
            			t1=t1.next;
            		}
            	}
        		}
        	
        		if(val1!=0 && val2!=0) {
        			num++;
        			System.out.println("Val 2 is "+val2);
        			System.out.println("for Edge "+k.id1+" -> "+k.id2);
        		if(val2>100) {
        			val2=((double)(100-1)*(double)(val2-1))/(double)(10000-1)+1;
        			val2=Math.round(val2 * 100.0) / 100.0;
        		}
        		impact=impact+val1*val2;
        		}
        		
        		k=k.next;
        	
        		}
        	if(vpred==0) {
        		//textOrder1.append("None");
        		probability=0;
        		impval=0;
        		rint=0;
        	}
        	else {
        		double prob=(double)((double)vpred/(double)totalpred);
        	//	prob=Double.valueOf(df.format(prob));
        		prob = Math.round(prob * 100.0) / 100.0;

        		System.out.println("probability is"+prob);
        		System.out.println("Impact is before scaling"+impact);
        		System.out.println("Num is "+num);
        		if(impact!=0)
        			impact=((double)(1-0)*(double)(impact-1))/(double)(1000*num-1)+0;
        		System.out.println("Impact is before rounding"+impact);
        		impact = Math.round(impact * 100.0) / 100.0;
        		//impact=Double.valueOf(df.format(impact));
        		System.out.println("Impact is after rounding"+impact);
        		risk=prob*impact;
        		//risk=Double.valueOf(df.format(risk));
        		risk = Math.round(risk * 100.0) / 100.0;
        		rint=risk;
        		System.out.println("Risk Exposure in this iteration is"+risk);
        		 RiskExp2=RiskExp+risk;
        		 RiskExp2 = Math.round(RiskExp2 * 100.0) / 100.0;
        		System.out.println("total risk is"+RiskExp2);
        		
        		probability=prob;
        		impval=impact;
        	}
        		
        	}
    	
    		
    	}
    	
    }

	public static void showgraph(String s)
	{
		iteration=41;
		System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
		System.out.println("Hi I am here");
		//String path="";
		int k=0;
		for(k=0;k<iteration-1;k++) {
			String temp="View"+String.valueOf(k+1);
			if((temp.compareTo(s))==0) {
				String path="Itr"+String.valueOf(k+1);
				try {
				File file=new File(path+"\\ChoiceList.txt");
				Desktop.getDesktop().open(file);
				}catch(IOException f) {
					
				}
			}
		}
		for(k=0;k<iteration-1;k++) {
			String temp="PO"+String.valueOf(k+1);
			String tempa="AP"+String.valueOf(k+1);
			if((temp.compareTo(s))==0) {
			String path="Itr"+String.valueOf(k+1);
		
				Graph graph=new MultiGraph("");
		    	 graph = new MultiGraph("Optimal Partial Order");
		       	graph.setAttribute("ui.title", "Optimal Partial Order || Iteration "+String.valueOf(k+1)+" ");
		        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;text-size: 16;fill-color: yellow;text-mode:normal; text-style: bold; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
		       System.out.println("The path is "+path);
		        //Adding Vertices
		        try{
		        	FileReader f1=new FileReader(path+"\\FRList.txt");
					int i;
					String temp2="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp2="";
						temp2=temp2.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp2=temp2.concat(Character.toString(c));
						}
						System.out.println("Temp is "+temp2);
					
						if(temp2.compareTo("count")!=0)
						{
							System.out.println("Vertex = "+temp2);
							graph.addNode(temp2);
							i=f1.read();
							if(i==13)
								i=f1.read();
						}
						else
							break;
							}
					
		        }catch(IOException en) {
		        	
		        }
		      //Creating Edges
		        try {
					
					FileReader f1=new FileReader(path+"\\POList.txt");
					int i;
					String temp2="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp2="";
						temp2=temp2.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp2=temp2.concat(Character.toString(c));
						}
						//System.out.println("Temp is "+temp);
					
						
						String k1=temp2;
						temp2="";
							while((i=f1.read())!=32) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp2=temp2.concat(Character.toString(c));
							}
							String k2=temp2;
							String ed=k1+k2;
				    		//System.out.println("Edge is"+k.id1+"->"+k.id2);
				    		final Edge edge = graph.addEdge(ed, k1, k2, true);
				           edge.addAttribute("layout.weight", 6);
	
						
						i=f1.read();
						if(i==13)
							i=f1.read();
						
					}
						}
					catch(IOException e1) {
						
					}
		    	for (final org.graphstream.graph.Node node : graph) {
		            node.addAttribute("ui.label", node.getId());
		            node.addAttribute("layout.weight", 150);
		        }
		    	Viewer viewer = graph.display();
		    
		    	 viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
	
				
					
				break;
			}
			//Displaying alternate partial order
			else if((tempa.compareTo(s))==0) {
				String path="Itr"+String.valueOf(k+1);
				Graph graph=new MultiGraph("");
		    	 graph = new MultiGraph("Optimal Partial Order");
		       	graph.setAttribute("ui.title", "Optimal Partial Order || Iteration "+String.valueOf(k+1)+" ");
		        graph.setAttribute("ui.stylesheet", "node {size : 40px; shape: circle;text-size: 16;fill-color: yellow;text-mode:normal; text-style: bold; text-alignment: center; text-background-mode: none; fill-mode: dyn-plain; text-visibility-mode: normal;}");
		        //Adding Vertices
		        try{
		        	FileReader f1=new FileReader(path+"\\FRList.txt");
					int i;
					String temp2="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp2="";
						temp2=temp2.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp2=temp2.concat(Character.toString(c));
						}
						System.out.println("Temp is "+temp2);
					
						if(temp2.compareTo("count")!=0)
						{
							System.out.println("Vertex = "+temp2);
							graph.addNode(temp2);
							i=f1.read();
							if(i==13)
								i=f1.read();
						}
						else
							break;
							}
					
		        }catch(IOException en) {
		        	
		        }
		      //Creating Edges
		        try {
					
					FileReader f1=new FileReader(path+"\\APOList.txt");
					int i;
					String temp2="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp2="";
						temp2=temp2.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp2=temp2.concat(Character.toString(c));
						}
						//System.out.println("Temp is "+temp);
					
						
						String k1=temp2;
						temp2="";
							while((i=f1.read())!=32) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp2=temp2.concat(Character.toString(c));
							}
							String k2=temp2;
							String ed=k1+k2;
				    		//System.out.println("Edge is"+k.id1+"->"+k.id2);
				    		final Edge edge = graph.addEdge(ed, k1, k2, true);
				           edge.addAttribute("layout.weight", 6);
				           
						i=f1.read();
						if(i==13)
							i=f1.read();
						
					}
						}
					catch(IOException e1) {
						
					}
		    	for (final org.graphstream.graph.Node node : graph) {
		            node.addAttribute("ui.label", node.getId());
		            node.addAttribute("layout.weight", 150);
		        }
		    	Viewer viewer = graph.display();
		    
		    	 viewer.setCloseFramePolicy(Viewer.CloseFramePolicy.HIDE_ONLY);
	
		    	 for (final org.graphstream.graph.Node node : graph) {
		             node.addAttribute("ui.label", node.getId());
		             node.addAttribute("layout.weight", 150);
		             String s2=node.getId();
		           //Check if node is in user choice list
			           String tempc="";
			           int flagc=0;
			           for(int p=0;p<=k;p++) {
			        	   try {
			        	 String path2="Itr"+String.valueOf(p+1);  
			        	 FileReader choice=new FileReader(path2+"\\ChoiceList.txt");
			        	 int h;
			        	 int flag=0;
			        	 
			        	 while((h=choice.read())!=-1) {
			        		char c=(char)h;
								tempc="";
								tempc=tempc.concat(Character.toString(c));
								while((h=choice.read())!=32) {
									c=(char)h;
									//System.out.println(i);
									if(h!=13)
										tempc=tempc.concat(Character.toString(c));
								}
								if((tempc.compareTo(s2))==0)
								{
									flagc=1;
								}
								
								h=choice.read();
								if(h==13)
									h=choice.read();	
								
			        	 }
			        	   }catch(IOException e4) {
			        		   
			        	   }
			           
			           }
		             if(flagc==1)
		             	node.addAttribute("ui.style", "fill-color: rgb(102,255,102); text-color: rgb(255,255,255);");
		      
		     	}
	
				break;
			}
	}		
		
	}
	public static void showLog()
	    {
	    	//int iteration=41;
	    	String num="";
	    	
	    	try {
	    		FileReader fr=new FileReader("count.txt");
	    		int i;
	    		while((i=fr.read())!=-1) {
	    			char c=(char)i;
	    			if(i>=48 && i<=57)
	    				num=num.concat(Character.toString(c));
	    		}
	    		fr.close();
	    	}catch(IOException io) {
	    		
	    	}
	    	System.out.println("Num = "+num);
	    	if((num.compareTo(""))==0)
	    		iteration=0;
	    	else
	    	iteration=Integer.valueOf(num)+1;
	    	JFrame statsFrame=new JFrame("Analytics");
	    	statsFrame.getContentPane().setBackground(new Color(255, 255, 153));
	        try {
	            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
	        }
	        catch (Exception e) {
	            System.out.println("Look and Feel not set");
	        }
	        statsFrame.setLayout(null);
	        statsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        statsFrame.setBounds(15, 6, 1320, 680);
	        int j=0;
	       	JButton[] buttons=new JButton[iteration];
	       	int x=100;
	       	int y=100;
	       	//Creating the table
	       
	     	DefaultTableModel model2 = new DefaultTableModel();  
	     //statdata=new JTable(model2);
	  
	     model2.setDataVector(new Object[][]{},
	       new Object[]{"Iteration No.","FR","NFR","Dependency","Conflict","Temporal","FR","NFR","Dependency","Conflict","Temporal","Dependency","Conflict","User Choice","Edges", "Value","Total","Optimal", "Alternate"});
	
	       statdata = new JTable( model2 ) {
	         protected JTableHeader createDefaultTableHeader() {
	             return new GroupableTableHeader(columnModel);
	         }
	         
	       };
	       //statdata.getTableHeader().addMouseListener(l);
	       String[] toolTips = {"Iteration Number", "Total Number of Functional Requirements", 
	    		   "Total Number of Non-functional Requirements", 
	    		   "Total Number of functional-non-functional requirement dependencies",
	    		   "Total Number of Non-functional requirement conflicts",
	    		   "Total Number of Temporal Dependencies between the Functional Requirements", 
	    		   "Number of Functional Requirements Newly added in an iteration",
	    		   "Number of Non-Functional Requirements Newly added in an iteration",
	    		   "Number of Functional-Non-functional requirement dependencies Newly added in an iteration",
	    		   "Number of Non-functional requirement conflicts Newly added in an iteration",
	    		   "Number of Temporal Dependencies between the Functional Requirements Newly added in an iteration", 
	    		   "Number of Functional-Non-functional requirement dependencies updated in an iteration",
	    		   "Number of Non-functional requirement conflicts updated in an iteration",
	    		   "Click to view User selected requirements for any iteration",
	    		   "List of conflicting precedences",
	    		   "Risk incurred in a particular iteration",
	    		   "Total Risk",
	    		   "Click Buttons to view Optimal partial Order",
	    		   "Click Buttons to view Alternate partial Order"
	    		   };
	       
	       ToolTipHeader tooltipHeader = new ToolTipHeader(statdata.getColumnModel());
	       tooltipHeader.setToolTipStrings(toolTips);
	       statdata.setTableHeader(tooltipHeader);
	       statdata.getColumn("Optimal").setCellRenderer(new ButtonRenderer());
	       statdata.getColumn("Optimal").setCellEditor(
	           new ButtonEditor(new JCheckBox()));
	       statdata.getColumn("Alternate").setCellRenderer(new ButtonRenderer());
	       statdata.getColumn("Alternate").setCellEditor(
	           new ButtonEditor(new JCheckBox()));
	       statdata.getColumn("User Choice").setCellRenderer(new ButtonRenderer());
	       statdata.getColumn("User Choice").setCellEditor(
	           new ButtonEditor(new JCheckBox()));
	       TableColumn tColumn;
	       tColumn = statdata.getColumnModel().getColumn(1);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.yellow, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(2);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.yellow, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(3);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.yellow, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(4);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.yellow, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(5);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.yellow, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(6);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.green, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(7);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.green, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(8);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.green, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(9);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.green, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(10);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.green, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(11);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.blue, Color.white));
	       tColumn = statdata.getColumnModel().getColumn(12);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.blue, Color.white));
	       tColumn = statdata.getColumnModel().getColumn(14);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.pink, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(15);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.pink, Color.black));
	       tColumn = statdata.getColumnModel().getColumn(16);
	       tColumn.setCellRenderer(new ColumnColorRenderer(Color.pink, Color.black));
	       TableColumnModel cm = statdata.getColumnModel();
	       ColumnGroup g_name = new ColumnGroup("Total");
	     
	       g_name.add(cm.getColumn(1));
	       g_name.add(cm.getColumn(2));
	       g_name.add(cm.getColumn(3));
	       g_name.add(cm.getColumn(4));
	       g_name.add(cm.getColumn(5));
	       ColumnGroup g_name2 = new ColumnGroup("Newly Added");
	       g_name2.add(cm.getColumn(6));
	       g_name2.add(cm.getColumn(7));
	       g_name2.add(cm.getColumn(8));
	       g_name2.add(cm.getColumn(9));
	       g_name2.add(cm.getColumn(10));
	       ColumnGroup g_name3 = new ColumnGroup("Updated");
	       g_name3.add(cm.getColumn(11));
	       g_name3.add(cm.getColumn(12));
	       ColumnGroup g_name4 = new ColumnGroup("Risk Analysis");
	       g_name4.add(cm.getColumn(13));
	       g_name4.add(cm.getColumn(14));
	       g_name4.add(cm.getColumn(15));
	       g_name4.add(cm.getColumn(16));
	       ColumnGroup g_name5 = new ColumnGroup("Partial Order");
	       g_name5.add(cm.getColumn(17));
	       g_name5.add(cm.getColumn(18));
	       
	       
	       GroupableTableHeader header = (GroupableTableHeader)statdata.getTableHeader();
	       header.addColumnGroup(g_name);
	       header.addColumnGroup(g_name2);
	       header.addColumnGroup(g_name3);
	       header.addColumnGroup(g_name4);
	       header.addColumnGroup(g_name5);
	       Font f = new Font("TimesRoman",Font.BOLD,12);
	       header.setFont(f);
	       
	      //statdata.getHe
	      //setBorder(BorderFactory.createLineBorder(Color.black));
	   //    statdata.setFillsViewportHeight(true);
	       //statdata.setEnabled(false);
			JScrollPane js=new JScrollPane(statdata);
			//js.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			statdata.setShowGrid(true);
			//statdata.setShowHorizontalLines(true);
			//statdata.setShowVerticalLines(true);;
			js.setBounds(0, 20, 1300, 400);
			js.setVisible(true);
		statdata.setBackground(new Color(255, 229, 255));
			statsFrame.add(js);
			
			
			
			// Adding data to table
			 for(int k=0;k<iteration-1;k++) {
			DefaultTableModel model = (DefaultTableModel)statdata.getModel();
			Object []o = new Object[19];
	
		
			//Reading files
			int clicked=k+1;
			o[0]=clicked;
			String p="Itr"+String.valueOf(clicked);
				//read FRs
				int count=0;
				try {
				FileReader f1=new FileReader(p+"\\FRList.txt");
				int i;
				String temp="";
				while((i=f1.read())!=-1) {
					char c=(char)i;
					//System.out.println(i);
					temp="";
					temp=temp.concat(Character.toString(c));
					while((i=f1.read())!=32) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13 && i!=10)
							temp=temp.concat(Character.toString(c));
					}
					System.out.println("Temp is "+temp);
				
					if(temp.compareTo("count")==0)
					{
						temp="";
						while((i=f1.read())!=10) {
	   					c=(char)i;
	   					System.out.println(i);
	   					if(i!=13)
	   						temp=temp.concat(Character.toString(c));
	   				}
						//System.out.println("temp="+temp);
						count=Integer.valueOf(temp);
						break;
					}
					else {
						i=f1.read();
					if(i==13)
						i=f1.read();
					}
					//System.out.println(i);	
				}
				System.out.println("FR count is"+count);
				}
				catch(IOException e1) {
					
				}
			o[1]=count;
			count=0;
			try {
			FileReader f1=new FileReader(p+"\\NFRList.txt");
			int i;
			String temp="";
			while((i=f1.read())!=-1) {
				char c=(char)i;
				//System.out.println(i);
				temp="";
				temp=temp.concat(Character.toString(c));
				while((i=f1.read())!=32) {
					c=(char)i;
					//System.out.println(i);
					if(i!=13 && i!=10)
						temp=temp.concat(Character.toString(c));
				}
				//System.out.println("Temp is "+temp);
			
				if(temp.compareTo("count")==0)
				{
					temp="";
					while((i=f1.read())!=10) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13)
							temp=temp.concat(Character.toString(c));
					}
					count=Integer.valueOf(temp);
					break;
				}
				else {
					i=f1.read();
				if(i==13)
					i=f1.read();
				}
				//System.out.println(i);	
			}
			System.out.println("NFR count is"+count);
			}
			catch(IOException e1) {
				
			}
		o[2]=count;
		count=0;
		try {
		FileReader f1=new FileReader(p+"\\DepList.txt");
		int i;
		String temp="";
		while((i=f1.read())!=-1) {
			char c=(char)i;
			//System.out.println(i);
			temp="";
			temp=temp.concat(Character.toString(c));
			while((i=f1.read())!=32) {
				c=(char)i;
				//System.out.println(i);
				if(i!=13 && i!=10)
					temp=temp.concat(Character.toString(c));
			}
			//System.out.println("Temp is "+temp);
		
			if(temp.compareTo("count")==0)
			{
				temp="";
				while((i=f1.read())!=10) {
					c=(char)i;
					//System.out.println(i);
					if(i!=13)
						temp=temp.concat(Character.toString(c));
				}
				count=Integer.valueOf(temp);
				break;
			}
			else {
				while((i=f1.read())!=10) {
					
				}
				
				/*i=f1.read();
			if(i==13)
				i=f1.read();*/
			}
			//System.out.println(i);	
		}
		System.out.println("Dep count is"+count);
		}
		catch(IOException e1) {
			
		}
				o[3]=count;
				count=0;
				try {
				FileReader f1=new FileReader(p+"\\ConList.txt");
				int i;
				String temp="";
				while((i=f1.read())!=-1) {
					char c=(char)i;
					//System.out.println(i);
					temp="";
					temp=temp.concat(Character.toString(c));
					while((i=f1.read())!=32) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13 && i!=10)
							temp=temp.concat(Character.toString(c));
					}
					//System.out.println("Temp is "+temp);
				
					if(temp.compareTo("count")==0)
					{
						temp="";
						while((i=f1.read())!=10) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13)
								temp=temp.concat(Character.toString(c));
						}
						count=Integer.valueOf(temp);
						break;
					}
					else {
						while((i=f1.read())!=10) {
							
						}
						/*i=f1.read();
						if(i==13)
							i=f1.read();
						}*/
					//System.out.println(i);	
				}
				}	
				System.out.println("Con count is"+count);
				}
				catch(IOException e1) {
					
				}
				o[4]=count;
				count=0;
				try {
				FileReader f1=new FileReader(p+"\\TemList.txt");
				int i;
				String temp="";
				while((i=f1.read())!=-1) {
					char c=(char)i;
					//System.out.println(i);
					temp="";
					temp=temp.concat(Character.toString(c));
					while((i=f1.read())!=32) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13 && i!=10)
							temp=temp.concat(Character.toString(c));
					}
					//System.out.println("Temp is "+temp);
				
					if(temp.compareTo("count")==0)
					{
						temp="";
						while((i=f1.read())!=10) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13)
								temp=temp.concat(Character.toString(c));
						}
						count=Integer.valueOf(temp);
						break;
					}
					else {
						while((i=f1.read())!=10) {
						
						}
						/*i=f1.read();
						if(i==13)
							i=f1.read();
						}*/
					//System.out.println(i);	
				}
				}
				System.out.println("Tem count is"+count);
				}
				
				catch(IOException e1) {
					
				}
			o[5]=count;
			if(k==0) //First iteration will not have any update
			{
				o[6]=0;
				o[7]=0;
				o[8]=0;
				o[9]=0;
				o[10]=0;
				o[11]=0;
				o[12]=0;
				
			}
			else {
				try {
					FileReader f1=new FileReader(p+"\\NewList.txt");
					int i;
					String temp="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp="";
						temp=temp.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp=temp.concat(Character.toString(c));
						}
						//System.out.println("Temp is "+temp);
					
						if(temp.compareTo("Dependency")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							//count=Integer.valueOf(temp);
							o[8]=temp;
							
						}
						else if(temp.compareTo("Conflict")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							//count=Integer.valueOf(temp);
							o[9]=temp;
							
						}
						else if(temp.compareTo("Temporal")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							//count=Integer.valueOf(temp);
							o[10]=temp;
							
						}
						else if(temp.compareTo("FR")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							//count=Integer.valueOf(temp);
							o[6]=temp;
							
						}
						else if(temp.compareTo("NFR")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							//count=Integer.valueOf(temp);
							o[7]=temp;
							
						}
						//System.out.println(i);	
					}
					System.out.println("NFR count is"+count);
					}
					catch(IOException e1) {
						
					}
				try {
					FileReader f1=new FileReader(p+"\\UpdateList.txt");
					int i;
					String temp="";
					while((i=f1.read())!=-1) {
						char c=(char)i;
						//System.out.println(i);
						temp="";
						temp=temp.concat(Character.toString(c));
						while((i=f1.read())!=32) {
							c=(char)i;
							//System.out.println(i);
							if(i!=13 && i!=10)
								temp=temp.concat(Character.toString(c));
						}
						//System.out.println("Temp is "+temp);
					
						if(temp.compareTo("Dependency")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							o[11]=temp;
						}
						if(temp.compareTo("Conflict")==0)
						{
							temp="";
							while((i=f1.read())!=10) {
								c=(char)i;
								//System.out.println(i);
								if(i!=13)
									temp=temp.concat(Character.toString(c));
							}
							o[12]=temp;
						}
						
						//System.out.println(i);	
					}
					//System.out.println("NFR count is"+count);
					}
					catch(IOException e1) {
						
					}
			}
			count=0;
			String list="";
			try {
			FileReader f1=new FileReader(p+"\\ChoiceList.txt");
			int i;
			String temp="";
			
			while((i=f1.read())!=-1) {
				char c=(char)i;
				//System.out.println(i);
				temp="";
				temp=temp.concat(Character.toString(c));
				while((i=f1.read())!=32) {
					c=(char)i;
					//System.out.println(i);
					if(i!=13 && i!=10)
						temp=temp.concat(Character.toString(c));
				}
				System.out.println("Temp is "+temp);
			list=list.concat(temp+" || ");
					i=f1.read();
				if(i==13)
					i=f1.read();
				}
				//System.out.println(i);	
			}
			catch(IOException e1) {
				
			}
			o[13]="View"+String.valueOf(k+1);
			//o[13]=list;
			count=0;
			try {
			FileReader f1=new FileReader(p+"\\Risk.txt");
			int i;
			String temp="";
			while((i=f1.read())!=-1) {
				char c=(char)i;
				//System.out.println(i);
				temp="";
				temp=temp.concat(Character.toString(c));
				while((i=f1.read())!=32) {
					c=(char)i;
					//System.out.println(i);
					if(i!=13 && i!=10)
						temp=temp.concat(Character.toString(c));
				}
				//System.out.println("Temp is "+temp);
			
				if(temp.compareTo("Conflict")==0)
				{
					temp="";
					while((i=f1.read())!=10) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13)
							temp=temp.concat(Character.toString(c));
					}
					o[14]=temp;
					
				}
				else if(temp.compareTo("Risk")==0)
				{
					temp="";
					while((i=f1.read())!=10) {
						c=(char)i;
						//System.out.println(i);
						if(i!=13)
							temp=temp.concat(Character.toString(c));
					}
					o[15]=temp;
					
				}
				else {
					while((i=f1.read())!=10) {
						
					}
					/*i=f1.read();
					if(i==13)
						i=f1.read();
					}*/
				//System.out.println(i);	
			}
			}	
		
			
			}
			catch(IOException e1) {
				
			}
			try {
				FileReader f1=new FileReader(p+"\\TotalRisk.txt");
				int i;
				String temp="";
				//System.out.println("reading total risk value");
				while((i=f1.read())!=-1) {
					char c=(char)i;
					System.out.println(i);
				
					if(i!=10 && i!=13)
					temp=temp.concat(Character.toString(c));
					System.out.println("temp="+temp);
				
					}
				//	System.out.println("Total Risk= "+temp);	
				o[16]=temp;
				}
				catch(IOException e1) {
					
				}
	
			o[17]="PO"+String.valueOf(k+1);
			o[18]="AP"+String.valueOf(k+1);
			model.addRow(o);
			// statdata.getColumnModel().getColumn(16).setCellRenderer(new ClientsTableButtonRenderer());
			  //statdata.getColumnModel().getColumn(16).setCellEditor(new ClientsTableRenderer(new JCheckBox()));
			//statdata.setValueAt(b1, 0, 16);
			 }
			 statsFrame.addWindowListener(new WindowAdapter() {
			      public void windowClosing(WindowEvent e) {
			       // System.exit(0);
			      }
			    });	
			 
			 //Adding graph
			 
			 JLabel l1=new JLabel("Select a parameter");
			 l1.setFont(new Font("Calibri", 2, 18));
		     l1.setBounds(560, 450, 200, 30);
		     statsFrame.add(l1);
		     JComboBox c1=new JComboBox();
		     c1.setBounds(560, 490, 100, 40);
	         statsFrame.add(c1);
	        c1.addItem("");
	        c1.addItem("FR");
	        c1.addItem("NFR");
	        c1.addItem("Dependency");
	        c1.addItem("Conflict");
	        c1.addItem("Temporal");
	        c1.addItem("Risk");
	        JButton b1=new JButton("Generate");
	        b1.setToolTipText("Click to Generate a Graph");
	        b1.setFont(new Font("Calibri", 2, 16));
	        b1.setBackground(new Color(255, 204, 204));
	        b1.setForeground(Color.black);
	        b1.setBounds(670, 490, 180, 40);
	        statsFrame.add(b1);
	        b1.addActionListener(new ActionListener() {
	             @Override
	              public void actionPerformed(final ActionEvent e) {
	            	 String s1=c1.getSelectedItem().toString();
	             	if((s1.compareTo(""))!=0) {
	             		// Create the Arrays
	             		int[] a1=new int[1000];
	             		int[] a2=new int[1000];
	             		int[] a3=new int[1000];
	             		double[] a4 = new double[1000];
	             		double[] a5 = new double[1000];
	        			int num=statdata.getRowCount();
	        			if(num==0) {
	             			JOptionPane.showMessageDialog(statsFrame,"No Data Available!!");
	         			}
	        			else {
	             		if(s1.compareTo("FR")==0) {
	             			int k=1;
	                		for(int j=0;j<num;j++) {
	                			a1[j]=Integer.valueOf(statdata.getValueAt(j, 1).toString());
	                			a2[j]=Integer.valueOf(statdata.getValueAt(j, 6).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		else if (s1.compareTo("NFR")==0) {
	                		for(int j=0;j<num;j++) {
	                			a1[j]=Integer.valueOf(statdata.getValueAt(j, 2).toString());
	                			a2[j]=Integer.valueOf(statdata.getValueAt(j, 7).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		else if (s1.compareTo("Dependency")==0) {
	                		for(int j=0;j<num;j++) {
	                			a1[j]=Integer.valueOf(statdata.getValueAt(j, 3).toString());
	                			a2[j]=Integer.valueOf(statdata.getValueAt(j, 8).toString());
	                			a3[j]=Integer.valueOf(statdata.getValueAt(j, 11).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		else if (s1.compareTo("Conflict")==0) {
	                		for(int j=0;j<num;j++) {
	                			a1[j]=Integer.valueOf(statdata.getValueAt(j, 4).toString());
	                			a2[j]=Integer.valueOf(statdata.getValueAt(j, 9).toString());
	                			a3[j]=Integer.valueOf(statdata.getValueAt(j, 12).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		else if (s1.compareTo("Temporal")==0) {
	                		for(int j=0;j<num;j++) {
	                			a1[j]=Integer.valueOf(statdata.getValueAt(j, 5).toString());
	                			a2[j]=Integer.valueOf(statdata.getValueAt(j, 10).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		else if (s1.compareTo("Risk")==0) {
	                		for(int j=0;j<num;j++) {
	                			a4[j]=Double.parseDouble(statdata.getValueAt(j, 15).toString());
	                			a5[j]=Double.parseDouble(statdata.getValueAt(j, 16).toString());
	                			}
	                		LineChart_AWT.graphGenerate(num, s1, a1, a2, a3,a4,a5);
	                		}
	             		}
	             	}
	             	else {
	             			JOptionPane.showMessageDialog(statsFrame,"Select a parameter!");
	             	}
	             
	              }
	          });
	        
	        
	        statsFrame.setVisible(true);
	    }
	public static void createLog()
	{
		int count=0;
		String path="Itr"+String.valueOf(iteration);
		 File file = new File(path);
	     //Creating the directory
	     boolean bool = file.mkdir();
	     if(bool){
	         System.out.println("Directory created successfully");
	      }else{
	         System.out.println("Sorry couldn�t create specified directory");
	      }
	     if(RiskExp2!=0) {
	    	 try {
	     		BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\TotalRisk.txt", false));
	     		
	     		b1.write(String.valueOf(RiskExp2));
	     		b1.newLine();
	     		b1.close();
	     	}catch(IOException e) {
	     		
	     	}
	     }
	
			try {
			    BufferedWriter b1=null;
				if(choice!=0) {
		 		 b1 = new BufferedWriter(new FileWriter(path+"\\Parameter.txt", false));
		 		 String t=Integer.toString(choice);
		 		 b1.write(t);
		 		 b1.newLine();
		 		 b1.close();
				}
		 	}catch(IOException fe) {
		 		
		 	}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\FRList.txt", false));
			Node f=FR;
			while(f!=null) {
				b1.write(f.id+" ");
				b1.newLine();
				count++;
				f=f.next;
			}
			b1.write("count "+count);
			b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		count=0;
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\NFRList.txt", false));
			Node f=NFR;
			while(f!=null) {
				b1.write(f.id+" ");
				b1.newLine();
				count++;
				f=f.next;
			}
			b1.write("count "+count);
			b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\Priority.txt", false));
			Node f=NFR;
			while(f!=null) {
				b1.write(f.priority+" ");
				b1.newLine();
				f=f.next;
			}
		//	b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		
		count=0;
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\DepList.txt", false));
			Edge1 f=E_FN;
			while(f!=null) {
				b1.write(f.id1+" "+f.id2+" "+f.value);
				b1.newLine();
				count++;
				f=f.next;
			}
			b1.write("count "+count);
			b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		count=0;
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\ConList.txt", false));
			Edge1 f=E_NN;
			while(f!=null) {
				b1.write(f.id1+" "+f.id2+" "+f.value);
				b1.newLine();
				count++;
				f=f.next;
			}
			b1.write("count "+count);
			b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		count=0;
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\TemList.txt", false));
			Edge2 f=E_FF;
			while(f!=null) {
				b1.write(f.id1+" "+f.id2);
				b1.newLine();
				count++;
				f=f.next;
			}
			b1.write("count "+count);
			b1.newLine();
			b1.close();
		}catch(IOException e) {
			
		}
		try {
			
			String name="Iteration"+String.valueOf(iteration)+".txt";
			
		BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\Risk.txt", false));
		FileReader f1=new FileReader(name);
		int i;
		while((i=f1.read())!=-1) {
			char c=(char)i;
			b1.write(i);
		}
		f1.close();
		b1.close();
		}catch(IOException e) {
			
		}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\ChoiceList.txt", false));
			plist f=flist;
			while(f!=null)
			{
			if(f.name==iteration) {
			sNode j=f.begin;
			while(j!=null) {
				b1.write(j.id+" ");
				b1.newLine();
			//	count++;
				j=j.next;
			}
				break;
				}
				f=f.next;
			}
			
			b1.close();
		}catch(IOException e) {
			
		}
		try {
			if(iteration>1) {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\UpdateList.txt", false));
			b1.write("Dependency "+updatedep);
			b1.newLine();
			b1.write("Conflict "+updatecon);
			b1.newLine();
			b1.close();
			}
		}catch(IOException e) {
			
		}
		try {
			if(iteration>1) {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\NewList.txt", false));
			b1.write("Dependency "+newdep);
			b1.newLine();
			b1.write("Conflict "+newcon);
			b1.newLine();
			b1.write("Temporal "+newtemp);
			b1.newLine();
			b1.write("FR "+newFR);
			b1.newLine();
			
			b1.write("NFR "+newNFR);
			b1.newLine();
			b1.close();
			}
		}catch(IOException e) {
			
		}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\POList.txt", false));
			PO f=proot;
			while(f!=null) {
				b1.write(f.id1+" "+f.id2+" ");
				b1.newLine();
		
				f=f.next;
			}
			b1.close();
		}catch(IOException e) {
			
		}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\SeqList.txt", false));
		plist m = rootOp;
	    while (m != null) {
	        for (sNode n = m.begin; n != null; n = n.next) {
	            b1.write(n.id+" ");
	        }
	        m = m.next;
	        b1.newLine();
	    }
		b1.close();
		}catch(IOException e) {
		
	}
		try {
			BufferedWriter b1= new BufferedWriter(new FileWriter(path+"\\APOList.txt", false));
			PO f=proot2;
			while(f!=null) {
				b1.write(f.id1+" "+f.id2+" ");
				b1.newLine();
		
				f=f.next;
			}
			b1.close();
		}catch(IOException e) {
			
		}
	}
	public static void store_data() {
		delete_files();
	    compare2();
	 	 if(vedges!=null) {
	   		 PO temp=vedges;
	   		 while(temp!=null) {
	   			 int ex=0;
	   			 PO nd=new PO();
	   			 nd.id1=temp.id1;
	   			 nd.id2=temp.id2;
	   			 nd.next=null;
	   			 if(VprevEdges!=null) {
	   			 PO temp2=VprevEdges;
	   			 while(temp2.next!=null) {
	   				 if((temp2.id1.compareTo(temp.id1))==0 && (temp2.id2.compareTo(temp.id2))==0)
	   					 ex=1;
	   				 temp2=temp2.next;
	   			 }
	   			 if((temp2.id1.compareTo(temp.id1))==0 && (temp2.id2.compareTo(temp.id2))==0)
					 ex=1;
	   			 if(ex==0) {
	   				 System.out.println("Yes exists! "+temp.id1+"->"+temp.id2);
	   				 temp2.next=nd;
	   			 }
	   		 }
	   			 else {
	   				 System.out.println("Empty list! "+temp.id1+"->"+temp.id2);
	   				 VprevEdges=nd;
	   			 }
	   			 temp=temp.next;
	   		 }
	   	 }
	 	 if(Fro!=null) {
			 Node k=Fro;
			 while(k!=null) {
				 System.out.println("running!");
				 Node temp=new Node();
				 temp.id=k.id;
				 temp.next=null;
				 if(prevFro==null) {
					 System.out.println("Prev Fro is null");
					 prevFro=temp;
				 }
				 else {
					 int flag=0;
					 Node j=prevFro;
					 while(j.next!=null) {
						 if((j.id.compareTo(temp.id))==0)
							 flag=1;
						 j=j.next;
					 }
					 if((j.id.compareTo(temp.id))==0)
						 flag=1;
					 if(flag==0)
						 j.next=temp;
				 }
				 k=k.next;
			 }
			 System.out.println("The frozen set is ");
			 Node r=prevFro;
			 while(r!=null) {
				 System.out.print("item="+r.id+" ");
				 r=r.next;
			 }
		 }
	     createLog();
		BufferedWriter b1=null;
		try {
	 		 b1 = new BufferedWriter(new FileWriter("count.txt", false));
	 		 String t=Integer.toString(iteration);
	 		 b1.write(t);
	 		 b1.newLine();
	 		 b1.close();
	 	}catch(IOException fe) {
	 		
	 	}
		
	b1=null;
	
	if(RiskExp2!=0) {
		try {
	 		 b1 = new BufferedWriter(new FileWriter("TotalRisk.txt", false));
	 		
	 		 b1.write(Double.toString(RiskExp2));
	 		 b1.newLine();
	 		 b1.close();
	 	}catch(IOException fe) {
	 		
	 	}
	RiskExp=RiskExp2;
	}
	
	RiskExp2=0;
		PO j=vedges;
		while(j!=null) {
			try {
	    		 b1 = new BufferedWriter(new FileWriter("VEdges.txt", true));
	    		 b1.write(j.id1+" "+j.id2);
	    		 b1.newLine();
	    		 b1.close();
	    	}catch(IOException fe) {
	    		
	    	}
			j=j.next;
		}
		j=VprevEdges;
		while(j!=null) {
			int flag=0;
			PO k=vedges;
			while(k!=null) {
				if((k.id1.compareTo(j.id1))==0 && (k.id2.compareTo(j.id2))==0)
					flag=1;
				k=k.next;
			}
			if(flag==0) {
				try {
	       		 b1 = new BufferedWriter(new FileWriter("VEdges.txt", true));
	       		 b1.write(j.id1+" "+j.id2);
	       		 b1.newLine();
	       		 b1.close();
	       	}catch(IOException fe) {
	       		
	       	}
			}
			j=j.next;
		}
		
		plist t1=flist;
		while(t1!=null) {
			try {
				b1 = new BufferedWriter(new FileWriter("VNodes.txt", true));
	      		 b1.write(t1.name+" ");
		
			sNode t2=t1.begin;
			while(t2!=null) {
				b1.write(t2.id+" "+t2.visited+" ");
				t2=t2.next;
			}
			b1.newLine();
	  		b1.close();
			}catch(IOException fe) {
	       		
	       	}
			t1=t1.next;
		}
		Node v=Fro;
		while(v!=null) {
			try {
	      		 b1 = new BufferedWriter(new FileWriter("FroFR.txt", true));
	      		 b1.write(v.id);
	      		 b1.newLine();
	      		 b1.close();
	      	}catch(IOException fe) {
	      		
	      	}
	   		v=v.next;
		}
		Node x=prevFro;
		while(x!=null) {
			int flag=0;
			 v=Fro;
			while(v!=null) {
				if((v.id.compareTo(x.id))==0)
					flag=1;
				v=v.next;
			}
			if(flag==0) {
				try {
	         		 b1 = new BufferedWriter(new FileWriter("FroFR.txt", true));
	         		 b1.write(x.id);
	         		 b1.newLine();
	         		 b1.close();
	         	}catch(IOException fe) {
	         		
	         	}
			}
			x=x.next;
		}
		Node p=FR;
	
		while(p!=null) {
			try {
	   		 b1 = new BufferedWriter(new FileWriter("FR.txt", true));
	   		 b1.write(p.id);
	   		 b1.newLine();
	   		 b1.close();
	   	}catch(IOException fe) {
	   		
	   	}
			p=p.next;
		}
		Node q=NFR;
		BufferedWriter b2=null;
		try {
		
		while(q!=null) {
		
			 b2 = new BufferedWriter(new FileWriter("NFR.txt", true));
	   		 b2.write(q.id+" "+q.priority+" ");
	   		 b2.newLine();
	   		 b2.close();
	   		q=q.next;
		}
		b2.close();
	   	}catch(IOException fe) {
	   		
	   	}
		
		
		Edge1 r=E_FN;
		BufferedWriter b3=null;
		try {
	 	
		while(r!=null) {
			
			 b3 = new BufferedWriter(new FileWriter("Dependency.txt", true));
	   		 b3.write(r.id1+" "+r.id2+" "+r.value+" ");
	   		 b3.newLine();
	   		 b3.close();
	   		r=r.next;
	   	}
		b3.close();
		}catch(IOException fe) {
	   		
	   	}
		
		Edge1 s=E_NN;
		BufferedWriter b4=null;
		while(s!=null) {
			try {
	   		 b4 = new BufferedWriter(new FileWriter("Conflict.txt",true));
	   		 b4.write(s.id1+" "+s.id2+" "+s.value+" ");
	   		 b4.newLine();
	   		 b4.close();
	   	}catch(IOException fe) {
	   		
	   	}
			s=s.next;
		}
		Edge2 t=E_FF;
		BufferedWriter b5=null;
		while(t!=null) {
			try {
				 b5 = new BufferedWriter(new FileWriter("Temporal.txt", true));
	   		 b5.write(t.id1+" "+t.id2+" ");
	   		 b5.newLine();
	   		 b5.close();
	   	}catch(IOException fe) {
	   		
	   	}
			t=t.next;
		}
		BufferedWriter b6=null;
		try {
			b6 = new BufferedWriter(new FileWriter("Iteration.txt", false));
			 String s2=Integer.toString(iteration);
	   		 b6.write(s2);
			
		}catch(IOException fe) {
	   		
	   	}
		
	}
}
/**
 * @version 1.0 11/09/98
 */

class ButtonRenderer extends JButton implements TableCellRenderer {

  public ButtonRenderer() {
    setOpaque(true);
  }

  public Component getTableCellRendererComponent(JTable table, Object value,
      boolean isSelected, boolean hasFocus, int row, int column) {
    if (isSelected) {
      setForeground(table.getSelectionForeground());
      setBackground(table.getSelectionBackground());
    } else {
      setForeground(table.getForeground());
      setBackground(UIManager.getColor("Button.background"));
    }
    setText((value == null) ? "" : value.toString());
    return this;
  }
}

/**
 * @version 1.0 11/09/98
 */
//Class for assigining buttons to table cells
class ButtonEditor extends DefaultCellEditor {
  protected JButton button;

  private String label;

  private boolean isPushed;

  public ButtonEditor(JCheckBox checkBox) {
    super(checkBox);
    button = new JButton();
    button.setOpaque(true);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
      }
    });
  }

  public Component getTableCellEditorComponent(JTable table, Object value,
      boolean isSelected, int row, int column) {
    if (isSelected) {
      button.setForeground(table.getSelectionForeground());
      button.setBackground(table.getSelectionBackground());
    } else {
      button.setForeground(table.getForeground());
      button.setBackground(table.getBackground());
    }
    label = (value == null) ? "" : value.toString();
    button.setText(label);
    isPushed = true;
    return button;
  }

  public Object getCellEditorValue() {
    if (isPushed) {
      // 
      // 
    	String s=label;
    	PartialOrder.showgraph(label);
    	System.out.println("The label is "+label);

    }
    isPushed = false;
    return new String(label);
  }

  public boolean stopCellEditing() {
    isPushed = false;
    return super.stopCellEditing();
  }

  protected void fireEditingStopped() {
    super.fireEditingStopped();
  }
}

//Class for getting tool tip over column headers in table
class ToolTipHeader extends GroupableTableHeader{
	   String[] toolTips;
	   public ToolTipHeader(TableColumnModel model) {
	      super(model);
	   }
	   public String getToolTipText(MouseEvent e) {
	      int col = columnAtPoint(e.getPoint());
	      int modelCol = getTable().convertColumnIndexToModel(col);
	      String retStr;
	      try {
	         retStr = toolTips[modelCol];
	      } catch (NullPointerException ex) {
	         retStr = "";
	      } catch (ArrayIndexOutOfBoundsException ex) {
	         retStr = "";
	      }
	      if (retStr.length() < 1) {
	         retStr = super.getToolTipText(e);
	      }
	      return retStr;
	   }
	   public void setToolTipStrings(String[] toolTips) {
	      this.toolTips = toolTips;
	   }
	}
//Class for assigning different colors to columns in table
class ColumnColorRenderer extends DefaultTableCellRenderer {
	   Color backgroundColor, foregroundColor;
	   public ColumnColorRenderer(Color backgroundColor, Color foregroundColor) {
	      super();
	      this.backgroundColor = backgroundColor;
	      this.foregroundColor = foregroundColor;
	      this.setFont(  this.getFont().deriveFont(Font.BOLD) );
	 
	   }
	   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,   boolean hasFocus, int row, int column) {
	      Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
	      cell.setBackground(backgroundColor);
	      cell.setForeground(foregroundColor);
	      return cell;
	   }
	}

//Class for creating charts or graphs
class LineChart_AWT extends JFrame {

	public LineChart_AWT( String applicationTitle , String chartTitle, int num, String s, int a1[], int a2[], int a3[], double a4[], double a5[] ) {
	      super(applicationTitle);
	      if(num!=0) {
	      JFreeChart barChart = ChartFactory.createBarChart(   //createLineChart3D( //createXYLineChart (
	         chartTitle,
	         "Iteration", "Functional Requirements",
	         createDataset(num,s, a1, a2, a3, a4,a5),
	         PlotOrientation.VERTICAL,
	         true,true,false);
	       
	      
	      CategoryPlot plot = barChart.getCategoryPlot();
	   //   Paint background = new GradientPaint(0, 0, Color.lightGray, 0, IMAGE_MIN_HEIGHT, Color.white);
	     // plot.setBackgroundPaint(background);
	      plot.setDomainGridlinePaint(Color.white);
	      plot.setDomainGridlinesVisible(true);
	      plot.setRangeGridlinePaint(Color.white);
	      plot.setRangeAxisLocation(AxisLocation.BOTTOM_OR_LEFT);
	      //if((s.compareTo("Risk"))!=0) {
	      LogarithmicAxis rangeAxis = new LogarithmicAxis(null);
	      rangeAxis.setStrictValuesFlag(false);
	      rangeAxis.setAllowNegativesFlag(true);
	      plot.setRangeAxis(rangeAxis);
	      //}
	      // Disable bar outlines.
	      BarRenderer renderer = (BarRenderer) plot.getRenderer();
	      renderer.setDrawBarOutline(false);
	      renderer.setSeriesPaint(0, Color.red);
			renderer.setSeriesPaint(1, Color.green);
			renderer.setSeriesPaint(2, Color.blue);
	     
	      CategoryAxis domainAxis = plot.getDomainAxis();
	      domainAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0));
	     // xAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0));
	      // Set theme-specific colors.
	      //Color bgColor = getBackground(request);
	      //Color fgColor = getForeground(request);
	
	      //chart.setBackgroundPaint(bgColor);
	
	      /*domainAxis.setTickLabelPaint(fgColor);
	      domainAxis.setTickMarkPaint(fgColor);
	      domainAxis.setAxisLinePaint(fgColor);
	
	      rangeAxis.setTickLabelPaint(fgColor);
	      rangeAxis.setTickMarkPaint(fgColor);
	      rangeAxis.setAxisLinePaint(fgColor);*/
	
	      
	      
	      ChartPanel chartPanel = new ChartPanel( barChart );
	      chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
	      setContentPane( chartPanel );
	
	      
	
	      // Assign it to the chart
	    /* CategoryPlot plot =barChart.getCategoryPlot();
	
	     CategoryAxis xAxis = plot.getDomainAxis();
	     xAxis.setCategoryLabelPositionOffset(3);
	     
	     NumberAxis yAxis = (NumberAxis) this.plot.getRangeAxis();
	     
	     */
	     // plot.setDomainAxis(xAxis);
	    
	      }
	   }

	/* public LineChart_AWT( String applicationTitle , String chartTitle, int num, String s, int a1[], int a2[], int a3[], double a4[], double a5[] ) {
	      super(applicationTitle);
	      if(num!=0) {
	      JFreeChart barChart = ChartFactory.createXYBarChart(   //createLineChart3D( //createXYLineChart (
	         chartTitle,
	         "Iteration", false, "Functional Requirements",
	         (IntervalXYDataset) createDataset(num,s, a1, a2, a3, a4,a5),
	         PlotOrientation.VERTICAL,
	         true,true,false);
	       
	      
	      final XYPlot plot = barChart.getXYPlot();
	      final NumberAxis domainAxis = new NumberAxis("Iteration");
	      final NumberAxis rangeAxis = new LogarithmicAxis("Functional Requirements");
	      plot.setDomainAxis(domainAxis);
	      plot.setRangeAxis(rangeAxis);
	      barChart.setBackgroundPaint(Color.white);
	      plot.setOutlinePaint(Color.black);
	      final ChartPanel chartPanel = new ChartPanel(barChart);
	      chartPanel.setPreferredSize(new java.awt.Dimension(500, 367));
	      setContentPane(chartPanel);
	      
	      
	      //ChartPanel chartPanel = new ChartPanel( barChart );
	      //chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
	      //setContentPane( chartPanel );
	   
	      
	
	      // Assign it to the chart
	    /* CategoryPlot plot =barChart.getCategoryPlot();
	
	     CategoryAxis xAxis = plot.getDomainAxis();
	     xAxis.setCategoryLabelPositionOffset(3);
	     
	     NumberAxis yAxis = (NumberAxis) this.plot.getRangeAxis();
	     
	     xAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(0));*/
	     // plot.setDomainAxis(xAxis);
	    
	      //}
	   //}
	
	  /* private XYSeriesCollection createDataset( int num, String s, int a1[], int a2[], int a3[], double a4[], double a5[]) {
		  //  DefaultXYDataset dataset = new DefaultXYDataset( );
		   //num=41;
		   System.out.println("Num ="+num);
		   final XYSeriesCollection dataset = new XYSeriesCollection();
		   if((s.compareTo("FR"))==0) {
			   final XYSeries s1 = new XYSeries("Total FRs");
		        final XYSeries s2 = new XYSeries("Newly Added FRs");
		 //  String series1 = "Total FRs";  
		   // String series2 = "Newly Added FRs";  
		        for (int i = 0; i <num; i++) {
		            s1.add(i, a1[i]);
		            if(a2[i]==0)
		            	s2.add(i, 2);
		            else
		            	s2.add(i, a2[i]);
		           
		        }
		        dataset.addSeries(s1);
		        dataset.addSeries(s2);
		   }
		      //  final XYSeriesCollection dataset = new XYSeriesCollection();
		    
	    /*  for(int i=0;i<num;i++)
	      {
	    	  dataset.addSeries(series1, a1[i]); //addValue(a1[i], series1, String.valueOf(i+1));
	    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
	      }
		   }
		   else if((s.compareTo("NFR"))==0) {
			   String series1 = "Total NFRs";  
			    String series2 = "Newly Added NFRs";  
	
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
		      }
			   }
		   else if((s.compareTo("Dependency"))==0) {
			   String series1 = "Total FR-NFR Dependency";  
			    String series2 = "Newly Added Dependencies";  
			    String series3 = "Updated Dependencies"; 
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
		    	  dataset.addValue(a3[i], series3, String.valueOf(i+1));
		      }
			   }
		   else if((s.compareTo("Conflict"))==0) {
			   String series1 = "Total NFR Conflict";  
			    String series2 = "Newly Added Conflicts";  
			    String series3 = "Updated Conflicts"; 
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
		    	  dataset.addValue(a3[i], series3, String.valueOf(i+1));
		      }
			   }
		   else if((s.compareTo("Temporal"))==0) {
			   String series1 = "Total Temporal Dependencies";  
			    String series2 = "Newly Added Dependencies";  
	
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
		      }
			   }
		   else if((s.compareTo("Risk"))==0) {
			   String series1 = "Risk Incurred";  
			   String series2 = "Total Risk";  
			   
	
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a4[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a5[i], series2, String.valueOf(i+1));
		    	
		      }
			   }*/
	     // return dataset;
	   //}
		 private DefaultCategoryDataset createDataset( int num, String s, int a1[], int a2[], int a3[], double a4[], double a5[]) {
			    DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
			   if((s.compareTo("FR"))==0) {
			   String series1 = "Total FRs";  
			    String series2 = "Newly Added FRs";  
	
		      for(int i=0;i<num;i++)
		      {
		    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
		    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
		      }
			   }
			   else if((s.compareTo("NFR"))==0) {
				   String series1 = "Total NFRs";  
				    String series2 = "Newly Added NFRs";  
	
			      for(int i=0;i<num;i++)
			      {
			    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
			    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
			      }
				   }
			   else if((s.compareTo("Dependency"))==0) {
				   String series1 = "Total FR-NFR Dependency";  
				    String series2 = "Newly Added Dependencies";  
				    String series3 = "Updated Dependencies"; 
			      for(int i=0;i<num;i++)
			      {
			    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
			    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
			    	  dataset.addValue(a3[i], series3, String.valueOf(i+1));
			      }
				   }
			   else if((s.compareTo("Conflict"))==0) {
				   String series1 = "Total NFR Conflict";  
				    String series2 = "Newly Added Conflicts";  
				    String series3 = "Updated Conflicts"; 
			      for(int i=0;i<num;i++)
			      {
			    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
			    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
			    	  dataset.addValue(a3[i], series3, String.valueOf(i+1));
			      }
				   }
			   else if((s.compareTo("Temporal"))==0) {
				   String series1 = "Total Temporal Dependencies";  
				    String series2 = "Newly Added Dependencies";  
	
			      for(int i=0;i<num;i++)
			      {
			    	  dataset.addValue(a1[i], series1, String.valueOf(i+1));
			    	  dataset.addValue(a2[i], series2, String.valueOf(i+1));
			      }
				   }
			   else if((s.compareTo("Risk"))==0) {
				   String series1 = "Risk Incurred";  
				   String series2 = "Total Risk";  
	
			      for(int i=0;i<num;i++)
			      {
			    	  dataset.addValue(a4[i], series1, String.valueOf(i+1));
			    	  dataset.addValue(a5[i], series2, String.valueOf(i+1));
			      }
				   }
		      return dataset;
		   }

	public static void graphGenerate(int num, String s, int a1[], int a2[], int a3[], double a4[], double a5[]) {
		  
		   LineChart_AWT chart=new LineChart_AWT("", "",0,s,a1,a2,a3,a4,a5);
		   if((s.compareTo("FR"))==0) {
	      chart = new LineChart_AWT(
	         "Graphical Analysis" ,
	         "Iteration & Functional Requirements",num, s, a1,a2,a3, a4,a5);
		  }
		   else if((s.compareTo("NFR"))==0) {
			      chart = new LineChart_AWT(
			         "Graphical Analysis" ,
			         "Iteration & Non-functional Requirements",num, s, a1,a2,a3, a4,a5);
				  }
		   else if((s.compareTo("Dependency"))==0) {
			      chart = new LineChart_AWT(
			         "Graphical Analysis" ,
			         "Iteration & FR-NFR Dependency",num, s, a1,a2,a3, a4,a5);
				  }
		   else if((s.compareTo("Conflict"))==0) {
			      chart = new LineChart_AWT(
			         "Graphical Analysis" ,
			         "Iteration & Non-functional Requirements Conflicts",num, s, a1,a2,a3, a4,a5);
				  }
		   else if((s.compareTo("Temporal"))==0) {
			      chart = new LineChart_AWT(
			         "Graphical Analysis" ,
			         "Iteration & Temporal Dependency",num, s, a1,a2,a3, a4,a5);
				  }
		   else if((s.compareTo("Risk"))==0) {
			      chart = new LineChart_AWT(
			         "Graphical Analysis" ,
			         "Iteration & Risk Analysis",num, s, a1,a2,a3, a4,a5);
				  }
	      chart.pack( );
	      RefineryUtilities.centerFrameOnScreen( chart );
	      chart.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	     
	      chart.setVisible( true );
	   }
	
}

 class RowHeaderRenderer extends DefaultTableCellRenderer {
  
	private static final long serialVersionUID = 1L;

	public RowHeaderRenderer() {
        setHorizontalAlignment(JLabel.CENTER);
    }

    public Component getTableCellRendererComponent(JTable table,
            Object value, boolean isSelected, boolean hasFocus, int row,
            int column) {
        if (table != null) {
            JTableHeader header = table.getTableHeader();

            if (header != null) {
                setForeground(header.getForeground());
                setBackground(header.getBackground());
                setFont(header.getFont());
            }
        }

        if (isSelected) {
            setFont(getFont().deriveFont(Font.BOLD));
        }

        setValue(value);
        return this;
    }
}
 
